window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "3289324877",
      "userLink" : "https://twitter.com/intent/user?user_id=3289324877"
    }
  },
  {
    "follower" : {
      "accountId" : "327084810",
      "userLink" : "https://twitter.com/intent/user?user_id=327084810"
    }
  },
  {
    "follower" : {
      "accountId" : "2661563889",
      "userLink" : "https://twitter.com/intent/user?user_id=2661563889"
    }
  },
  {
    "follower" : {
      "accountId" : "1641018061103702017",
      "userLink" : "https://twitter.com/intent/user?user_id=1641018061103702017"
    }
  }
]