window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "1387219918597328897",
      "userLink" : "https://twitter.com/intent/user?user_id=1387219918597328897"
    }
  },
  {
    "muting" : {
      "accountId" : "1613830464774754304",
      "userLink" : "https://twitter.com/intent/user?user_id=1613830464774754304"
    }
  },
  {
    "muting" : {
      "accountId" : "1490570807940108288",
      "userLink" : "https://twitter.com/intent/user?user_id=1490570807940108288"
    }
  },
  {
    "muting" : {
      "accountId" : "1672264030969372672",
      "userLink" : "https://twitter.com/intent/user?user_id=1672264030969372672"
    }
  },
  {
    "muting" : {
      "accountId" : "1012993604481150977",
      "userLink" : "https://twitter.com/intent/user?user_id=1012993604481150977"
    }
  },
  {
    "muting" : {
      "accountId" : "1253745177459646466",
      "userLink" : "https://twitter.com/intent/user?user_id=1253745177459646466"
    }
  },
  {
    "muting" : {
      "accountId" : "1647709670507782151",
      "userLink" : "https://twitter.com/intent/user?user_id=1647709670507782151"
    }
  },
  {
    "muting" : {
      "accountId" : "64857767",
      "userLink" : "https://twitter.com/intent/user?user_id=64857767"
    }
  }
]