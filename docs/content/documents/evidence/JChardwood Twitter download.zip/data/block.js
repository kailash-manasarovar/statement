window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "1691702433745960960",
      "userLink" : "https://twitter.com/intent/user?user_id=1691702433745960960"
    }
  },
  {
    "blocking" : {
      "accountId" : "1688493655534026752",
      "userLink" : "https://twitter.com/intent/user?user_id=1688493655534026752"
    }
  },
  {
    "blocking" : {
      "accountId" : "1660283023550713856",
      "userLink" : "https://twitter.com/intent/user?user_id=1660283023550713856"
    }
  },
  {
    "blocking" : {
      "accountId" : "1659538228498530306",
      "userLink" : "https://twitter.com/intent/user?user_id=1659538228498530306"
    }
  },
  {
    "blocking" : {
      "accountId" : "1658904847473598465",
      "userLink" : "https://twitter.com/intent/user?user_id=1658904847473598465"
    }
  },
  {
    "blocking" : {
      "accountId" : "1647709670507782151",
      "userLink" : "https://twitter.com/intent/user?user_id=1647709670507782151"
    }
  },
  {
    "blocking" : {
      "accountId" : "1640251271939538946",
      "userLink" : "https://twitter.com/intent/user?user_id=1640251271939538946"
    }
  },
  {
    "blocking" : {
      "accountId" : "1640198272215306240",
      "userLink" : "https://twitter.com/intent/user?user_id=1640198272215306240"
    }
  },
  {
    "blocking" : {
      "accountId" : "1640188438464057344",
      "userLink" : "https://twitter.com/intent/user?user_id=1640188438464057344"
    }
  },
  {
    "blocking" : {
      "accountId" : "1640125908659863553",
      "userLink" : "https://twitter.com/intent/user?user_id=1640125908659863553"
    }
  },
  {
    "blocking" : {
      "accountId" : "1639970296907304960",
      "userLink" : "https://twitter.com/intent/user?user_id=1639970296907304960"
    }
  },
  {
    "blocking" : {
      "accountId" : "1606741342029316102",
      "userLink" : "https://twitter.com/intent/user?user_id=1606741342029316102"
    }
  },
  {
    "blocking" : {
      "accountId" : "1604192108646203392",
      "userLink" : "https://twitter.com/intent/user?user_id=1604192108646203392"
    }
  },
  {
    "blocking" : {
      "accountId" : "1598751294465925120",
      "userLink" : "https://twitter.com/intent/user?user_id=1598751294465925120"
    }
  },
  {
    "blocking" : {
      "accountId" : "1596677182436544513",
      "userLink" : "https://twitter.com/intent/user?user_id=1596677182436544513"
    }
  },
  {
    "blocking" : {
      "accountId" : "1587642372480966658",
      "userLink" : "https://twitter.com/intent/user?user_id=1587642372480966658"
    }
  },
  {
    "blocking" : {
      "accountId" : "1559731905637007360",
      "userLink" : "https://twitter.com/intent/user?user_id=1559731905637007360"
    }
  },
  {
    "blocking" : {
      "accountId" : "1540054413636673537",
      "userLink" : "https://twitter.com/intent/user?user_id=1540054413636673537"
    }
  },
  {
    "blocking" : {
      "accountId" : "1539184737398538242",
      "userLink" : "https://twitter.com/intent/user?user_id=1539184737398538242"
    }
  },
  {
    "blocking" : {
      "accountId" : "1536093715034476544",
      "userLink" : "https://twitter.com/intent/user?user_id=1536093715034476544"
    }
  },
  {
    "blocking" : {
      "accountId" : "1513096730505490435",
      "userLink" : "https://twitter.com/intent/user?user_id=1513096730505490435"
    }
  },
  {
    "blocking" : {
      "accountId" : "1503499710111555584",
      "userLink" : "https://twitter.com/intent/user?user_id=1503499710111555584"
    }
  },
  {
    "blocking" : {
      "accountId" : "1491391874447335433",
      "userLink" : "https://twitter.com/intent/user?user_id=1491391874447335433"
    }
  },
  {
    "blocking" : {
      "accountId" : "1395812274984607744",
      "userLink" : "https://twitter.com/intent/user?user_id=1395812274984607744"
    }
  },
  {
    "blocking" : {
      "accountId" : "1331709794386923521",
      "userLink" : "https://twitter.com/intent/user?user_id=1331709794386923521"
    }
  },
  {
    "blocking" : {
      "accountId" : "988383437831712768",
      "userLink" : "https://twitter.com/intent/user?user_id=988383437831712768"
    }
  },
  {
    "blocking" : {
      "accountId" : "704293564226744320",
      "userLink" : "https://twitter.com/intent/user?user_id=704293564226744320"
    }
  },
  {
    "blocking" : {
      "accountId" : "3336426058",
      "userLink" : "https://twitter.com/intent/user?user_id=3336426058"
    }
  },
  {
    "blocking" : {
      "accountId" : "3324174575",
      "userLink" : "https://twitter.com/intent/user?user_id=3324174575"
    }
  },
  {
    "blocking" : {
      "accountId" : "3021962360",
      "userLink" : "https://twitter.com/intent/user?user_id=3021962360"
    }
  },
  {
    "blocking" : {
      "accountId" : "2998647189",
      "userLink" : "https://twitter.com/intent/user?user_id=2998647189"
    }
  },
  {
    "blocking" : {
      "accountId" : "2957045984",
      "userLink" : "https://twitter.com/intent/user?user_id=2957045984"
    }
  },
  {
    "blocking" : {
      "accountId" : "2954677705",
      "userLink" : "https://twitter.com/intent/user?user_id=2954677705"
    }
  },
  {
    "blocking" : {
      "accountId" : "2856660409",
      "userLink" : "https://twitter.com/intent/user?user_id=2856660409"
    }
  },
  {
    "blocking" : {
      "accountId" : "2737636815",
      "userLink" : "https://twitter.com/intent/user?user_id=2737636815"
    }
  },
  {
    "blocking" : {
      "accountId" : "1154197626",
      "userLink" : "https://twitter.com/intent/user?user_id=1154197626"
    }
  },
  {
    "blocking" : {
      "accountId" : "835068482",
      "userLink" : "https://twitter.com/intent/user?user_id=835068482"
    }
  },
  {
    "blocking" : {
      "accountId" : "561666424",
      "userLink" : "https://twitter.com/intent/user?user_id=561666424"
    }
  },
  {
    "blocking" : {
      "accountId" : "511538112",
      "userLink" : "https://twitter.com/intent/user?user_id=511538112"
    }
  },
  {
    "blocking" : {
      "accountId" : "377919230",
      "userLink" : "https://twitter.com/intent/user?user_id=377919230"
    }
  },
  {
    "blocking" : {
      "accountId" : "333315940",
      "userLink" : "https://twitter.com/intent/user?user_id=333315940"
    }
  },
  {
    "blocking" : {
      "accountId" : "333296714",
      "userLink" : "https://twitter.com/intent/user?user_id=333296714"
    }
  },
  {
    "blocking" : {
      "accountId" : "330390220",
      "userLink" : "https://twitter.com/intent/user?user_id=330390220"
    }
  },
  {
    "blocking" : {
      "accountId" : "298747917",
      "userLink" : "https://twitter.com/intent/user?user_id=298747917"
    }
  },
  {
    "blocking" : {
      "accountId" : "262545395",
      "userLink" : "https://twitter.com/intent/user?user_id=262545395"
    }
  },
  {
    "blocking" : {
      "accountId" : "255086802",
      "userLink" : "https://twitter.com/intent/user?user_id=255086802"
    }
  },
  {
    "blocking" : {
      "accountId" : "230779264",
      "userLink" : "https://twitter.com/intent/user?user_id=230779264"
    }
  }
]