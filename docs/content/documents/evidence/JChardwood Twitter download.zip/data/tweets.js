window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698223635763200095"
          ],
          "editableUntil" : "2023-09-03T07:37:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anthony Sin 🟩🌹",
            "screen_name" : "AlphaSinnerMan",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "407951198",
            "id" : "407951198"
          },
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "16",
              "23"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          },
          {
            "name" : "Support",
            "screen_name" : "Support",
            "indices" : [
              "24",
              "32"
            ],
            "id_str" : "17874544",
            "id" : "17874544"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "33",
              "42"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "88",
              "95"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "95"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1698194741505249548",
      "id_str" : "1698223635763200095",
      "in_reply_to_user_id" : "407951198",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698223635763200095",
      "in_reply_to_status_id" : "1698194741505249548",
      "created_at" : "Sun Sep 03 06:37:20 +0000 2023",
      "favorited" : false,
      "full_text" : "@AlphaSinnerMan @1FRGVN @Support @elonmusk i guess this is exactly what's been going on @1FRGVN",
      "lang" : "en",
      "in_reply_to_screen_name" : "AlphaSinnerMan",
      "in_reply_to_user_id_str" : "407951198"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698129797648417132"
          ],
          "editableUntil" : "2023-09-03T01:24:28.142Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          },
          {
            "name" : "Support",
            "screen_name" : "Support",
            "indices" : [
              "12",
              "20"
            ],
            "id_str" : "17874544",
            "id" : "17874544"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "48",
              "57"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "114",
              "128"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1698129797648417132",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698129797648417132",
      "created_at" : "Sun Sep 03 00:24:28 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: @Support no one is seeing my tweets @elonmusk and I have been gang stalked and hacked on here (and at @jackchardwood) for months",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698127568568770603"
          ],
          "editableUntil" : "2023-09-03T01:15:36.688Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "0",
      "id_str" : "1698127568568770603",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698127568568770603",
      "created_at" : "Sun Sep 03 00:15:36 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: If I die in suspicious circumstances, I want my epitaph to read:\n\n\"All I wanted was to play the piano.\"\n\n&lt;3",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698127328172294530"
          ],
          "editableUntil" : "2023-09-03T01:14:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "8",
              "17"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "21",
      "in_reply_to_status_id_str" : "1698121721457365343",
      "id_str" : "1698127328172294530",
      "in_reply_to_user_id" : "1423937973201027078",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1698127328172294530",
      "in_reply_to_status_id" : "1698121721457365343",
      "created_at" : "Sun Sep 03 00:14:39 +0000 2023",
      "favorited" : false,
      "full_text" : "@1FRGVN @elonmusk can you help?",
      "lang" : "en",
      "in_reply_to_screen_name" : "1FRGVN",
      "in_reply_to_user_id_str" : "1423937973201027078"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698127172483895778"
          ],
          "editableUntil" : "2023-09-03T01:14:02.254Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1698127172483895778",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698127172483895778",
      "created_at" : "Sun Sep 03 00:14:02 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: I've just gone public after years being anonymous on Twitter because it's safer for Women that way.\n\nI have been targeted by #T…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698127136408613169"
          ],
          "editableUntil" : "2023-09-03T01:13:53.653Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          },
          {
            "name" : "The Free Speech Union",
            "screen_name" : "SpeechUnion",
            "indices" : [
              "12",
              "24"
            ],
            "id_str" : "1157694950655561728",
            "id" : "1157694950655561728"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1698127136408613169",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698127136408613169",
      "created_at" : "Sun Sep 03 00:13:53 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: @SpeechUnion",
      "lang" : "qam"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698127122076721365"
          ],
          "editableUntil" : "2023-09-03T01:13:50.236Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "id_str" : "1698127122076721365",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698127122076721365",
      "created_at" : "Sun Sep 03 00:13:50 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: Going public.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698127100073455910"
          ],
          "editableUntil" : "2023-09-03T01:13:44.990Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1698127100073455910",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698127100073455910",
      "created_at" : "Sun Sep 03 00:13:44 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: I've just gone public.\n\nThe reason is because I believe I am about to be arrested in Spain for something related to my GC belie…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698127079752016094"
          ],
          "editableUntil" : "2023-09-03T01:13:40.145Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          },
          {
            "name" : "The Free Speech Union",
            "screen_name" : "SpeechUnion",
            "indices" : [
              "12",
              "24"
            ],
            "id_str" : "1157694950655561728",
            "id" : "1157694950655561728"
          },
          {
            "name" : "Dennis Noel Kavanagh",
            "screen_name" : "Jebadoo2",
            "indices" : [
              "25",
              "34"
            ],
            "id_str" : "1436433500",
            "id" : "1436433500"
          },
          {
            "name" : "Helen Joyce",
            "screen_name" : "HJoyceGender",
            "indices" : [
              "35",
              "48"
            ],
            "id_str" : "1110105054",
            "id" : "1110105054"
          },
          {
            "name" : "Julie Bindel",
            "screen_name" : "bindelj",
            "indices" : [
              "49",
              "57"
            ],
            "id_str" : "209512953",
            "id" : "209512953"
          },
          {
            "name" : "Justice for Women",
            "screen_name" : "justice4women",
            "indices" : [
              "58",
              "72"
            ],
            "id_str" : "165402581",
            "id" : "165402581"
          },
          {
            "name" : "Genevieve Gluck",
            "screen_name" : "WomenReadWomen",
            "indices" : [
              "73",
              "88"
            ],
            "id_str" : "1088761072163516417",
            "id" : "1088761072163516417"
          },
          {
            "name" : "REDUXX",
            "screen_name" : "ReduxxMag",
            "indices" : [
              "89",
              "99"
            ],
            "id_str" : "1482775223414198273",
            "id" : "1482775223414198273"
          },
          {
            "name" : "Daily Mail US",
            "screen_name" : "DailyMail",
            "indices" : [
              "100",
              "110"
            ],
            "id_str" : "380285402",
            "id" : "380285402"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "id_str" : "1698127079752016094",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698127079752016094",
      "created_at" : "Sun Sep 03 00:13:40 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: @SpeechUnion @Jebadoo2 @HJoyceGender @bindelj @justice4women @WomenReadWomen @ReduxxMag @DailyMail who else should I ping?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1697880235105022271"
          ],
          "editableUntil" : "2023-09-02T08:52:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "SorryGreta",
            "indices" : [
              "38",
              "49"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk (Parody)",
            "screen_name" : "ElonMuskAOC",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1382209054999646212",
            "id" : "1382209054999646212"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/ntC8JZAVIw",
            "expanded_url" : "https://www.honda.co.uk/cars/new/civic-type-r/overview.html",
            "display_url" : "honda.co.uk/cars/new/civic…",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1697735883871682755",
      "id_str" : "1697880235105022271",
      "in_reply_to_user_id" : "1382209054999646212",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1697880235105022271",
      "in_reply_to_status_id" : "1697735883871682755",
      "possibly_sensitive" : false,
      "created_at" : "Sat Sep 02 07:52:47 +0000 2023",
      "favorited" : false,
      "full_text" : "@ElonMuskAOC https://t.co/ntC8JZAVIw\n\n#SorryGreta",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ElonMuskAOC",
      "in_reply_to_user_id_str" : "1382209054999646212"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1697527520285855934"
          ],
          "editableUntil" : "2023-09-01T09:31:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "id_str" : "1697527520285855934",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1697527520285855934",
      "created_at" : "Fri Sep 01 08:31:14 +0000 2023",
      "favorited" : false,
      "full_text" : "Good luck getting paid love.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1697198981678256150"
          ],
          "editableUntil" : "2023-08-31T11:45:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "1",
      "id_str" : "1697198981678256150",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1697198981678256150",
      "created_at" : "Thu Aug 31 10:45:44 +0000 2023",
      "favorited" : false,
      "full_text" : "God, I feel paralysed.\n\nBit of an additional delayed reaction I guess.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1697014897698029945"
          ],
          "editableUntil" : "2023-08-30T23:34:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "267"
      ],
      "favorite_count" : "1",
      "id_str" : "1697014897698029945",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1697014897698029945",
      "created_at" : "Wed Aug 30 22:34:15 +0000 2023",
      "favorited" : false,
      "full_text" : "My guess:\n\nYou lied about me, REALLY REALLY BADLY this time, and it will cause me a lot of pain.\n\nAnd, at the moment I find out about this evil, you put your toro website live, with something dreadful on there. \n\nPics of me from my hacked machine? Worse?\n\nAm I right?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696996675317903456"
          ],
          "editableUntil" : "2023-08-30T22:21:50.726Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "0",
      "id_str" : "1696996675317903456",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696996675317903456",
      "created_at" : "Wed Aug 30 21:21:50 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: I need some legit confirmation of this and you'll never see me there again.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696996664555225110"
          ],
          "editableUntil" : "2023-08-30T22:21:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696990588628029460",
      "id_str" : "1696996664555225110",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1696996664555225110",
      "in_reply_to_status_id" : "1696990588628029460",
      "created_at" : "Wed Aug 30 21:21:48 +0000 2023",
      "favorited" : false,
      "full_text" : "I need some legit confirmation of this and you'll never see me there again.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696996474561736881"
          ],
          "editableUntil" : "2023-08-30T22:21:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "252"
      ],
      "favorite_count" : "1",
      "id_str" : "1696996474561736881",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696996474561736881",
      "created_at" : "Wed Aug 30 21:21:02 +0000 2023",
      "favorited" : false,
      "full_text" : "It's impossible to know how to resolve conflicts if I don't know what they are based on?\n\nIt's mysterious.\n\nCould it really be a friends bruised ego from 10 years ago?\n\nMy words taken out of context?\n\nOr you feel more alive at these moments?\n\nOr what??",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696990588628029460"
          ],
          "editableUntil" : "2023-08-30T21:57:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "1",
      "id_str" : "1696990588628029460",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1696990588628029460",
      "created_at" : "Wed Aug 30 20:57:39 +0000 2023",
      "favorited" : false,
      "full_text" : "Look, if I'm going to be in danger going back there, I won't go back.\n\nThat's what you all wanted isn't it?\n\nNo big deal. Not worth the stress.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696986746322289064"
          ],
          "editableUntil" : "2023-08-30T21:42:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "1",
      "id_str" : "1696986746322289064",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696986746322289064",
      "created_at" : "Wed Aug 30 20:42:23 +0000 2023",
      "favorited" : false,
      "full_text" : "We need to talk.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696986510459879442"
          ],
          "editableUntil" : "2023-08-30T21:41:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "1",
      "id_str" : "1696986510459879442",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696986510459879442",
      "created_at" : "Wed Aug 30 20:41:27 +0000 2023",
      "favorited" : false,
      "full_text" : "I have no bad or malicious feelings for anyone.\n\nHowever, I'm feeling a lot of negative and malicious energy directed towards me, and I feel that, perhaps, some evil is planned for Monday 4th?\n\nAm I right?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696984188530884843"
          ],
          "editableUntil" : "2023-08-30T21:32:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "1696984188530884843",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696984188530884843",
      "created_at" : "Wed Aug 30 20:32:13 +0000 2023",
      "favorited" : false,
      "full_text" : "Is there anything we can do now - communicate properly maybe - to avoid something that everyone is bound to regret?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696983414220435643"
          ],
          "editableUntil" : "2023-08-30T21:29:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "id_str" : "1696983414220435643",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696983414220435643",
      "created_at" : "Wed Aug 30 20:29:09 +0000 2023",
      "favorited" : false,
      "full_text" : "More gang stalking, or worse?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696982282945335696"
          ],
          "editableUntil" : "2023-08-30T21:24:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696980074715570543",
      "id_str" : "1696982282945335696",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696982282945335696",
      "in_reply_to_status_id" : "1696980074715570543",
      "created_at" : "Wed Aug 30 20:24:39 +0000 2023",
      "favorited" : false,
      "full_text" : "I should really say, another seriously unpleasant thing to add to the list.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696980074715570543"
          ],
          "editableUntil" : "2023-08-30T21:15:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "0",
      "id_str" : "1696980074715570543",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696980074715570543",
      "created_at" : "Wed Aug 30 20:15:52 +0000 2023",
      "favorited" : false,
      "full_text" : "I've gotta say, it feels like you're planning something seriously unpleasant.\n\nAm I right?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696849220278317383"
          ],
          "editableUntil" : "2023-08-30T12:35:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/aV5lxxQbdn",
            "expanded_url" : "https://etherscan.io/token/0x9d29f93e0a4c0bc5ac1e13d5b72038f35c81f325",
            "display_url" : "etherscan.io/token/0x9d29f9…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "id_str" : "1696849220278317383",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696849220278317383",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 30 11:35:54 +0000 2023",
      "favorited" : false,
      "full_text" : "https://t.co/aV5lxxQbdn",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696840825412407430"
          ],
          "editableUntil" : "2023-08-30T12:02:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "NothingToHide",
            "indices" : [
              "133",
              "147"
            ]
          },
          {
            "text" : "StillNoPrivacyHereInnit",
            "indices" : [
              "149",
              "173"
            ]
          },
          {
            "text" : "WhatDoYouWantExactlyIdLikeToKnowThankYou",
            "indices" : [
              "174",
              "215"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "215"
      ],
      "favorite_count" : "0",
      "id_str" : "1696840825412407430",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696840825412407430",
      "created_at" : "Wed Aug 30 11:02:33 +0000 2023",
      "favorited" : false,
      "full_text" : "I know it's fun, but you could just ask the business how much it makes.\n\nI guess you don't really understand the web3 space either.\n\n#NothingToHide \n#StillNoPrivacyHereInnit\n#WhatDoYouWantExactlyIdLikeToKnowThankYou",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696803933040026013"
          ],
          "editableUntil" : "2023-08-30T09:35:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "2",
      "id_str" : "1696803933040026013",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696803933040026013",
      "created_at" : "Wed Aug 30 08:35:57 +0000 2023",
      "favorited" : false,
      "full_text" : "Never forget that I love you, and wish you the very best &lt;3 \n\nYes, even you.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696616721237315626"
          ],
          "editableUntil" : "2023-08-29T21:12:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692575000841142681",
      "id_str" : "1696616721237315626",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696616721237315626",
      "in_reply_to_status_id" : "1692575000841142681",
      "created_at" : "Tue Aug 29 20:12:02 +0000 2023",
      "favorited" : false,
      "full_text" : "this didn't happen",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696613855504355493"
          ],
          "editableUntil" : "2023-08-29T21:00:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1696613855504355493/photo/1",
            "indices" : [
              "13",
              "36"
            ],
            "url" : "https://t.co/4sWSy21SpH",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/F4uVTiIWMAADhE0.jpg",
            "id_str" : "1696613847446990848",
            "id" : "1696613847446990848",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/F4uVTiIWMAADhE0.jpg",
            "sizes" : {
              "medium" : {
                "w" : "498",
                "h" : "372",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "498",
                "h" : "372",
                "resize" : "fit"
              },
              "large" : {
                "w" : "498",
                "h" : "372",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/4sWSy21SpH"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "id_str" : "1696613855504355493",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696613855504355493",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 29 20:00:39 +0000 2023",
      "favorited" : false,
      "full_text" : "yep, you too https://t.co/4sWSy21SpH",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1696613855504355493/photo/1",
            "indices" : [
              "13",
              "36"
            ],
            "url" : "https://t.co/4sWSy21SpH",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/F4uVTiIWMAADhE0.jpg",
            "id_str" : "1696613847446990848",
            "video_info" : {
              "aspect_ratio" : [
                "83",
                "62"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/F4uVTiIWMAADhE0.mp4"
                }
              ]
            },
            "id" : "1696613847446990848",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/F4uVTiIWMAADhE0.jpg",
            "sizes" : {
              "medium" : {
                "w" : "498",
                "h" : "372",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "498",
                "h" : "372",
                "resize" : "fit"
              },
              "large" : {
                "w" : "498",
                "h" : "372",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/4sWSy21SpH"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696613438405951719"
          ],
          "editableUntil" : "2023-08-29T20:58:59.926Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692575000841142681/photo/1",
            "source_status_id" : "1692575000841142681",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/cVGi3sL3qd",
            "media_url" : "http://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "id_str" : "1692574949863571456",
            "source_user_id" : "1568722551580278786",
            "id" : "1692574949863571456",
            "media_url_https" : "https://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "source_user_id_str" : "1568722551580278786",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "635",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1692575000841142681",
            "display_url" : "pic.twitter.com/cVGi3sL3qd"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "0",
      "id_str" : "1696613438405951719",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696613438405951719",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 29 19:58:59 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: And we would all appreciate very much it if you would .. https://t.co/cVGi3sL3qd",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692575000841142681/photo/1",
            "source_status_id" : "1692575000841142681",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/cVGi3sL3qd",
            "media_url" : "http://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "id_str" : "1692574949863571456",
            "source_user_id" : "1568722551580278786",
            "id" : "1692574949863571456",
            "media_url_https" : "https://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "source_user_id_str" : "1568722551580278786",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "635",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1692575000841142681",
            "display_url" : "pic.twitter.com/cVGi3sL3qd"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696083345896014098"
          ],
          "editableUntil" : "2023-08-28T09:52:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "WhyNot",
            "indices" : [
              "14",
              "21"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "id_str" : "1696083345896014098",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696083345896014098",
      "created_at" : "Mon Aug 28 08:52:36 +0000 2023",
      "favorited" : false,
      "full_text" : "Making hay. \n\n#WhyNot",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696073983660106033"
          ],
          "editableUntil" : "2023-08-28T09:15:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "141"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1696073754462265427",
      "id_str" : "1696073983660106033",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696073983660106033",
      "in_reply_to_status_id" : "1696073754462265427",
      "created_at" : "Mon Aug 28 08:15:23 +0000 2023",
      "favorited" : false,
      "full_text" : "i can't be bothered to learn this .. i will if i have to .. the bigger boys always get in in any case, so i never thought it worth the effort",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696073754462265427"
          ],
          "editableUntil" : "2023-08-28T09:14:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "116"
      ],
      "favorite_count" : "0",
      "id_str" : "1696073754462265427",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696073754462265427",
      "created_at" : "Mon Aug 28 08:14:29 +0000 2023",
      "favorited" : false,
      "full_text" : "The first thing I'm gonna need you to do when you're onboard love is ...\n\n... secure my Linux machine.\n\n😅😅🤣🤣🤣😂😂😂😂😂🤣😅",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695719989305561402"
          ],
          "editableUntil" : "2023-08-27T09:48:45.061Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1695719989305561402",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695719989305561402",
      "created_at" : "Sun Aug 27 08:48:45 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: Ongoing frontend dev support.\n\nFuture dev ops infrastructure support.\n\nFuture backend engineering efforts (check out the…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695590860635685134"
          ],
          "editableUntil" : "2023-08-27T01:15:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "131"
      ],
      "favorite_count" : "0",
      "id_str" : "1695590860635685134",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695590860635685134",
      "created_at" : "Sun Aug 27 00:15:38 +0000 2023",
      "favorited" : false,
      "full_text" : "Do you know, that if God hadn't given male cats barbs on their willies, the whole world would be overrun with cats.\n\nThat's a fact.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695590542162243943"
          ],
          "editableUntil" : "2023-08-27T01:14:22.457Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "place where cat shouldn't be",
            "screen_name" : "catshouldnt",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1333062067356532736",
            "id" : "1333062067356532736"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/catshouldnt/status/1695472170326249834/video/1",
            "source_status_id" : "1695472170326249834",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/PNghhy1bWh",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1695472145172951040/pu/img/RhAiL9YGiDmEjMHF.jpg",
            "id_str" : "1695472145172951040",
            "source_user_id" : "1333062067356532736",
            "id" : "1695472145172951040",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1695472145172951040/pu/img/RhAiL9YGiDmEjMHF.jpg",
            "source_user_id_str" : "1333062067356532736",
            "sizes" : {
              "small" : {
                "w" : "512",
                "h" : "640",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "512",
                "h" : "640",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "512",
                "h" : "640",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1695472170326249834",
            "display_url" : "pic.twitter.com/PNghhy1bWh"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1695590542162243943",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695590542162243943",
      "possibly_sensitive" : false,
      "created_at" : "Sun Aug 27 00:14:22 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @catshouldnt: https://t.co/PNghhy1bWh",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/catshouldnt/status/1695472170326249834/video/1",
            "source_status_id" : "1695472170326249834",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/PNghhy1bWh",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1695472145172951040/pu/img/RhAiL9YGiDmEjMHF.jpg",
            "id_str" : "1695472145172951040",
            "video_info" : {
              "aspect_ratio" : [
                "4",
                "5"
              ],
              "duration_millis" : "14860",
              "variants" : [
                {
                  "bitrate" : "632000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1695472145172951040/pu/vid/320x400/boJV6H_j6m43yJ-N.mp4?tag=12"
                },
                {
                  "bitrate" : "950000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1695472145172951040/pu/vid/512x640/a_yhUEuHjMUS6RZi.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1695472145172951040/pu/pl/mbIODeAWQisrdRp8.m3u8?tag=12&container=fmp4&v=983"
                }
              ]
            },
            "source_user_id" : "1333062067356532736",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1695472145172951040",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1695472145172951040/pu/img/RhAiL9YGiDmEjMHF.jpg",
            "source_user_id_str" : "1333062067356532736",
            "sizes" : {
              "small" : {
                "w" : "512",
                "h" : "640",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "512",
                "h" : "640",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "512",
                "h" : "640",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1695472170326249834",
            "display_url" : "pic.twitter.com/PNghhy1bWh"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695590050384216250"
          ],
          "editableUntil" : "2023-08-27T01:12:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "id_str" : "1695590050384216250",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695590050384216250",
      "created_at" : "Sun Aug 27 00:12:25 +0000 2023",
      "favorited" : false,
      "full_text" : "I feel loved.\n\nI do.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695583894555263127"
          ],
          "editableUntil" : "2023-08-27T00:47:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "3"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1695583788883906857",
      "id_str" : "1695583894555263127",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695583894555263127",
      "in_reply_to_status_id" : "1695583788883906857",
      "created_at" : "Sat Aug 26 23:47:57 +0000 2023",
      "favorited" : false,
      "full_text" : "do*",
      "lang" : "qst",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695583788883906857"
          ],
          "editableUntil" : "2023-08-27T00:47:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "BigGSaidSo",
            "indices" : [
              "94",
              "105"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "id_str" : "1695583788883906857",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695583788883906857",
      "created_at" : "Sat Aug 26 23:47:32 +0000 2023",
      "favorited" : false,
      "full_text" : "I promise you one thing, it's gonna be the most wonderful thing you ever done in your lives.\n\n#BigGSaidSo",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695580690140549390"
          ],
          "editableUntil" : "2023-08-27T00:35:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "1",
      "id_str" : "1695580690140549390",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1695580690140549390",
      "created_at" : "Sat Aug 26 23:35:13 +0000 2023",
      "favorited" : false,
      "full_text" : "You already passed the technical interview.\n\nWanna do the human next step thing?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695375967412207934"
          ],
          "editableUntil" : "2023-08-26T11:01:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1695375967412207934/photo/1",
            "indices" : [
              "16",
              "39"
            ],
            "url" : "https://t.co/zZTlukZyhf",
            "media_url" : "http://pbs.twimg.com/media/F4cvdGjXUAEu6w4.png",
            "id_str" : "1695375961749934081",
            "id" : "1695375961749934081",
            "media_url_https" : "https://pbs.twimg.com/media/F4cvdGjXUAEu6w4.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "475",
                "resize" : "fit"
              },
              "large" : {
                "w" : "791",
                "h" : "553",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "791",
                "h" : "553",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/zZTlukZyhf"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "id_str" : "1695375967412207934",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695375967412207934",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 26 10:01:43 +0000 2023",
      "favorited" : false,
      "full_text" : "dm for t-shirts https://t.co/zZTlukZyhf",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1695375967412207934/photo/1",
            "indices" : [
              "16",
              "39"
            ],
            "url" : "https://t.co/zZTlukZyhf",
            "media_url" : "http://pbs.twimg.com/media/F4cvdGjXUAEu6w4.png",
            "id_str" : "1695375961749934081",
            "id" : "1695375961749934081",
            "media_url_https" : "https://pbs.twimg.com/media/F4cvdGjXUAEu6w4.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "475",
                "resize" : "fit"
              },
              "large" : {
                "w" : "791",
                "h" : "553",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "791",
                "h" : "553",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/zZTlukZyhf"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687131482559537152"
          ],
          "editableUntil" : "2023-08-03T17:01:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Wall Street Silver",
            "screen_name" : "WallStreetSilv",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1366565625401909249",
            "id" : "1366565625401909249"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687122831685894144",
      "id_str" : "1687131482559537152",
      "in_reply_to_user_id" : "1366565625401909249",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687131482559537152",
      "in_reply_to_status_id" : "1687122831685894144",
      "created_at" : "Thu Aug 03 16:01:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@WallStreetSilv Suntan lotion.",
      "lang" : "en",
      "in_reply_to_screen_name" : "WallStreetSilv",
      "in_reply_to_user_id_str" : "1366565625401909249"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687131253760282625"
          ],
          "editableUntil" : "2023-08-03T17:00:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kristijan | Digital Ace",
            "screen_name" : "vilibic",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "4615583081",
            "id" : "4615583081"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1687070819728637952",
      "id_str" : "1687131253760282625",
      "in_reply_to_user_id" : "4615583081",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687131253760282625",
      "in_reply_to_status_id" : "1687070819728637952",
      "created_at" : "Thu Aug 03 16:00:10 +0000 2023",
      "favorited" : false,
      "full_text" : "@vilibic both",
      "lang" : "en",
      "in_reply_to_screen_name" : "vilibic",
      "in_reply_to_user_id_str" : "4615583081"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687131124919660544"
          ],
          "editableUntil" : "2023-08-03T16:59:40.218Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "altcoin",
            "indices" : [
              "24",
              "32"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "id_str" : "1687131124919660544",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687131124919660544",
      "created_at" : "Thu Aug 03 15:59:40 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @yourcryptodj: Which #altcoin will 💯x this week ?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687122416542093312"
          ],
          "editableUntil" : "2023-08-03T16:25:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Katrin Petautschnig",
            "screen_name" : "katrinpetau",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "94978445",
            "id" : "94978445"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1687044135004332033",
      "id_str" : "1687122416542093312",
      "in_reply_to_user_id" : "94978445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687122416542093312",
      "in_reply_to_status_id" : "1687044135004332033",
      "created_at" : "Thu Aug 03 15:25:03 +0000 2023",
      "favorited" : false,
      "full_text" : "@katrinpetau Your stomach tells you.",
      "lang" : "en",
      "in_reply_to_screen_name" : "katrinpetau",
      "in_reply_to_user_id_str" : "94978445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687120564434120704"
          ],
          "editableUntil" : "2023-08-03T16:17:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Klingler",
            "screen_name" : "ethanklingler_",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "836320123522846720",
            "id" : "836320123522846720"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686927242306142208",
      "id_str" : "1687120564434120704",
      "in_reply_to_user_id" : "836320123522846720",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687120564434120704",
      "in_reply_to_status_id" : "1686927242306142208",
      "created_at" : "Thu Aug 03 15:17:42 +0000 2023",
      "favorited" : false,
      "full_text" : "@ethanklingler_ 😅😅😅😅😂🤣",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ethanklingler_",
      "in_reply_to_user_id_str" : "836320123522846720"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687116972306432000"
          ],
          "editableUntil" : "2023-08-03T16:03:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687116551978373120",
      "id_str" : "1687116972306432000",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687116972306432000",
      "in_reply_to_status_id" : "1687116551978373120",
      "created_at" : "Thu Aug 03 15:03:25 +0000 2023",
      "favorited" : false,
      "full_text" : "Not quite the end...\n\nThe thing of it is ... I can't call it Twipod anymore!\n\nARRRGGGHHHHHHH\n\nend)",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687116551978373120"
          ],
          "editableUntil" : "2023-08-03T16:01:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "265"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687115164037046273",
      "id_str" : "1687116551978373120",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687116551978373120",
      "in_reply_to_status_id" : "1687115164037046273",
      "created_at" : "Thu Aug 03 15:01:45 +0000 2023",
      "favorited" : false,
      "full_text" : "It's a great idea. \n\nIt's called Twipod.\n\nAnyone, I'm done with it for now.\n\nI can be like that, I get obsessed with things for a while, and then just switch off completely, forever.\n\nAnything truly important remains with me.\n\nWhat about you?\n\n2) (might be the end)",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687115164037046273"
          ],
          "editableUntil" : "2023-08-03T15:56:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "278"
      ],
      "favorite_count" : "0",
      "id_str" : "1687115164037046273",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687115164037046273",
      "created_at" : "Thu Aug 03 14:56:14 +0000 2023",
      "favorited" : false,
      "full_text" : "I'm planning a Twitter DJ app. \n\nI started work in 22 but needed paid-for enhanced API access, and I'm only at research stage, so I didn't bother.\n\nI'm still tagging tunes, but I never had a developer account. \n\nI lost interest ... really. \n\nI prefer peace.\n\nWhat about you?\n\n1)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687110257418661889"
          ],
          "editableUntil" : "2023-08-03T15:36:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mr Barry Crypto",
            "screen_name" : "MrBarryCrypto",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "190390941",
            "id" : "190390941"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6q6Qt",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686904721544474625",
      "id_str" : "1687110257418661889",
      "in_reply_to_user_id" : "190390941",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687110257418661889",
      "in_reply_to_status_id" : "1686904721544474625",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 03 14:36:45 +0000 2023",
      "favorited" : false,
      "full_text" : "@MrBarryCrypto https://t.co/6JUcz6q6Qt",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MrBarryCrypto",
      "in_reply_to_user_id_str" : "190390941"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687110189739352066"
          ],
          "editableUntil" : "2023-08-03T15:36:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6q6Qt",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687101009682731008",
      "id_str" : "1687110189739352066",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687110189739352066",
      "in_reply_to_status_id" : "1687101009682731008",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 03 14:36:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj https://t.co/6JUcz6q6Qt",
      "lang" : "qme",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687072876573097984"
          ],
          "editableUntil" : "2023-08-03T13:08:12.730Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Paul Hookem 🇺🇸",
            "screen_name" : "PaulHook_em",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2246299058",
            "id" : "2246299058"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "17",
              "26"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/PaulHook_em/status/1686928117112225792/photo/1",
            "source_status_id" : "1686928117112225792",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/bjsYsjTVpp",
            "media_url" : "http://pbs.twimg.com/media/F2ksLrLXoAAFbml.jpg",
            "id_str" : "1686928114507554816",
            "source_user_id" : "2246299058",
            "id" : "1686928114507554816",
            "media_url_https" : "https://pbs.twimg.com/media/F2ksLrLXoAAFbml.jpg",
            "source_user_id_str" : "2246299058",
            "sizes" : {
              "medium" : {
                "w" : "941",
                "h" : "779",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "563",
                "resize" : "fit"
              },
              "large" : {
                "w" : "941",
                "h" : "779",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1686928117112225792",
            "display_url" : "pic.twitter.com/bjsYsjTVpp"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "0",
      "id_str" : "1687072876573097984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687072876573097984",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 03 12:08:12 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @PaulHook_em: @elonmusk https://t.co/bjsYsjTVpp",
      "lang" : "qme",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/PaulHook_em/status/1686928117112225792/photo/1",
            "source_status_id" : "1686928117112225792",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/bjsYsjTVpp",
            "media_url" : "http://pbs.twimg.com/media/F2ksLrLXoAAFbml.jpg",
            "id_str" : "1686928114507554816",
            "source_user_id" : "2246299058",
            "id" : "1686928114507554816",
            "media_url_https" : "https://pbs.twimg.com/media/F2ksLrLXoAAFbml.jpg",
            "source_user_id_str" : "2246299058",
            "sizes" : {
              "medium" : {
                "w" : "941",
                "h" : "779",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "563",
                "resize" : "fit"
              },
              "large" : {
                "w" : "941",
                "h" : "779",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1686928117112225792",
            "display_url" : "pic.twitter.com/bjsYsjTVpp"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687072785883860992"
          ],
          "editableUntil" : "2023-08-03T13:07:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686925930806022146",
      "id_str" : "1687072785883860992",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687072785883860992",
      "in_reply_to_status_id" : "1686925930806022146",
      "created_at" : "Thu Aug 03 12:07:51 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk Are you going to decentralize Twitter (sorry X) I wonder?",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687038587450105856"
          ],
          "editableUntil" : "2023-08-03T10:51:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Neil",
            "screen_name" : "NeilKollipara",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1310905876786688000",
            "id" : "1310905876786688000"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686814125085655040",
      "id_str" : "1687038587450105856",
      "in_reply_to_user_id" : "1310905876786688000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687038587450105856",
      "in_reply_to_status_id" : "1686814125085655040",
      "created_at" : "Thu Aug 03 09:51:57 +0000 2023",
      "favorited" : false,
      "full_text" : "@NeilKollipara Saving the world.",
      "lang" : "en",
      "in_reply_to_screen_name" : "NeilKollipara",
      "in_reply_to_user_id_str" : "1310905876786688000"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687037079811743745"
          ],
          "editableUntil" : "2023-08-03T10:45:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Asaka",
            "screen_name" : "asaka_EIA",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1511069787274817541",
            "id" : "1511069787274817541"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686675080795893760",
      "id_str" : "1687037079811743745",
      "in_reply_to_user_id" : "1511069787274817541",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687037079811743745",
      "in_reply_to_status_id" : "1686675080795893760",
      "created_at" : "Thu Aug 03 09:45:58 +0000 2023",
      "favorited" : false,
      "full_text" : "@asaka_EIA Too busy to read book.",
      "lang" : "en",
      "in_reply_to_screen_name" : "asaka_EIA",
      "in_reply_to_user_id_str" : "1511069787274817541"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687036909405544448"
          ],
          "editableUntil" : "2023-08-03T10:45:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ricky ⚡",
            "screen_name" : "WojtekRicky",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "3420857457",
            "id" : "3420857457"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686681243881218048",
      "id_str" : "1687036909405544448",
      "in_reply_to_user_id" : "3420857457",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687036909405544448",
      "in_reply_to_status_id" : "1686681243881218048",
      "created_at" : "Thu Aug 03 09:45:17 +0000 2023",
      "favorited" : false,
      "full_text" : "@WojtekRicky Yoga",
      "lang" : "in",
      "in_reply_to_screen_name" : "WojtekRicky",
      "in_reply_to_user_id_str" : "3420857457"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686981737321037824"
          ],
          "editableUntil" : "2023-08-03T07:06:03.439Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1686981737321037824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686981737321037824",
      "created_at" : "Thu Aug 03 06:06:03 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: Don't be afraid bruv.\n\nIt's easy once you start.\n\nA simple action you'll never regret...\n\nSay sorry to someone. \n\nUse th…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686979416465805312"
          ],
          "editableUntil" : "2023-08-03T06:56:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686884594061135873",
      "id_str" : "1686979416465805312",
      "in_reply_to_user_id" : "2883228803",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686979416465805312",
      "in_reply_to_status_id" : "1686884594061135873",
      "created_at" : "Thu Aug 03 05:56:50 +0000 2023",
      "favorited" : false,
      "full_text" : "@_david__wright_ France currently.",
      "lang" : "en",
      "in_reply_to_screen_name" : "_david__wright_",
      "in_reply_to_user_id_str" : "2883228803"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686862731498909696"
          ],
          "editableUntil" : "2023-08-02T23:13:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Lessa",
            "screen_name" : "lessaraebiger",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1146546889",
            "id" : "1146546889"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686746874093486081",
      "id_str" : "1686862731498909696",
      "in_reply_to_user_id" : "1146546889",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686862731498909696",
      "in_reply_to_status_id" : "1686746874093486081",
      "created_at" : "Wed Aug 02 22:13:10 +0000 2023",
      "favorited" : false,
      "full_text" : "@lessaraebiger Swine.",
      "lang" : "en",
      "in_reply_to_screen_name" : "lessaraebiger",
      "in_reply_to_user_id_str" : "1146546889"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686853432127135745"
          ],
          "editableUntil" : "2023-08-02T22:36:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Srikar Karra",
            "screen_name" : "thesrikarkarra",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1663221119032197120",
            "id" : "1663221119032197120"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686723456476327936",
      "id_str" : "1686853432127135745",
      "in_reply_to_user_id" : "1663221119032197120",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686853432127135745",
      "in_reply_to_status_id" : "1686723456476327936",
      "created_at" : "Wed Aug 02 21:36:13 +0000 2023",
      "favorited" : false,
      "full_text" : "@thesrikarkarra I also like chess and rapping. \n\nHaven't rapped for decades tho. Wasn't very good :D",
      "lang" : "en",
      "in_reply_to_screen_name" : "thesrikarkarra",
      "in_reply_to_user_id_str" : "1663221119032197120"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686841544240738306"
          ],
          "editableUntil" : "2023-08-02T21:48:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1686841544240738306",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686841544240738306",
      "created_at" : "Wed Aug 02 20:48:58 +0000 2023",
      "favorited" : false,
      "full_text" : "My marketing team is elevated.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686809153375707136"
          ],
          "editableUntil" : "2023-08-02T19:40:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef5haKj",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "163",
              "186"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "186"
      ],
      "favorite_count" : "3",
      "id_str" : "1686809153375707136",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1686809153375707136",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 02 18:40:16 +0000 2023",
      "favorited" : false,
      "full_text" : "Don't be afraid bruv.\n\nIt's easy once you start.\n\nA simple action you'll never regret...\n\nSay sorry to someone. \n\nUse the forgivenet. \n\nReceive crypto in return.\n\nhttps://t.co/Iu5ef5haKj",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686781595087257623"
          ],
          "editableUntil" : "2023-08-02T17:50:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686768722122301441",
      "id_str" : "1686781595087257623",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686781595087257623",
      "in_reply_to_status_id" : "1686768722122301441",
      "created_at" : "Wed Aug 02 16:50:45 +0000 2023",
      "favorited" : false,
      "full_text" : "@StephenKing That's right Steve-o.",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686777171900088321"
          ],
          "editableUntil" : "2023-08-02T17:33:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Richard Kovacs",
            "screen_name" : "rchardkovacs",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1365672371714224128",
            "id" : "1365672371714224128"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686733111114039296",
      "id_str" : "1686777171900088321",
      "in_reply_to_user_id" : "1365672371714224128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686777171900088321",
      "in_reply_to_status_id" : "1686733111114039296",
      "created_at" : "Wed Aug 02 16:33:11 +0000 2023",
      "favorited" : false,
      "full_text" : "@rchardkovacs 😅😅😂😂",
      "lang" : "qme",
      "in_reply_to_screen_name" : "rchardkovacs",
      "in_reply_to_user_id_str" : "1365672371714224128"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686717853758562304"
          ],
          "editableUntil" : "2023-08-02T13:37:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "MB ABDALLAH",
            "screen_name" : "itz_abeee415",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1510358376945012742",
            "id" : "1510358376945012742"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686424549972234249",
      "id_str" : "1686717853758562304",
      "in_reply_to_user_id" : "1510358376945012742",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686717853758562304",
      "in_reply_to_status_id" : "1686424549972234249",
      "created_at" : "Wed Aug 02 12:37:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@itz_abeee415 3-2-1 ...\n\nYou Get What You Pay For!",
      "lang" : "en",
      "in_reply_to_screen_name" : "itz_abeee415",
      "in_reply_to_user_id_str" : "1510358376945012742"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686715853717274624"
          ],
          "editableUntil" : "2023-08-02T13:29:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Richard Kovacs",
            "screen_name" : "rchardkovacs",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1365672371714224128",
            "id" : "1365672371714224128"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1686630731022262272",
      "id_str" : "1686715853717274624",
      "in_reply_to_user_id" : "1365672371714224128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686715853717274624",
      "in_reply_to_status_id" : "1686630731022262272",
      "created_at" : "Wed Aug 02 12:29:31 +0000 2023",
      "favorited" : false,
      "full_text" : "@rchardkovacs street fighting",
      "lang" : "en",
      "in_reply_to_screen_name" : "rchardkovacs",
      "in_reply_to_user_id_str" : "1365672371714224128"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686713238795247616"
          ],
          "editableUntil" : "2023-08-02T13:19:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Satyam Tomar",
            "screen_name" : "satyamwrites",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1629874710971572229",
            "id" : "1629874710971572229"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686617385984229376",
      "id_str" : "1686713238795247616",
      "in_reply_to_user_id" : "1629874710971572229",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686713238795247616",
      "in_reply_to_status_id" : "1686617385984229376",
      "created_at" : "Wed Aug 02 12:19:08 +0000 2023",
      "favorited" : false,
      "full_text" : "@satyamwrites true that dude",
      "lang" : "en",
      "in_reply_to_screen_name" : "satyamwrites",
      "in_reply_to_user_id_str" : "1629874710971572229"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686664190503641088"
          ],
          "editableUntil" : "2023-08-02T10:04:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686345289286754304",
      "id_str" : "1686664190503641088",
      "in_reply_to_user_id" : "2883228803",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686664190503641088",
      "in_reply_to_status_id" : "1686345289286754304",
      "created_at" : "Wed Aug 02 09:04:14 +0000 2023",
      "favorited" : false,
      "full_text" : "@_david__wright_ Working on ChatGPT to convert my web app to Android. \n\nWhat would have taken me months to figure out, I did in a morning!",
      "lang" : "en",
      "in_reply_to_screen_name" : "_david__wright_",
      "in_reply_to_user_id_str" : "2883228803"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686664184103157762"
          ],
          "editableUntil" : "2023-08-02T10:04:12.852Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "buildinpublic",
            "indices" : [
              "86",
              "100"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "0",
      "id_str" : "1686664184103157762",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686664184103157762",
      "created_at" : "Wed Aug 02 09:04:12 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @_david__wright_: Let's have a coffee break, tell me what you've been up to today? #buildinpublic",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686648287326031872"
          ],
          "editableUntil" : "2023-08-02T09:01:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686548630323228672",
      "id_str" : "1686648287326031872",
      "in_reply_to_user_id" : "2883228803",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686648287326031872",
      "in_reply_to_status_id" : "1686548630323228672",
      "created_at" : "Wed Aug 02 08:01:02 +0000 2023",
      "favorited" : false,
      "full_text" : "@_david__wright_ both",
      "lang" : "en",
      "in_reply_to_screen_name" : "_david__wright_",
      "in_reply_to_user_id_str" : "2883228803"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686641641434591232"
          ],
          "editableUntil" : "2023-08-02T08:34:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686351078680383488",
      "id_str" : "1686641641434591232",
      "in_reply_to_user_id" : "2883228803",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686641641434591232",
      "in_reply_to_status_id" : "1686351078680383488",
      "created_at" : "Wed Aug 02 07:34:38 +0000 2023",
      "favorited" : false,
      "full_text" : "@_david__wright_ Hi David, I'm web3 crypto CEO &lt;3",
      "lang" : "en",
      "in_reply_to_screen_name" : "_david__wright_",
      "in_reply_to_user_id_str" : "2883228803"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686488932664446976"
          ],
          "editableUntil" : "2023-08-01T22:27:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Thor | Kirito",
            "screen_name" : "Thorshammergems",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1484117053892141056",
            "id" : "1484117053892141056"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "17",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686436921612914717",
      "id_str" : "1686488932664446976",
      "in_reply_to_user_id" : "1484117053892141056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686488932664446976",
      "in_reply_to_status_id" : "1686436921612914717",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 21:27:49 +0000 2023",
      "favorited" : false,
      "full_text" : "@Thorshammergems https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Thorshammergems",
      "in_reply_to_user_id_str" : "1484117053892141056"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686482359267299328"
          ],
          "editableUntil" : "2023-08-01T22:01:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "217"
      ],
      "favorite_count" : "0",
      "id_str" : "1686482359267299328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686482359267299328",
      "created_at" : "Tue Aug 01 21:01:42 +0000 2023",
      "favorited" : false,
      "full_text" : "Did you know ... \n\n... you are more likely to win the lottery every day for the rest of your life than ...\n\n... the likelihood of the moon being exactly the right size to cover the earth for total solar eclipses.\n\n🫨😲🤯",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686481485719621632"
          ],
          "editableUntil" : "2023-08-01T21:58:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Catalin",
            "screen_name" : "catalinmpit",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "173057927",
            "id" : "173057927"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686027262196371456",
      "id_str" : "1686481485719621632",
      "in_reply_to_user_id" : "173057927",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686481485719621632",
      "in_reply_to_status_id" : "1686027262196371456",
      "created_at" : "Tue Aug 01 20:58:14 +0000 2023",
      "favorited" : false,
      "full_text" : "@catalinmpit Totally unfair.",
      "lang" : "en",
      "in_reply_to_screen_name" : "catalinmpit",
      "in_reply_to_user_id_str" : "173057927"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686465113946042369"
          ],
          "editableUntil" : "2023-08-01T20:53:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Fox Crypto",
            "screen_name" : "FoxCryptoBSC",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "419697640",
            "id" : "419697640"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686383532040470528",
      "id_str" : "1686465113946042369",
      "in_reply_to_user_id" : "419697640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686465113946042369",
      "in_reply_to_status_id" : "1686383532040470528",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 19:53:10 +0000 2023",
      "favorited" : false,
      "full_text" : "@FoxCryptoBSC https://t.co/6JUcz6pz0V of course",
      "lang" : "en",
      "in_reply_to_screen_name" : "FoxCryptoBSC",
      "in_reply_to_user_id_str" : "419697640"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686388188053749760"
          ],
          "editableUntil" : "2023-08-01T15:47:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CetoEX",
            "screen_name" : "Cetoex",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1506274530725040128",
            "id" : "1506274530725040128"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6q6Qt",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "8",
              "31"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686317579626061824",
      "id_str" : "1686388188053749760",
      "in_reply_to_user_id" : "1506274530725040128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686388188053749760",
      "in_reply_to_status_id" : "1686317579626061824",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 14:47:30 +0000 2023",
      "favorited" : false,
      "full_text" : "@Cetoex https://t.co/6JUcz6q6Qt",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Cetoex",
      "in_reply_to_user_id_str" : "1506274530725040128"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686387731327586304"
          ],
          "editableUntil" : "2023-08-01T15:45:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sofia Zamolo",
            "screen_name" : "sofizamolo",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "153243904",
            "id" : "153243904"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6q6Qt",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686341983692849155",
      "id_str" : "1686387731327586304",
      "in_reply_to_user_id" : "153243904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686387731327586304",
      "in_reply_to_status_id" : "1686341983692849155",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 14:45:41 +0000 2023",
      "favorited" : false,
      "full_text" : "@sofizamolo https://t.co/6JUcz6q6Qt",
      "lang" : "qme",
      "in_reply_to_screen_name" : "sofizamolo",
      "in_reply_to_user_id_str" : "153243904"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686370594579714048"
          ],
          "editableUntil" : "2023-08-01T14:37:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686369546003718144",
      "id_str" : "1686370594579714048",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686370594579714048",
      "in_reply_to_status_id" : "1686369546003718144",
      "created_at" : "Tue Aug 01 13:37:35 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk That's right. Is it like that for your employees I wonder?",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686370516372783104"
          ],
          "editableUntil" : "2023-08-01T14:37:17.009Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1686370516372783104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686370516372783104",
      "created_at" : "Tue Aug 01 13:37:17 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @elonmusk: Unless there are a few issues where you at least slightly disagree with your political party, then you are not in a political…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686363969462669312"
          ],
          "editableUntil" : "2023-08-01T14:11:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "JAKE",
            "screen_name" : "JakeGagain",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1355014327988707329",
            "id" : "1355014327988707329"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686336723817476097",
      "id_str" : "1686363969462669312",
      "in_reply_to_user_id" : "1355014327988707329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686363969462669312",
      "in_reply_to_status_id" : "1686336723817476097",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 13:11:16 +0000 2023",
      "favorited" : false,
      "full_text" : "@JakeGagain https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "JakeGagain",
      "in_reply_to_user_id_str" : "1355014327988707329"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686347127750828033"
          ],
          "editableUntil" : "2023-08-01T13:04:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mr Barry Crypto",
            "screen_name" : "MrBarryCrypto",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "190390941",
            "id" : "190390941"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686300744042131456",
      "id_str" : "1686347127750828033",
      "in_reply_to_user_id" : "190390941",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686347127750828033",
      "in_reply_to_status_id" : "1686300744042131456",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 12:04:20 +0000 2023",
      "favorited" : false,
      "full_text" : "@MrBarryCrypto https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MrBarryCrypto",
      "in_reply_to_user_id_str" : "190390941"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686347037128753154"
          ],
          "editableUntil" : "2023-08-01T13:03:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Francesco",
            "screen_name" : "FrancescoCiull4",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1704118916",
            "id" : "1704118916"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1686294365012946946",
      "id_str" : "1686347037128753154",
      "in_reply_to_user_id" : "1704118916",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686347037128753154",
      "in_reply_to_status_id" : "1686294365012946946",
      "created_at" : "Tue Aug 01 12:03:59 +0000 2023",
      "favorited" : false,
      "full_text" : "@FrancescoCiull4 They must be male.",
      "lang" : "en",
      "in_reply_to_screen_name" : "FrancescoCiull4",
      "in_reply_to_user_id_str" : "1704118916"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686345256692752385"
          ],
          "editableUntil" : "2023-08-01T12:56:54.632Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Rizk - Orthopaedic Surgeon 🇱🇧 🇺🇸",
            "screen_name" : "RobinRizk",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "328669891",
            "id" : "328669891"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/urLC43eS4N",
            "expanded_url" : "https://t.me/cryptomedic",
            "display_url" : "t.me/cryptomedic",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "0",
      "id_str" : "1686345256692752385",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686345256692752385",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 11:56:54 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @RobinRizk: https://t.co/urLC43eS4N\n\nHelping our dear crypto community with the thing I do best ❤️",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686280295048187905"
          ],
          "editableUntil" : "2023-08-01T08:38:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "forgiveness",
            "indices" : [
              "14",
              "26"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Fox Crypto",
            "screen_name" : "FoxCryptoBSC",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "419697640",
            "id" : "419697640"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "28",
              "51"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686074782763139075",
      "id_str" : "1686280295048187905",
      "in_reply_to_user_id" : "419697640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686280295048187905",
      "in_reply_to_status_id" : "1686074782763139075",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 07:38:46 +0000 2023",
      "favorited" : false,
      "full_text" : "@FoxCryptoBSC #forgiveness\n\nhttps://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "FoxCryptoBSC",
      "in_reply_to_user_id_str" : "419697640"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686279768482680833"
          ],
          "editableUntil" : "2023-08-01T08:36:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686255443629477888",
      "id_str" : "1686279768482680833",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686279768482680833",
      "in_reply_to_status_id" : "1686255443629477888",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 01 07:36:41 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686135601454530561"
          ],
          "editableUntil" : "2023-07-31T23:03:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "WHALE 🐳 EVERYTHING",
            "screen_name" : "WhaleEverything",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1476262356019814411",
            "id" : "1476262356019814411"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "17",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685969206297112577",
      "id_str" : "1686135601454530561",
      "in_reply_to_user_id" : "1476262356019814411",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686135601454530561",
      "in_reply_to_status_id" : "1685969206297112577",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 22:03:48 +0000 2023",
      "favorited" : false,
      "full_text" : "@WhaleEverything https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "WhaleEverything",
      "in_reply_to_user_id_str" : "1476262356019814411"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686135467526201344"
          ],
          "editableUntil" : "2023-07-31T23:03:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "100x Altcoin Gems",
            "screen_name" : "100xAltcoinGems",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1517796456949817347",
            "id" : "1517796456949817347"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "17",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686091105417490432",
      "id_str" : "1686135467526201344",
      "in_reply_to_user_id" : "1517796456949817347",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686135467526201344",
      "in_reply_to_status_id" : "1686091105417490432",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 22:03:16 +0000 2023",
      "favorited" : false,
      "full_text" : "@100xAltcoinGems https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "100xAltcoinGems",
      "in_reply_to_user_id_str" : "1517796456949817347"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686135421183426560"
          ],
          "editableUntil" : "2023-07-31T23:03:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686104447301345285",
      "id_str" : "1686135421183426560",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686135421183426560",
      "in_reply_to_status_id" : "1686104447301345285",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 22:03:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686134693693906944"
          ],
          "editableUntil" : "2023-07-31T23:00:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Riccardo Bossio",
            "screen_name" : "riccardogems",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "369645502",
            "id" : "369645502"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685928163166048256",
      "id_str" : "1686134693693906944",
      "in_reply_to_user_id" : "369645502",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686134693693906944",
      "in_reply_to_status_id" : "1685928163166048256",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 22:00:12 +0000 2023",
      "favorited" : false,
      "full_text" : "@riccardogems https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "riccardogems",
      "in_reply_to_user_id_str" : "369645502"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686134619437944832"
          ],
          "editableUntil" : "2023-07-31T22:59:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686048217853505536",
      "id_str" : "1686134619437944832",
      "in_reply_to_user_id" : "1435742528326746118",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686134619437944832",
      "in_reply_to_status_id" : "1686048217853505536",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 21:59:54 +0000 2023",
      "favorited" : false,
      "full_text" : "@realCryptorich https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "notlessCrypto",
      "in_reply_to_user_id_str" : "1435742528326746118"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686134472360476672"
          ],
          "editableUntil" : "2023-07-31T22:59:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SlumDOGE Millionaire",
            "screen_name" : "ProTheDoge",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1358176095850229761",
            "id" : "1358176095850229761"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686078639111364608",
      "id_str" : "1686134472360476672",
      "in_reply_to_user_id" : "1358176095850229761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686134472360476672",
      "in_reply_to_status_id" : "1686078639111364608",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 21:59:19 +0000 2023",
      "favorited" : false,
      "full_text" : "@ProTheDoge https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ProTheDoge",
      "in_reply_to_user_id_str" : "1358176095850229761"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686134414139441153"
          ],
          "editableUntil" : "2023-07-31T22:59:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CryptoJack",
            "screen_name" : "cryptojack",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1415997802321256453",
            "id" : "1415997802321256453"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686089475342888960",
      "id_str" : "1686134414139441153",
      "in_reply_to_user_id" : "1415997802321256453",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686134414139441153",
      "in_reply_to_status_id" : "1686089475342888960",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 21:59:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@cryptojack https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "cryptojack",
      "in_reply_to_user_id_str" : "1415997802321256453"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686134343587057671"
          ],
          "editableUntil" : "2023-07-31T22:58:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685964053699588096",
      "id_str" : "1686134343587057671",
      "in_reply_to_user_id" : "2613358347",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686134343587057671",
      "in_reply_to_status_id" : "1685964053699588096",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 21:58:49 +0000 2023",
      "favorited" : false,
      "full_text" : "@LordOfGems_ https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "samcriscolo",
      "in_reply_to_user_id_str" : "2613358347"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686115656167567360"
          ],
          "editableUntil" : "2023-07-31T21:44:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Peter Simeonov",
            "screen_name" : "PeterKSimeonov",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1272991981032046605",
            "id" : "1272991981032046605"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685970097557454853",
      "id_str" : "1686115656167567360",
      "in_reply_to_user_id" : "1272991981032046605",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686115656167567360",
      "in_reply_to_status_id" : "1685970097557454853",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 20:44:33 +0000 2023",
      "favorited" : false,
      "full_text" : "@PeterKSimeonov https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "PeterKSimeonov",
      "in_reply_to_user_id_str" : "1272991981032046605"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686115595161333760"
          ],
          "editableUntil" : "2023-07-31T21:44:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Lourdes",
            "screen_name" : "lourdesanchezok",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "292097834",
            "id" : "292097834"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "17",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685951488957325313",
      "id_str" : "1686115595161333760",
      "in_reply_to_user_id" : "292097834",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686115595161333760",
      "in_reply_to_status_id" : "1685951488957325313",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 20:44:19 +0000 2023",
      "favorited" : false,
      "full_text" : "@lourdesanchezok https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "lourdesanchezok",
      "in_reply_to_user_id_str" : "292097834"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686115548906606592"
          ],
          "editableUntil" : "2023-07-31T21:44:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686074245942558724",
      "id_str" : "1686115548906606592",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686115548906606592",
      "in_reply_to_status_id" : "1686074245942558724",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 20:44:08 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686115391041310720"
          ],
          "editableUntil" : "2023-07-31T21:43:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CryptoJack",
            "screen_name" : "cryptojack",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1415997802321256453",
            "id" : "1415997802321256453"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686029159712116736",
      "id_str" : "1686115391041310720",
      "in_reply_to_user_id" : "1415997802321256453",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686115391041310720",
      "in_reply_to_status_id" : "1686029159712116736",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 20:43:30 +0000 2023",
      "favorited" : false,
      "full_text" : "@cryptojack https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "cryptojack",
      "in_reply_to_user_id_str" : "1415997802321256453"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686115074245554176"
          ],
          "editableUntil" : "2023-07-31T21:42:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jazmin Pinedo",
            "screen_name" : "jazminpinedo",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "239241254",
            "id" : "239241254"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685925439028461568",
      "id_str" : "1686115074245554176",
      "in_reply_to_user_id" : "239241254",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686115074245554176",
      "in_reply_to_status_id" : "1685925439028461568",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 20:42:14 +0000 2023",
      "favorited" : false,
      "full_text" : "@jazminpinedo https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "jazminpinedo",
      "in_reply_to_user_id_str" : "239241254"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686114975356477445"
          ],
          "editableUntil" : "2023-07-31T21:41:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sofia Zamolo",
            "screen_name" : "sofizamolo",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "153243904",
            "id" : "153243904"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1686003461421158401",
      "id_str" : "1686114975356477445",
      "in_reply_to_user_id" : "153243904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686114975356477445",
      "in_reply_to_status_id" : "1686003461421158401",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 20:41:51 +0000 2023",
      "favorited" : false,
      "full_text" : "@sofizamolo https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "sofizamolo",
      "in_reply_to_user_id_str" : "153243904"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686094836812640256"
          ],
          "editableUntil" : "2023-07-31T20:21:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "0",
      "id_str" : "1686094836812640256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686094836812640256",
      "created_at" : "Mon Jul 31 19:21:49 +0000 2023",
      "favorited" : false,
      "full_text" : "Hi new followers.\n\nI post about crypto and forgiveness and everything in between.\n\n&lt;3",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686045019734503424"
          ],
          "editableUntil" : "2023-07-31T17:03:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mr. BIG WHALE",
            "screen_name" : "MrBigWhaleREAL",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1415324327113805830",
            "id" : "1415324327113805830"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685990504876683264",
      "id_str" : "1686045019734503424",
      "in_reply_to_user_id" : "1415324327113805830",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686045019734503424",
      "in_reply_to_status_id" : "1685990504876683264",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 16:03:52 +0000 2023",
      "favorited" : false,
      "full_text" : "@MrBigWhaleREAL https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MrBigWhaleREAL",
      "in_reply_to_user_id_str" : "1415324327113805830"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686038996026089473"
          ],
          "editableUntil" : "2023-07-31T16:39:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SlumDOGE Millionaire",
            "screen_name" : "ProTheDoge",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1358176095850229761",
            "id" : "1358176095850229761"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685830731011141634",
      "id_str" : "1686038996026089473",
      "in_reply_to_user_id" : "1358176095850229761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686038996026089473",
      "in_reply_to_status_id" : "1685830731011141634",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 15:39:56 +0000 2023",
      "favorited" : false,
      "full_text" : "@ProTheDoge https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ProTheDoge",
      "in_reply_to_user_id_str" : "1358176095850229761"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686012030166110208"
          ],
          "editableUntil" : "2023-07-31T14:52:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "1686012030166110208",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686012030166110208",
      "created_at" : "Mon Jul 31 13:52:47 +0000 2023",
      "favorited" : false,
      "full_text" : "Bots crack me up.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686000393191362560"
          ],
          "editableUntil" : "2023-07-31T14:06:32.766Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "altcoin",
            "indices" : [
              "42",
              "50"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Altcoin Daily",
            "screen_name" : "AltcoinDailyio",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "958118843636854784",
            "id" : "958118843636854784"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "id_str" : "1686000393191362560",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686000393191362560",
      "created_at" : "Mon Jul 31 13:06:32 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @AltcoinDailyio: Shill me your biggest #altcoin holding! 💪 🚀 💎",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1686000368281419777"
          ],
          "editableUntil" : "2023-07-31T14:06:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Altcoin Daily",
            "screen_name" : "AltcoinDailyio",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "958118843636854784",
            "id" : "958118843636854784"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685961249647898624",
      "id_str" : "1686000368281419777",
      "in_reply_to_user_id" : "958118843636854784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1686000368281419777",
      "in_reply_to_status_id" : "1685961249647898624",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 31 13:06:26 +0000 2023",
      "favorited" : false,
      "full_text" : "@AltcoinDailyio https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "AltcoinDailyio",
      "in_reply_to_user_id_str" : "958118843636854784"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685933815691083776"
          ],
          "editableUntil" : "2023-07-31T09:41:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Pedro Sanders",
            "screen_name" : "pedrosanders_",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "739107184148107264",
            "id" : "739107184148107264"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685649766162604032",
      "id_str" : "1685933815691083776",
      "in_reply_to_user_id" : "739107184148107264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685933815691083776",
      "in_reply_to_status_id" : "1685649766162604032",
      "created_at" : "Mon Jul 31 08:41:59 +0000 2023",
      "favorited" : false,
      "full_text" : "@pedrosanders_ Correcto.",
      "lang" : "es",
      "in_reply_to_screen_name" : "pedrosanders_",
      "in_reply_to_user_id_str" : "739107184148107264"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685933358742671360"
          ],
          "editableUntil" : "2023-07-31T09:40:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "14"
      ],
      "favorite_count" : "0",
      "id_str" : "1685933358742671360",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685933358742671360",
      "created_at" : "Mon Jul 31 08:40:10 +0000 2023",
      "favorited" : false,
      "full_text" : "🙈 🙉 🙊 .... 🐒🐒🐵",
      "lang" : "art"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685801146928001024"
          ],
          "editableUntil" : "2023-07-31T00:54:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mr. BIG WHALE",
            "screen_name" : "MrBigWhaleREAL",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1415324327113805830",
            "id" : "1415324327113805830"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef5haKj",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1685663275168743424",
      "id_str" : "1685801146928001024",
      "in_reply_to_user_id" : "1415324327113805830",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685801146928001024",
      "in_reply_to_status_id" : "1685663275168743424",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 30 23:54:48 +0000 2023",
      "favorited" : false,
      "full_text" : "@MrBigWhaleREAL https://t.co/Iu5ef5haKj",
      "lang" : "qme",
      "in_reply_to_screen_name" : "MrBigWhaleREAL",
      "in_reply_to_user_id_str" : "1415324327113805830"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685799620813750273"
          ],
          "editableUntil" : "2023-07-31T00:48:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CoinGecko",
            "screen_name" : "coingecko",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "2412652615",
            "id" : "2412652615"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685613709497110529",
      "id_str" : "1685799620813750273",
      "in_reply_to_user_id" : "2412652615",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685799620813750273",
      "in_reply_to_status_id" : "1685613709497110529",
      "created_at" : "Sun Jul 30 23:48:44 +0000 2023",
      "favorited" : false,
      "full_text" : "@coingecko FRGVN",
      "lang" : "vi",
      "in_reply_to_screen_name" : "coingecko",
      "in_reply_to_user_id_str" : "2412652615"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685797854890037248"
          ],
          "editableUntil" : "2023-07-31T00:41:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/KbUMGsUGRk",
            "expanded_url" : "https://www.youtube.com/watch?v=jvujypVVBAY",
            "display_url" : "youtube.com/watch?v=jvujyp…",
            "indices" : [
              "9",
              "32"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "id_str" : "1685797854890037248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685797854890037248",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 30 23:41:43 +0000 2023",
      "favorited" : false,
      "full_text" : "STOP IT\n\nhttps://t.co/KbUMGsUGRk",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685795729246175232"
          ],
          "editableUntil" : "2023-07-31T00:33:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1685795729246175232",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685795729246175232",
      "created_at" : "Sun Jul 30 23:33:17 +0000 2023",
      "favorited" : false,
      "full_text" : "Stop it. Just stop it.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685756121951154177"
          ],
          "editableUntil" : "2023-07-30T21:55:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1685756121951154177",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685756121951154177",
      "created_at" : "Sun Jul 30 20:55:53 +0000 2023",
      "favorited" : false,
      "full_text" : "Are y'all stalking me here too? I wonder..",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685647190784438274"
          ],
          "editableUntil" : "2023-07-30T14:43:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk (Parody)",
            "screen_name" : "ElonMuskAOC",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1382209054999646212",
            "id" : "1382209054999646212"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685399134701015040",
      "id_str" : "1685647190784438274",
      "in_reply_to_user_id" : "1382209054999646212",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685647190784438274",
      "in_reply_to_status_id" : "1685399134701015040",
      "created_at" : "Sun Jul 30 13:43:02 +0000 2023",
      "favorited" : false,
      "full_text" : "@ElonMuskAOC Hopefully it involves my FOMO DOGE becoming extremely valuable.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ElonMuskAOC",
      "in_reply_to_user_id_str" : "1382209054999646212"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1685402690417811456"
          ],
          "editableUntil" : "2023-07-29T22:31:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1685048326213828608",
      "id_str" : "1685402690417811456",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1685402690417811456",
      "in_reply_to_status_id" : "1685048326213828608",
      "created_at" : "Sat Jul 29 21:31:29 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk Fwoar!",
      "lang" : "de",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1684828073059905536"
          ],
          "editableUntil" : "2023-07-28T08:28:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1684585441947947008",
      "id_str" : "1684828073059905536",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1684828073059905536",
      "in_reply_to_status_id" : "1684585441947947008",
      "created_at" : "Fri Jul 28 07:28:09 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk ..pass me Friday's implant please",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1684662703183298560"
          ],
          "editableUntil" : "2023-07-27T21:31:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Catalin",
            "screen_name" : "catalinmpit",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "173057927",
            "id" : "173057927"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1684619608873984002",
      "id_str" : "1684662703183298560",
      "in_reply_to_user_id" : "173057927",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1684662703183298560",
      "in_reply_to_status_id" : "1684619608873984002",
      "created_at" : "Thu Jul 27 20:31:02 +0000 2023",
      "favorited" : false,
      "full_text" : "@catalinmpit I'm heading back in that direction.",
      "lang" : "en",
      "in_reply_to_screen_name" : "catalinmpit",
      "in_reply_to_user_id_str" : "173057927"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1684660293547274240"
          ],
          "editableUntil" : "2023-07-27T21:21:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "0",
      "id_str" : "1684660293547274240",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1684660293547274240",
      "created_at" : "Thu Jul 27 20:21:28 +0000 2023",
      "favorited" : false,
      "full_text" : "Real software engineers are men.\n\n(this is satire, btw, if anyone was in any doubt)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1684660137342963712"
          ],
          "editableUntil" : "2023-07-27T21:20:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Abhinav Pandey 🍀",
            "screen_name" : "Abh1navv",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1451297084",
            "id" : "1451297084"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1684604680637480962",
      "id_str" : "1684660137342963712",
      "in_reply_to_user_id" : "1451297084",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1684660137342963712",
      "in_reply_to_status_id" : "1684604680637480962",
      "created_at" : "Thu Jul 27 20:20:50 +0000 2023",
      "favorited" : false,
      "full_text" : "@Abh1navv 😂😂🤣🤣🤣",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Abh1navv",
      "in_reply_to_user_id_str" : "1451297084"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1684659887752540160"
          ],
          "editableUntil" : "2023-07-27T21:19:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kevin Naughton Jr.",
            "screen_name" : "KevinNaughtonJr",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1045398019351425026",
            "id" : "1045398019351425026"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1684298714205093891",
      "id_str" : "1684659887752540160",
      "in_reply_to_user_id" : "1045398019351425026",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1684659887752540160",
      "in_reply_to_status_id" : "1684298714205093891",
      "created_at" : "Thu Jul 27 20:19:51 +0000 2023",
      "favorited" : false,
      "full_text" : "@KevinNaughtonJr especially the incels",
      "lang" : "en",
      "in_reply_to_screen_name" : "KevinNaughtonJr",
      "in_reply_to_user_id_str" : "1045398019351425026"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1684464326604738560"
          ],
          "editableUntil" : "2023-07-27T08:22:45.953Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kevin Naughton Jr.",
            "screen_name" : "KevinNaughtonJr",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "1045398019351425026",
            "id" : "1045398019351425026"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "id_str" : "1684464326604738560",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1684464326604738560",
      "created_at" : "Thu Jul 27 07:22:45 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @KevinNaughtonJr: AI will replace all software engineers",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1684232174944264192"
          ],
          "editableUntil" : "2023-07-26T17:00:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Forge",
            "screen_name" : "TheJackForge",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1246452518508355584",
            "id" : "1246452518508355584"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1684188458410180608",
      "id_str" : "1684232174944264192",
      "in_reply_to_user_id" : "1246452518508355584",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1684232174944264192",
      "in_reply_to_status_id" : "1684188458410180608",
      "created_at" : "Wed Jul 26 16:00:16 +0000 2023",
      "favorited" : false,
      "full_text" : "@TheJackForge I like Python.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TheJackForge",
      "in_reply_to_user_id_str" : "1246452518508355584"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1683594775142727680"
          ],
          "editableUntil" : "2023-07-24T22:47:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk (Parody)",
            "screen_name" : "ElonMuskAOC",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1382209054999646212",
            "id" : "1382209054999646212"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1683540647138172928",
      "id_str" : "1683594775142727680",
      "in_reply_to_user_id" : "1382209054999646212",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1683594775142727680",
      "in_reply_to_status_id" : "1683540647138172928",
      "created_at" : "Mon Jul 24 21:47:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@ElonMuskAOC marksthespot",
      "lang" : "da",
      "in_reply_to_screen_name" : "ElonMuskAOC",
      "in_reply_to_user_id_str" : "1382209054999646212"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1683534308168876032"
          ],
          "editableUntil" : "2023-07-24T18:47:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sawyer Merritt",
            "screen_name" : "SawyerMerritt",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "243013409",
            "id" : "243013409"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1683365478582951936",
      "id_str" : "1683534308168876032",
      "in_reply_to_user_id" : "243013409",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1683534308168876032",
      "in_reply_to_status_id" : "1683365478582951936",
      "created_at" : "Mon Jul 24 17:47:12 +0000 2023",
      "favorited" : false,
      "full_text" : "@SawyerMerritt Xeets (pronounced as expected)",
      "lang" : "en",
      "in_reply_to_screen_name" : "SawyerMerritt",
      "in_reply_to_user_id_str" : "243013409"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1683092795634982914"
          ],
          "editableUntil" : "2023-07-23T13:32:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1682964919325724673",
      "id_str" : "1683092795634982914",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1683092795634982914",
      "in_reply_to_status_id" : "1682964919325724673",
      "created_at" : "Sun Jul 23 12:32:47 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk no no no no no",
      "lang" : "es",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1683092561399775233"
          ],
          "editableUntil" : "2023-07-23T13:31:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1682945360572948484",
      "id_str" : "1683092561399775233",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1683092561399775233",
      "in_reply_to_status_id" : "1682945360572948484",
      "created_at" : "Sun Jul 23 12:31:51 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk And if there are aliens, then there's a few more tiny candles in your abyss of darkness.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1675234376643117057"
          ],
          "editableUntil" : "2023-07-01T21:06:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "46",
              "55"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "id_str" : "1675234376643117057",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1675234376643117057",
      "created_at" : "Sat Jul 01 20:06:14 +0000 2023",
      "favorited" : false,
      "full_text" : "The only way to get data off here is scraping @elonmusk cos the API's so shite.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1675210980165287939"
          ],
          "editableUntil" : "2023-07-01T19:33:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1675210005073600512",
      "id_str" : "1675210980165287939",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1675210980165287939",
      "in_reply_to_status_id" : "1675210005073600512",
      "created_at" : "Sat Jul 01 18:33:16 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk REVERT REVERT UNDO",
      "lang" : "es",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1675078714059571200"
          ],
          "editableUntil" : "2023-07-01T10:47:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "gbae the app developer",
            "screen_name" : "daboigbae",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "923587339150118912",
            "id" : "923587339150118912"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "12"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1674764969731317760",
      "id_str" : "1675078714059571200",
      "in_reply_to_user_id" : "923587339150118912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1675078714059571200",
      "in_reply_to_status_id" : "1674764969731317760",
      "created_at" : "Sat Jul 01 09:47:41 +0000 2023",
      "favorited" : false,
      "full_text" : "@daboigbae 7",
      "lang" : "und",
      "in_reply_to_screen_name" : "daboigbae",
      "in_reply_to_user_id_str" : "923587339150118912"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1675078199452024832"
          ],
          "editableUntil" : "2023-07-01T10:45:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Eddie Jaoude | EddieHub | Open Source GitHub Star",
            "screen_name" : "eddiejaoude",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "151130284",
            "id" : "151130284"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1675048854406742016",
      "id_str" : "1675078199452024832",
      "in_reply_to_user_id" : "151130284",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1675078199452024832",
      "in_reply_to_status_id" : "1675048854406742016",
      "created_at" : "Sat Jul 01 09:45:38 +0000 2023",
      "favorited" : false,
      "full_text" : "@eddiejaoude Men.",
      "lang" : "und",
      "in_reply_to_screen_name" : "eddiejaoude",
      "in_reply_to_user_id_str" : "151130284"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1663938785535565824"
          ],
          "editableUntil" : "2023-05-31T16:31:35.616Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Wall Street Silver",
            "screen_name" : "WallStreetSilv",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "1366565625401909249",
            "id" : "1366565625401909249"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/WallStreetSilv/status/1663711901484822530/video/1",
            "source_status_id" : "1663711901484822530",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/zKTW5Uyh5s",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1663701267200237572/pu/img/lbXzKQQEztuMBGov.jpg",
            "id_str" : "1663701267200237572",
            "source_user_id" : "1366565625401909249",
            "id" : "1663701267200237572",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1663701267200237572/pu/img/lbXzKQQEztuMBGov.jpg",
            "source_user_id_str" : "1366565625401909249",
            "sizes" : {
              "medium" : {
                "w" : "406",
                "h" : "720",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "406",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1663711901484822530",
            "display_url" : "pic.twitter.com/zKTW5Uyh5s"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "1663938785535565824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1663938785535565824",
      "possibly_sensitive" : false,
      "created_at" : "Wed May 31 16:01:35 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @WallStreetSilv: The staggering number of people trying to summit Mt. Everest 🤨\n\n🔊 https://t.co/zKTW5Uyh5s",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/WallStreetSilv/status/1663711901484822530/video/1",
            "source_status_id" : "1663711901484822530",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/zKTW5Uyh5s",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1663701267200237572/pu/img/lbXzKQQEztuMBGov.jpg",
            "id_str" : "1663701267200237572",
            "video_info" : {
              "aspect_ratio" : [
                "203",
                "360"
              ],
              "duration_millis" : "54675",
              "variants" : [
                {
                  "bitrate" : "950000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1663701267200237572/pu/vid/406x720/jaoL92dGxTj61nlW.mp4?tag=12"
                },
                {
                  "bitrate" : "632000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1663701267200237572/pu/vid/320x566/HqTMR7xkE6iOlUWZ.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1663701267200237572/pu/pl/Tr6M8U8oF6kJ1Lxj.m3u8?tag=12&container=fmp4"
                }
              ]
            },
            "source_user_id" : "1366565625401909249",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1663701267200237572",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1663701267200237572/pu/img/lbXzKQQEztuMBGov.jpg",
            "source_user_id_str" : "1366565625401909249",
            "sizes" : {
              "medium" : {
                "w" : "406",
                "h" : "720",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "406",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1663711901484822530",
            "display_url" : "pic.twitter.com/zKTW5Uyh5s"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1659810955847409664"
          ],
          "editableUntil" : "2023-05-20T07:09:04.327Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "unusual_whales",
            "screen_name" : "unusual_whales",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "1200616796295847936",
            "id" : "1200616796295847936"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/unusual_whales/status/1659779682093645824/photo/1",
            "source_status_id" : "1659779682093645824",
            "indices" : [
              "46",
              "69"
            ],
            "url" : "https://t.co/TjmIWwqjoI",
            "media_url" : "http://pbs.twimg.com/media/Fwi4puMWcAAKwt8.jpg",
            "id_str" : "1659779489600008192",
            "source_user_id" : "1200616796295847936",
            "id" : "1659779489600008192",
            "media_url_https" : "https://pbs.twimg.com/media/Fwi4puMWcAAKwt8.jpg",
            "source_user_id_str" : "1200616796295847936",
            "sizes" : {
              "large" : {
                "w" : "828",
                "h" : "1792",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "554",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "314",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1659779682093645824",
            "display_url" : "pic.twitter.com/TjmIWwqjoI"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "1659810955847409664",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1659810955847409664",
      "possibly_sensitive" : false,
      "created_at" : "Sat May 20 06:39:04 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @unusual_whales: These are unusual whales: https://t.co/TjmIWwqjoI",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/unusual_whales/status/1659779682093645824/photo/1",
            "source_status_id" : "1659779682093645824",
            "indices" : [
              "46",
              "69"
            ],
            "url" : "https://t.co/TjmIWwqjoI",
            "media_url" : "http://pbs.twimg.com/media/Fwi4puMWcAAKwt8.jpg",
            "id_str" : "1659779489600008192",
            "source_user_id" : "1200616796295847936",
            "id" : "1659779489600008192",
            "media_url_https" : "https://pbs.twimg.com/media/Fwi4puMWcAAKwt8.jpg",
            "source_user_id_str" : "1200616796295847936",
            "sizes" : {
              "large" : {
                "w" : "828",
                "h" : "1792",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "554",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "314",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1659779682093645824",
            "display_url" : "pic.twitter.com/TjmIWwqjoI"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1659810917943525379"
          ],
          "editableUntil" : "2023-05-20T07:08:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "unusual_whales",
            "screen_name" : "unusual_whales",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1200616796295847936",
            "id" : "1200616796295847936"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1659779682093645824",
      "id_str" : "1659810917943525379",
      "in_reply_to_user_id" : "1200616796295847936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1659810917943525379",
      "in_reply_to_status_id" : "1659779682093645824",
      "created_at" : "Sat May 20 06:38:55 +0000 2023",
      "favorited" : false,
      "full_text" : "@unusual_whales cos they're fed up with us, and rightly so",
      "lang" : "en",
      "in_reply_to_screen_name" : "unusual_whales",
      "in_reply_to_user_id_str" : "1200616796295847936"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1659596812678774785"
          ],
          "editableUntil" : "2023-05-19T16:58:08.617Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Catturd ™",
            "screen_name" : "catturd2",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "1043185714437992449",
            "id" : "1043185714437992449"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "14",
              "23"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/catturd2/status/1659344190331912198/photo/1",
            "source_status_id" : "1659344190331912198",
            "indices" : [
              "67",
              "90"
            ],
            "url" : "https://t.co/OrUzX2y2Po",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FwcsvhJWAAUaMIF.jpg",
            "id_str" : "1659344182572351493",
            "source_user_id" : "1043185714437992449",
            "id" : "1659344182572351493",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FwcsvhJWAAUaMIF.jpg",
            "source_user_id_str" : "1043185714437992449",
            "sizes" : {
              "medium" : {
                "w" : "300",
                "h" : "300",
                "resize" : "fit"
              },
              "small" : {
                "w" : "300",
                "h" : "300",
                "resize" : "fit"
              },
              "large" : {
                "w" : "300",
                "h" : "300",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1659344190331912198",
            "display_url" : "pic.twitter.com/OrUzX2y2Po"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "0",
      "id_str" : "1659596812678774785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1659596812678774785",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 19 16:28:08 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @catturd2: @elonmusk People frantically googling - elucidation. https://t.co/OrUzX2y2Po",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/catturd2/status/1659344190331912198/photo/1",
            "source_status_id" : "1659344190331912198",
            "indices" : [
              "67",
              "90"
            ],
            "url" : "https://t.co/OrUzX2y2Po",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FwcsvhJWAAUaMIF.jpg",
            "id_str" : "1659344182572351493",
            "video_info" : {
              "aspect_ratio" : [
                "1",
                "1"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/FwcsvhJWAAUaMIF.mp4"
                }
              ]
            },
            "source_user_id" : "1043185714437992449",
            "id" : "1659344182572351493",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FwcsvhJWAAUaMIF.jpg",
            "source_user_id_str" : "1043185714437992449",
            "sizes" : {
              "medium" : {
                "w" : "300",
                "h" : "300",
                "resize" : "fit"
              },
              "small" : {
                "w" : "300",
                "h" : "300",
                "resize" : "fit"
              },
              "large" : {
                "w" : "300",
                "h" : "300",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "animated_gif",
            "source_status_id_str" : "1659344190331912198",
            "display_url" : "pic.twitter.com/OrUzX2y2Po"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1659596786548310016"
          ],
          "editableUntil" : "2023-05-19T16:58:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1659340939477876737",
      "id_str" : "1659596786548310016",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1659596786548310016",
      "in_reply_to_status_id" : "1659340939477876737",
      "created_at" : "Fri May 19 16:28:02 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk miracles even",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1659596641253351427"
          ],
          "editableUntil" : "2023-05-19T16:57:27.746Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "id_str" : "1659596641253351427",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1659596641253351427",
      "created_at" : "Fri May 19 16:27:27 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @elonmusk: I have spaceships",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1652225005382516738"
          ],
          "editableUntil" : "2023-04-29T08:45:12.796Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Musk University | Quotes",
            "screen_name" : "MuskUniversity",
            "indices" : [
              "14",
              "29"
            ],
            "id_str" : "1495956968640421893",
            "id" : "1495956968640421893"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1652225005382516738",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1652225005382516738",
      "created_at" : "Sat Apr 29 08:15:12 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @elonmusk: @MuskUniversity Physics is the law, everything else is a recommendation. \n\nAnyone can break laws created by people, but I hav…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1652219667551846400"
          ],
          "editableUntil" : "2023-04-29T08:24:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Musk University | Quotes",
            "screen_name" : "MuskUniversity",
            "indices" : [
              "10",
              "25"
            ],
            "id_str" : "1495956968640421893",
            "id" : "1495956968640421893"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1652049254087811072",
      "id_str" : "1652219667551846400",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1652219667551846400",
      "in_reply_to_status_id" : "1652049254087811072",
      "created_at" : "Sat Apr 29 07:54:00 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk @MuskUniversity I like the \"as yet\" in that statement ...",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1652217224122204163"
          ],
          "editableUntil" : "2023-04-29T08:14:17.599Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AlchemyAmplify",
            "indices" : [
              "52",
              "67"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          },
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "88",
              "104"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1652217224122204163",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1652217224122204163",
      "created_at" : "Sat Apr 29 07:44:17 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: LFG! We’ve been chosen to  be in #AlchemyAmplify! We’re working with @alchemyplatform to build out the forgivenet. Check…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1652217161820041218"
          ],
          "editableUntil" : "2023-04-29T08:14:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "69",
              "85"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef5haKj",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "125",
              "148"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1652217161820041218/photo/1",
            "indices" : [
              "149",
              "172"
            ],
            "url" : "https://t.co/bFu132YD7E",
            "media_url" : "http://pbs.twimg.com/media/Fu3atZIWwAAUL1h.jpg",
            "id_str" : "1652217111689740288",
            "id" : "1652217111689740288",
            "media_url_https" : "https://pbs.twimg.com/media/Fu3atZIWwAAUL1h.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2000",
                "h" : "2000",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bFu132YD7E"
          }
        ],
        "hashtags" : [
          {
            "text" : "AlchemyAmplify",
            "indices" : [
              "33",
              "48"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "172"
      ],
      "favorite_count" : "1",
      "id_str" : "1652217161820041218",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1652217161820041218",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 29 07:44:02 +0000 2023",
      "favorited" : false,
      "full_text" : "LFG! We’ve been chosen to  be in #AlchemyAmplify! We’re working with @alchemyplatform to build out the forgivenet. Check out https://t.co/Iu5ef5haKj https://t.co/bFu132YD7E",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1652217161820041218/photo/1",
            "indices" : [
              "149",
              "172"
            ],
            "url" : "https://t.co/bFu132YD7E",
            "media_url" : "http://pbs.twimg.com/media/Fu3atZIWwAAUL1h.jpg",
            "id_str" : "1652217111689740288",
            "id" : "1652217111689740288",
            "media_url_https" : "https://pbs.twimg.com/media/Fu3atZIWwAAUL1h.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2000",
                "h" : "2000",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bFu132YD7E"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1646867196130254848"
          ],
          "editableUntil" : "2023-04-14T13:55:11.527Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "zkSync ∎",
            "screen_name" : "zksync",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1191702416971968512",
            "id" : "1191702416971968512"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/CtywpkEkd0",
            "expanded_url" : "https://twitter.com/the_matter_labs/status/1646864605648437248",
            "display_url" : "twitter.com/the_matter_lab…",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "1646867196130254848",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1646867196130254848",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 14 13:25:11 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @zksync: https://t.co/CtywpkEkd0",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1646861769715884032"
          ],
          "editableUntil" : "2023-04-14T13:33:37.769Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "zkSync ∎",
            "screen_name" : "zksync",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1191702416971968512",
            "id" : "1191702416971968512"
          },
          {
            "name" : "Matter Labs ∎",
            "screen_name" : "the_matter_labs",
            "indices" : [
              "85",
              "101"
            ],
            "id_str" : "1026513297414279168",
            "id" : "1026513297414279168"
          },
          {
            "name" : "Alex G. ∎",
            "screen_name" : "gluk64",
            "indices" : [
              "106",
              "113"
            ],
            "id_str" : "167801813",
            "id" : "167801813"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1646861769715884032",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1646861769715884032",
      "created_at" : "Fri Apr 14 13:03:37 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @zksync: THIS TWITTER ACCOUNT IS COMPROMISED!\n\nDo not trust it until confirmed by @the_matter_labs and @gluk64\n\n@TwitterSupport, @elonmu…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1646050962300190720"
          ],
          "editableUntil" : "2023-04-12T07:51:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "zkSync ∎",
            "screen_name" : "zksync",
            "indices" : [
              "32",
              "39"
            ],
            "id_str" : "1191702416971968512",
            "id" : "1191702416971968512"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/4MaxqPW7pd",
            "expanded_url" : "https://zksync.io/",
            "display_url" : "zksync.io",
            "indices" : [
              "135",
              "158"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "158"
      ],
      "favorite_count" : "0",
      "id_str" : "1646050962300190720",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1646050962300190720",
      "possibly_sensitive" : false,
      "created_at" : "Wed Apr 12 07:21:46 +0000 2023",
      "favorited" : false,
      "full_text" : "I'm claiming testnet tokens for @zksync era, the ultimate zkEVM!\n\nMy Address: 0x525cc3afaf11397c49c4d114df106b8793bd5ebc\n\nLearn more:  https://t.co/4MaxqPW7pd",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1643495929763319808"
          ],
          "editableUntil" : "2023-04-05T06:38:58.990Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethereum Daily",
            "screen_name" : "ETH_Daily",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1390323555569524738",
            "id" : "1390323555569524738"
          },
          {
            "name" : "zkSync ∎",
            "screen_name" : "zksync",
            "indices" : [
              "19",
              "26"
            ],
            "id_str" : "1191702416971968512",
            "id" : "1191702416971968512"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1643495929763319808",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1643495929763319808",
      "created_at" : "Wed Apr 05 06:08:58 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ETH_Daily: 🤓📊  @zkSync Era - Understanding smart contract architecture made easy with this diagram! \n\nCheck out the components of this…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1642107811998973953"
          ],
          "editableUntil" : "2023-04-01T10:43:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "goerli",
            "indices" : [
              "99",
              "106"
            ]
          },
          {
            "text" : "faucet",
            "indices" : [
              "107",
              "114"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/BRqyzVVapn",
            "expanded_url" : "https://goerli-faucet.pk910.de/",
            "display_url" : "goerli-faucet.pk910.de",
            "indices" : [
              "37",
              "60"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "114"
      ],
      "favorite_count" : "0",
      "id_str" : "1642107811998973953",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1642107811998973953",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 01 10:13:05 +0000 2023",
      "favorited" : false,
      "full_text" : "Boom! Just got 0.134 Goerli ETH from https://t.co/BRqyzVVapn (Mining for 2h 11min with 122.52 H/s) #goerli #faucet",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1642073911557779457"
          ],
          "editableUntil" : "2023-04-01T08:28:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1642073911557779457",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1642073911557779457",
      "created_at" : "Sat Apr 01 07:58:23 +0000 2023",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1642073387903139841"
          ],
          "editableUntil" : "2023-04-01T08:26:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "buidl",
            "indices" : [
              "74",
              "80"
            ]
          },
          {
            "text" : "web3",
            "indices" : [
              "81",
              "86"
            ]
          },
          {
            "text" : "eth",
            "indices" : [
              "87",
              "91"
            ]
          },
          {
            "text" : "development",
            "indices" : [
              "92",
              "104"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "QuickNode",
            "screen_name" : "QuickNode",
            "indices" : [
              "28",
              "38"
            ],
            "id_str" : "878924739812761600",
            "id" : "878924739812761600"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/GpAzTSy9TB",
            "expanded_url" : "https://faucet.quicknode.com/ethereum/sepolia?utm_source=faucet&utm_medium=twitter&utm_content=social-share&utm_term=sepolia-eth",
            "display_url" : "faucet.quicknode.com/ethereum/sepol…",
            "indices" : [
              "107",
              "130"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "0",
      "id_str" : "1642073387903139841",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1642073387903139841",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 01 07:56:18 +0000 2023",
      "favorited" : false,
      "full_text" : "Getting some Sepolia ETH at @quicknode's faucet for my 0E58AC8C wallet! \n #buidl #web3 #eth #development \n https://t.co/GpAzTSy9TB",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1641693071178956803"
          ],
          "editableUntil" : "2023-03-31T07:15:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "buidl",
            "indices" : [
              "73",
              "79"
            ]
          },
          {
            "text" : "web3",
            "indices" : [
              "80",
              "85"
            ]
          },
          {
            "text" : "eth",
            "indices" : [
              "86",
              "90"
            ]
          },
          {
            "text" : "development",
            "indices" : [
              "91",
              "103"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "QuickNode",
            "screen_name" : "QuickNode",
            "indices" : [
              "27",
              "37"
            ],
            "id_str" : "878924739812761600",
            "id" : "878924739812761600"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/U77bxMjfDa",
            "expanded_url" : "https://faucet.quicknode.com/ethereum/goerli?utm_source=faucet&utm_medium=twitter&utm_content=social-share&utm_term=goerli-eth",
            "display_url" : "faucet.quicknode.com/ethereum/goerl…",
            "indices" : [
              "106",
              "129"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "129"
      ],
      "favorite_count" : "0",
      "id_str" : "1641693071178956803",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1641693071178956803",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 31 06:45:04 +0000 2023",
      "favorited" : false,
      "full_text" : "Getting some Goerli ETH at @quicknode's faucet for my 93bd5ebc wallet! \n #buidl #web3 #eth #development \n https://t.co/U77bxMjfDa",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1641692399125643264"
          ],
          "editableUntil" : "2023-03-31T07:12:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "zkSync ∎",
            "screen_name" : "zksync",
            "indices" : [
              "32",
              "39"
            ],
            "id_str" : "1191702416971968512",
            "id" : "1191702416971968512"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/4MaxqPW7pd",
            "expanded_url" : "https://zksync.io/",
            "display_url" : "zksync.io",
            "indices" : [
              "135",
              "158"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "158"
      ],
      "favorite_count" : "0",
      "id_str" : "1641692399125643264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1641692399125643264",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 31 06:42:23 +0000 2023",
      "favorited" : false,
      "full_text" : "I'm claiming testnet tokens for @zksync era, the ultimate zkEVM!\n\nMy Address: 0x5f5f8722bee348afbcd383c8bd514c7f281e25af\n\nLearn more:  https://t.co/4MaxqPW7pd",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1641686550680424448"
          ],
          "editableUntil" : "2023-03-31T06:49:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBnVE",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "id_str" : "1641686550680424448",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1641686550680424448",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 31 06:19:09 +0000 2023",
      "favorited" : false,
      "full_text" : "Boom! Just got some free Goerli ETH on https://t.co/jUMA9jBnVE in literally 1 minute.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1641058572292308992"
          ],
          "editableUntil" : "2023-03-29T13:13:47.685Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "zkSync ∎",
            "screen_name" : "zksync",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1191702416971968512",
            "id" : "1191702416971968512"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1641058572292308992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1641058572292308992",
      "created_at" : "Wed Mar 29 12:43:47 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @zksync: Responsible disclosure and community contributions to security are critical for safeguarding zkSync Era. We’re excited to annou…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1640969981297934336"
          ],
          "editableUntil" : "2023-03-29T07:21:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBnVE",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "19",
              "42"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "114"
      ],
      "favorite_count" : "0",
      "id_str" : "1640969981297934336",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1640969981297934336",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 29 06:51:45 +0000 2023",
      "favorited" : false,
      "full_text" : "Just started using https://t.co/jUMA9jBnVE and it worked like a breeze!\n\nShoutout to Alchemy for making it happen.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1638812911509315585"
          ],
          "editableUntil" : "2023-03-23T08:30:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "zkSync ∎",
            "screen_name" : "zksync",
            "indices" : [
              "32",
              "39"
            ],
            "id_str" : "1191702416971968512",
            "id" : "1191702416971968512"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/4MaxqPW7pd",
            "expanded_url" : "https://zksync.io/",
            "display_url" : "zksync.io",
            "indices" : [
              "135",
              "158"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "158"
      ],
      "favorite_count" : "0",
      "id_str" : "1638812911509315585",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1638812911509315585",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 23 08:00:20 +0000 2023",
      "favorited" : false,
      "full_text" : "I'm claiming testnet tokens for @zksync era, the ultimate zkEVM!\n\nMy Address: 0x5f5f8722bee348afbcd383c8bd514c7f281e25af\n\nLearn more:  https://t.co/4MaxqPW7pd",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1638811704891940864"
          ],
          "editableUntil" : "2023-03-23T08:25:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "id_str" : "1638811704891940864",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1638811704891940864",
      "created_at" : "Thu Mar 23 07:55:32 +0000 2023",
      "favorited" : false,
      "full_text" : "Requesting testnet ETH 0x5f5F8722BEe348afbCd383c8bD514C7F281e25aF",
      "lang" : "da"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1637459949646147586"
          ],
          "editableUntil" : "2023-03-19T14:54:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1637198368714772486",
      "id_str" : "1637459949646147586",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1637459949646147586",
      "in_reply_to_status_id" : "1637198368714772486",
      "created_at" : "Sun Mar 19 14:24:09 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk if user == porn.addict then assume report == malicious, ignore report",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1633766977054408704"
          ],
          "editableUntil" : "2023-03-09T10:19:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "0",
      "id_str" : "1633766977054408704",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1633766977054408704",
      "created_at" : "Thu Mar 09 09:49:35 +0000 2023",
      "favorited" : false,
      "full_text" : "Recommended platform for converting web3 desktop app to mobile?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1630125314197127169"
          ],
          "editableUntil" : "2023-02-27T09:08:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1629914011415244803",
      "id_str" : "1630125314197127169",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1630125314197127169",
      "in_reply_to_status_id" : "1629914011415244803",
      "created_at" : "Mon Feb 27 08:38:55 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk I love you but you're such a donut.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1629513981260976129"
          ],
          "editableUntil" : "2023-02-25T16:39:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1629201852968452097",
      "id_str" : "1629513981260976129",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1629513981260976129",
      "in_reply_to_status_id" : "1629201852968452097",
      "created_at" : "Sat Feb 25 16:09:42 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk How do you do that in bulk?",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1627946590546587649"
          ],
          "editableUntil" : "2023-02-21T08:51:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1627940509858529281",
      "id_str" : "1627946590546587649",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1627946590546587649",
      "in_reply_to_status_id" : "1627940509858529281",
      "created_at" : "Tue Feb 21 08:21:27 +0000 2023",
      "favorited" : false,
      "full_text" : "@StephenKing that was a film reference",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1627940509858529281"
          ],
          "editableUntil" : "2023-02-21T08:27:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1627712303066906637",
      "id_str" : "1627940509858529281",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1627940509858529281",
      "in_reply_to_status_id" : "1627712303066906637",
      "created_at" : "Tue Feb 21 07:57:17 +0000 2023",
      "favorited" : false,
      "full_text" : "@StephenKing Spilling out all over the dock.",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1625412061999116288"
          ],
          "editableUntil" : "2023-02-14T09:00:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1625407245218648065",
      "id_str" : "1625412061999116288",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1625412061999116288",
      "in_reply_to_status_id" : "1625407245218648065",
      "created_at" : "Tue Feb 14 08:30:08 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk Oh bl**dy hell, what now?",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1624480645710749696"
          ],
          "editableUntil" : "2023-02-11T19:19:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "crypto",
            "indices" : [
              "8",
              "15"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1624479812139077639",
      "id_str" : "1624480645710749696",
      "in_reply_to_user_id" : "1423937973201027078",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1624480645710749696",
      "in_reply_to_status_id" : "1624479812139077639",
      "created_at" : "Sat Feb 11 18:49:01 +0000 2023",
      "favorited" : false,
      "full_text" : "@1FRGVN #crypto like no other",
      "lang" : "en",
      "in_reply_to_screen_name" : "1FRGVN",
      "in_reply_to_user_id_str" : "1423937973201027078"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1624480605093208066"
          ],
          "editableUntil" : "2023-02-11T19:18:52.301Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/K5oxxxIm0Y",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "63",
              "86"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1624480605093208066",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1624480605093208066",
      "possibly_sensitive" : false,
      "created_at" : "Sat Feb 11 18:48:52 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: It's time to give love to the forgivenetTM folks.\n\nhttps://t.co/K5oxxxIm0Y\n\nWe support safety for children and their happy adul…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1624335918843801601"
          ],
          "editableUntil" : "2023-02-11T09:43:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Ria",
            "screen_name" : "RiaRevealed",
            "indices" : [
              "10",
              "22"
            ],
            "id_str" : "135848667",
            "id" : "135848667"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1624097556119818240",
      "id_str" : "1624335918843801601",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1624335918843801601",
      "in_reply_to_status_id" : "1624097556119818240",
      "created_at" : "Sat Feb 11 09:13:56 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk @RiaRevealed You mean, if you can't afford  it, you're corrupt?",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1624073539471958016"
          ],
          "editableUntil" : "2023-02-10T16:21:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "32",
              "55"
            ]
          },
          {
            "url" : "https://t.co/pLQmlRDEiD",
            "expanded_url" : "https://www.alchemy.com/web3-awards",
            "display_url" : "alchemy.com/web3-awards",
            "indices" : [
              "57",
              "80"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "id_str" : "1624073539471958016",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1624073539471958016",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 10 15:51:20 +0000 2023",
      "favorited" : false,
      "full_text" : "GO ON, nominate the forgivenet.\nhttps://t.co/6JUcz6pz0V\n\nhttps://t.co/pLQmlRDEiD",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1621645590818947081"
          ],
          "editableUntil" : "2023-02-03T23:33:32.226Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "groomedAsF",
            "indices" : [
              "105",
              "116"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          },
          {
            "name" : "ThisEgg",
            "screen_name" : "ThisEgg_",
            "indices" : [
              "12",
              "21"
            ],
            "id_str" : "364947028",
            "id" : "364947028"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/SKh3UVPtOe",
            "expanded_url" : "https://twitter.com/1FRGVN/status/1472689767481499651",
            "display_url" : "twitter.com/1FRGVN/status/…",
            "indices" : [
              "81",
              "104"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "116"
      ],
      "favorite_count" : "0",
      "id_str" : "1621645590818947081",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1621645590818947081",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 03 23:03:32 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @1FRGVN: @ThisEgg_ How about some self inquiry about how groomed you all are. https://t.co/SKh3UVPtOe #groomedAsF",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1621601493710262272"
          ],
          "editableUntil" : "2023-02-03T20:38:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kevin W.",
            "screen_name" : "Brink_Thinker",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1131818069184135168",
            "id" : "1131818069184135168"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1621292370783264771",
      "id_str" : "1621601493710262272",
      "in_reply_to_user_id" : "1131818069184135168",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1621601493710262272",
      "in_reply_to_status_id" : "1621292370783264771",
      "created_at" : "Fri Feb 03 20:08:18 +0000 2023",
      "favorited" : false,
      "full_text" : "@Brink_Thinker £10 a day ... putting clothes in plastic bags.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Brink_Thinker",
      "in_reply_to_user_id_str" : "1131818069184135168"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1620843185391144960"
          ],
          "editableUntil" : "2023-02-01T18:25:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "114"
      ],
      "favorite_count" : "0",
      "id_str" : "1620843185391144960",
      "in_reply_to_user_id" : "17874544",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1620843185391144960",
      "created_at" : "Wed Feb 01 17:55:03 +0000 2023",
      "favorited" : false,
      "full_text" : "@TwitterSupport can you remove this message alert from my email box please, there is no email in there, thank you.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Support",
      "in_reply_to_user_id_str" : "17874544"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1618885951698395136"
          ],
          "editableUntil" : "2023-01-27T08:47:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CZ 🔶 Binance",
            "screen_name" : "cz_binance",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "902926941413453824",
            "id" : "902926941413453824"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6q6Qt",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "66",
              "89"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1618833012606775296",
      "id_str" : "1618885951698395136",
      "in_reply_to_user_id" : "902926941413453824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1618885951698395136",
      "in_reply_to_status_id" : "1618833012606775296",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 27 08:17:42 +0000 2023",
      "favorited" : false,
      "full_text" : "@cz_binance Marvellous wonderful things, mainly saving the world. https://t.co/6JUcz6q6Qt",
      "lang" : "en",
      "in_reply_to_screen_name" : "cz_binance",
      "in_reply_to_user_id_str" : "902926941413453824"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1617231197674897408"
          ],
          "editableUntil" : "2023-01-22T19:12:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1616962475857186817",
      "id_str" : "1617231197674897408",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1617231197674897408",
      "in_reply_to_status_id" : "1616962475857186817",
      "created_at" : "Sun Jan 22 18:42:18 +0000 2023",
      "favorited" : false,
      "full_text" : "@StephenKing Molly is a wee dote.",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1615761344485294080"
          ],
          "editableUntil" : "2023-01-18T17:51:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1615742233134653442",
      "id_str" : "1615761344485294080",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1615761344485294080",
      "in_reply_to_status_id" : "1615742233134653442",
      "created_at" : "Wed Jan 18 17:21:38 +0000 2023",
      "favorited" : false,
      "full_text" : "@StephenKing even if it's porn?",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1615625480534630400"
          ],
          "editableUntil" : "2023-01-18T08:51:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Robert F. Kennedy Jr",
            "screen_name" : "RobertKennedyJr",
            "indices" : [
              "10",
              "26"
            ],
            "id_str" : "337808606",
            "id" : "337808606"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1615395217464786944",
      "id_str" : "1615625480534630400",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1615625480534630400",
      "in_reply_to_status_id" : "1615395217464786944",
      "created_at" : "Wed Jan 18 08:21:46 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk @RobertKennedyJr Still not allowed to call men men tho.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1613101573470650370"
          ],
          "editableUntil" : "2023-01-11T09:42:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1612990869900075010",
      "id_str" : "1613101573470650370",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1613101573470650370",
      "in_reply_to_status_id" : "1612990869900075010",
      "created_at" : "Wed Jan 11 09:12:39 +0000 2023",
      "favorited" : false,
      "full_text" : "@StephenKing Maria Carey Christmas ear-worm Song.",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1612191917990633475"
          ],
          "editableUntil" : "2023-01-08T21:28:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr Katharine Murphy PhD",
            "screen_name" : "1FRGVN",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1423937973201027078",
            "id" : "1423937973201027078"
          },
          {
            "name" : "Ashwini Shrivastava",
            "screen_name" : "AshwiniSahaya",
            "indices" : [
              "8",
              "22"
            ],
            "id_str" : "1501772314722983936",
            "id" : "1501772314722983936"
          },
          {
            "name" : "United Nations",
            "screen_name" : "UN",
            "indices" : [
              "23",
              "26"
            ],
            "id_str" : "14159148",
            "id" : "14159148"
          },
          {
            "name" : "UN Human Rights",
            "screen_name" : "UNHumanRights",
            "indices" : [
              "27",
              "41"
            ],
            "id_str" : "69231187",
            "id" : "69231187"
          },
          {
            "name" : "Robert Spencer",
            "screen_name" : "jihadwatchRS",
            "indices" : [
              "42",
              "55"
            ],
            "id_str" : "19985444",
            "id" : "19985444"
          },
          {
            "name" : "Masih Alinejad 🏳️",
            "screen_name" : "AlinejadMasih",
            "indices" : [
              "56",
              "70"
            ],
            "id_str" : "947924373029171200",
            "id" : "947924373029171200"
          },
          {
            "name" : "Tarek Fatah",
            "screen_name" : "TarekFatah",
            "indices" : [
              "71",
              "82"
            ],
            "id_str" : "17537467",
            "id" : "17537467"
          },
          {
            "name" : "Martina Navratilova",
            "screen_name" : "Martina",
            "indices" : [
              "83",
              "91"
            ],
            "id_str" : "506429053",
            "id" : "506429053"
          },
          {
            "name" : "BBC Breaking News",
            "screen_name" : "BBCBreaking",
            "indices" : [
              "92",
              "104"
            ],
            "id_str" : "5402612",
            "id" : "5402612"
          },
          {
            "name" : "Fox News",
            "screen_name" : "FoxNews",
            "indices" : [
              "105",
              "113"
            ],
            "id_str" : "1367531",
            "id" : "1367531"
          },
          {
            "name" : "The New York Times",
            "screen_name" : "nytimes",
            "indices" : [
              "114",
              "122"
            ],
            "id_str" : "807095",
            "id" : "807095"
          },
          {
            "name" : "CNN Breaking News",
            "screen_name" : "cnnbrk",
            "indices" : [
              "123",
              "130"
            ],
            "id_str" : "428333",
            "id" : "428333"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "181"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1612043179401875458",
      "id_str" : "1612191917990633475",
      "in_reply_to_user_id" : "1423937973201027078",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1612191917990633475",
      "in_reply_to_status_id" : "1612043179401875458",
      "created_at" : "Sun Jan 08 20:58:00 +0000 2023",
      "favorited" : false,
      "full_text" : "@1FRGVN @AshwiniSahaya @UN @UNHumanRights @jihadwatchRS @AlinejadMasih @TarekFatah @Martina @BBCBreaking @FoxNews @nytimes @cnnbrk Certainly looks like it's going this way globally.",
      "lang" : "en",
      "in_reply_to_screen_name" : "1FRGVN",
      "in_reply_to_user_id_str" : "1423937973201027078"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1612191641246339072"
          ],
          "editableUntil" : "2023-01-08T21:26:55.002Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef5hIzR",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "88",
              "111"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "0",
      "id_str" : "1612191641246339072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1612191641246339072",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 08 20:56:55 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: Request forgiveness. Earn a crypto reward.\n\nFEEL BETTER AFTERWARDS.\n\nhttps://t.co/Iu5ef5hIzR",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1612191619826216961"
          ],
          "editableUntil" : "2023-01-08T21:26:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef5hIzR",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "69",
              "92"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "1",
      "id_str" : "1612191619826216961",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1612191619826216961",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 08 20:56:49 +0000 2023",
      "favorited" : false,
      "full_text" : "Request forgiveness. Earn a crypto reward.\n\nFEEL BETTER AFTERWARDS.\n\nhttps://t.co/Iu5ef5hIzR",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1610911509957181441"
          ],
          "editableUntil" : "2023-01-05T08:40:07.919Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matt Wallace",
            "screen_name" : "MattWallace888",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "805532293951606785",
            "id" : "805532293951606785"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "0",
      "id_str" : "1610911509957181441",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1610911509957181441",
      "created_at" : "Thu Jan 05 08:10:07 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @MattWallace888: Elon Musk is calling for the Epstein client list to be released. Do you agree with him?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1610911498326384641"
          ],
          "editableUntil" : "2023-01-05T08:40:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matt Wallace",
            "screen_name" : "MattWallace888",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "805532293951606785",
            "id" : "805532293951606785"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1610686887085346817",
      "id_str" : "1610911498326384641",
      "in_reply_to_user_id" : "805532293951606785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1610911498326384641",
      "in_reply_to_status_id" : "1610686887085346817",
      "created_at" : "Thu Jan 05 08:10:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@MattWallace888 Could anyone disagree with this?",
      "lang" : "en",
      "in_reply_to_screen_name" : "MattWallace888",
      "in_reply_to_user_id_str" : "805532293951606785"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1609342483481366528"
          ],
          "editableUntil" : "2023-01-01T00:45:22.856Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "vitalik.eth",
            "screen_name" : "VitalikButerin",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "295218901",
            "id" : "295218901"
          },
          {
            "name" : "Balaji",
            "screen_name" : "balajis",
            "indices" : [
              "20",
              "28"
            ],
            "id_str" : "2178012643",
            "id" : "2178012643"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1609342483481366528",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1609342483481366528",
      "created_at" : "Sun Jan 01 00:15:22 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @VitalikButerin: @balajis Reaching the \"basic rollup scaling\" milestone in my roadmap diagram.\n\nThat means:\n\n* EIP-4844 rolled out\n* Rol…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1605932057095327745"
          ],
          "editableUntil" : "2022-12-22T14:53:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CZ 🔶 Binance",
            "screen_name" : "cz_binance",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "902926941413453824",
            "id" : "902926941413453824"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/spiRVUU6jc",
            "expanded_url" : "https://www.alchemy.com/dapps/1frgvn",
            "display_url" : "alchemy.com/dapps/1frgvn",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1605651313240391681",
      "id_str" : "1605932057095327745",
      "in_reply_to_user_id" : "902926941413453824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1605932057095327745",
      "in_reply_to_status_id" : "1605651313240391681",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 22 14:23:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@cz_binance https://t.co/spiRVUU6jc",
      "lang" : "qme",
      "in_reply_to_screen_name" : "cz_binance",
      "in_reply_to_user_id_str" : "902926941413453824"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1605931815025356801"
          ],
          "editableUntil" : "2022-12-22T14:52:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1605931815025356801/photo/1",
            "indices" : [
              "20",
              "43"
            ],
            "url" : "https://t.co/Tm1bQ4pan6",
            "media_url" : "http://pbs.twimg.com/media/FklqSBuVUAAngjJ.jpg",
            "id_str" : "1605931600067252224",
            "id" : "1605931600067252224",
            "media_url_https" : "https://pbs.twimg.com/media/FklqSBuVUAAngjJ.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Tm1bQ4pan6"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "1605931815025356801",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1605931815025356801",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 22 14:22:36 +0000 2022",
      "favorited" : false,
      "full_text" : "A new era begins... https://t.co/Tm1bQ4pan6",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1605931815025356801/photo/1",
            "indices" : [
              "20",
              "43"
            ],
            "url" : "https://t.co/Tm1bQ4pan6",
            "media_url" : "http://pbs.twimg.com/media/FklqSBuVUAAngjJ.jpg",
            "id_str" : "1605931600067252224",
            "id" : "1605931600067252224",
            "media_url_https" : "https://pbs.twimg.com/media/FklqSBuVUAAngjJ.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Tm1bQ4pan6"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1605808074614181889"
          ],
          "editableUntil" : "2022-12-22T06:40:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "10",
              "26"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef4ZzlJ",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "60",
              "83"
            ]
          },
          {
            "url" : "https://t.co/ffx5zSCAtT",
            "expanded_url" : "https://dapps.alchemy.com/dapps",
            "display_url" : "dapps.alchemy.com/dapps",
            "indices" : [
              "84",
              "107"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "0",
      "id_str" : "1605808074614181889",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1605808074614181889",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 22 06:10:54 +0000 2022",
      "favorited" : false,
      "full_text" : "Thank you @AlchemyPlatform for believing in the forgivenet.\nhttps://t.co/Iu5ef4ZzlJ\nhttps://t.co/ffx5zSCAtT",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1603484427539124224"
          ],
          "editableUntil" : "2022-12-15T20:47:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Teslaconomics",
            "screen_name" : "Teslaconomics",
            "indices" : [
              "10",
              "24"
            ],
            "id_str" : "985243593538338816",
            "id" : "985243593538338816"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "123"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1603273356865847297",
      "id_str" : "1603484427539124224",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1603484427539124224",
      "in_reply_to_status_id" : "1603273356865847297",
      "created_at" : "Thu Dec 15 20:17:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @Teslaconomics I have this level of security now, but it would need a long explanation ... over a decade minimum.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602811937993232386"
          ],
          "editableUntil" : "2022-12-14T00:15:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "unusual_whales",
            "screen_name" : "unusual_whales",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1200616796295847936",
            "id" : "1200616796295847936"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1602783723673378816",
      "id_str" : "1602811937993232386",
      "in_reply_to_user_id" : "1200616796295847936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602811937993232386",
      "in_reply_to_status_id" : "1602783723673378816",
      "created_at" : "Tue Dec 13 23:45:19 +0000 2022",
      "favorited" : false,
      "full_text" : "@unusual_whales Good.",
      "lang" : "en",
      "in_reply_to_screen_name" : "unusual_whales",
      "in_reply_to_user_id_str" : "1200616796295847936"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602776422912860165"
          ],
          "editableUntil" : "2022-12-13T21:54:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "unusual_whales",
            "screen_name" : "unusual_whales",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1200616796295847936",
            "id" : "1200616796295847936"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1602774097204748291",
      "id_str" : "1602776422912860165",
      "in_reply_to_user_id" : "1200616796295847936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602776422912860165",
      "in_reply_to_status_id" : "1602774097204748291",
      "created_at" : "Tue Dec 13 21:24:12 +0000 2022",
      "favorited" : false,
      "full_text" : "@unusual_whales And men are women, per NYT.",
      "lang" : "en",
      "in_reply_to_screen_name" : "unusual_whales",
      "in_reply_to_user_id_str" : "1200616796295847936"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602776336803983361"
          ],
          "editableUntil" : "2022-12-13T21:53:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "0",
      "id_str" : "1602776336803983361",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602776336803983361",
      "created_at" : "Tue Dec 13 21:23:51 +0000 2022",
      "favorited" : false,
      "full_text" : "I got botted.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602365739217948730"
          ],
          "editableUntil" : "2022-12-12T18:42:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Microsoft",
            "screen_name" : "Microsoft",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "74286565",
            "id" : "74286565"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1602365343841882112",
      "id_str" : "1602365739217948730",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602365739217948730",
      "in_reply_to_status_id" : "1602365343841882112",
      "created_at" : "Mon Dec 12 18:12:17 +0000 2022",
      "favorited" : false,
      "full_text" : "@Microsoft crack myself up",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602365716153470977"
          ],
          "editableUntil" : "2022-12-12T18:42:11.903Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          },
          {
            "name" : "Microsoft",
            "screen_name" : "Microsoft",
            "indices" : [
              "19",
              "29"
            ],
            "id_str" : "74286565",
            "id" : "74286565"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "113"
      ],
      "favorite_count" : "0",
      "id_str" : "1602365716153470977",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602365716153470977",
      "created_at" : "Mon Dec 12 18:12:11 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: @Microsoft No, it's usually Shane Watson from Bangalore, sometimes Ronald Turnpike from Delhi.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602365343841882112"
          ],
          "editableUntil" : "2022-12-12T18:40:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Microsoft",
            "screen_name" : "Microsoft",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "74286565",
            "id" : "74286565"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "94"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1602361998720864270",
      "id_str" : "1602365343841882112",
      "in_reply_to_user_id" : "74286565",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1602365343841882112",
      "in_reply_to_status_id" : "1602361998720864270",
      "created_at" : "Mon Dec 12 18:10:43 +0000 2022",
      "favorited" : false,
      "full_text" : "@Microsoft No, it's usually Shane Watson from Bangalore, sometimes Ronald Turnpike from Delhi.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Microsoft",
      "in_reply_to_user_id_str" : "74286565"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602294784093483008"
          ],
          "editableUntil" : "2022-12-12T14:00:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "37",
              "46"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "id_str" : "1602294784093483008",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602294784093483008",
      "created_at" : "Mon Dec 12 13:30:20 +0000 2022",
      "favorited" : false,
      "full_text" : "Something of the Coyote about you Mr @ElonMusk.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602294057761390593"
          ],
          "editableUntil" : "2022-12-12T13:57:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "1602294057761390593",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602294057761390593",
      "created_at" : "Mon Dec 12 13:27:27 +0000 2022",
      "favorited" : false,
      "full_text" : "Wow, Coinbase Wallet is way better than MM.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602076564300128266"
          ],
          "editableUntil" : "2022-12-11T23:33:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Viva Frei",
            "screen_name" : "thevivafrei",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "96906231",
            "id" : "96906231"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "13",
              "22"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "J.K. Rowling",
            "screen_name" : "jk_rowling",
            "indices" : [
              "23",
              "34"
            ],
            "id_str" : "62513246",
            "id" : "62513246"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1602022235023314949",
      "id_str" : "1602076564300128266",
      "in_reply_to_user_id" : "96906231",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602076564300128266",
      "in_reply_to_status_id" : "1602022235023314949",
      "created_at" : "Sun Dec 11 23:03:12 +0000 2022",
      "favorited" : false,
      "full_text" : "@thevivafrei @elonmusk @jk_rowling 's tweet likes are in the BILLIONS!",
      "lang" : "en",
      "in_reply_to_screen_name" : "thevivafrei",
      "in_reply_to_user_id_str" : "96906231"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1601210416419721216"
          ],
          "editableUntil" : "2022-12-09T14:11:26.982Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "unusual_whales",
            "screen_name" : "unusual_whales",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "1200616796295847936",
            "id" : "1200616796295847936"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1601210416419721216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1601210416419721216",
      "created_at" : "Fri Dec 09 13:41:26 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @unusual_whales: BREAKING: Twitter Files released by Elon Musk, Matt Taibbi &amp; Bari Weiss, have suggested that a secret group headed by V…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1599537372449820672"
          ],
          "editableUntil" : "2022-12-04T23:23:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "1599537372449820672",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1599537372449820672",
      "created_at" : "Sun Dec 04 22:53:22 +0000 2022",
      "favorited" : false,
      "full_text" : "think i'm having a gum abscess BCJT",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1599110263449321474"
          ],
          "editableUntil" : "2022-12-03T19:06:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/rpFX0c6Xgo",
            "expanded_url" : "http://1FRGVN.COM",
            "display_url" : "1FRGVN.COM",
            "indices" : [
              "83",
              "106"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "123"
      ],
      "favorite_count" : "0",
      "id_str" : "1599110263449321474",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1599110263449321474",
      "possibly_sensitive" : false,
      "created_at" : "Sat Dec 03 18:36:11 +0000 2022",
      "favorited" : false,
      "full_text" : "Web3 competition.\n\nWin 1M FRGVN tokens by building a new site for the forgivenet.\n\nhttps://t.co/rpFX0c6Xgo\n\nDM for details.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1599050554734702593"
          ],
          "editableUntil" : "2022-12-03T15:08:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Avi Yemini",
            "screen_name" : "OzraeliAvi",
            "indices" : [
              "10",
              "21"
            ],
            "id_str" : "97054224",
            "id" : "97054224"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1598990820665065472",
      "id_str" : "1599050554734702593",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1599050554734702593",
      "in_reply_to_status_id" : "1598990820665065472",
      "created_at" : "Sat Dec 03 14:38:55 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @OzraeliAvi you'll get yourself shadow banned with that sort of thing",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1599050464971980801"
          ],
          "editableUntil" : "2022-12-03T15:08:34.427Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Avi Yemini",
            "screen_name" : "OzraeliAvi",
            "indices" : [
              "14",
              "25"
            ],
            "id_str" : "97054224",
            "id" : "97054224"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1599050464971980801",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1599050464971980801",
      "created_at" : "Sat Dec 03 14:38:34 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: @OzraeliAvi I’ve seen a lot of concerning tweets about the recent Brazil election. If those tweets are accurate, it’s possibl…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1598408162591531009"
          ],
          "editableUntil" : "2022-12-01T20:36:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "128"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1598381157124837376",
      "id_str" : "1598408162591531009",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1598408162591531009",
      "in_reply_to_status_id" : "1598381157124837376",
      "created_at" : "Thu Dec 01 20:06:17 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk they're scared to speak because anytime anyone talk sense over here, they're quite often attacked ... so it's mob rule",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1598321219249602560"
          ],
          "editableUntil" : "2022-12-01T14:50:48.698Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Jim Hall",
            "screen_name" : "jhall",
            "indices" : [
              "14",
              "20"
            ],
            "id_str" : "778623",
            "id" : "778623"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "id_str" : "1598321219249602560",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1598321219249602560",
      "created_at" : "Thu Dec 01 14:20:48 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: @jhall Cancel culture needs to be canceled!!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1598277817313419264"
          ],
          "editableUntil" : "2022-12-01T11:58:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Ashlee Vance",
            "screen_name" : "ashleevance",
            "indices" : [
              "10",
              "22"
            ],
            "id_str" : "81961201",
            "id" : "81961201"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1598154904635596802",
      "id_str" : "1598277817313419264",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1598277817313419264",
      "in_reply_to_status_id" : "1598154904635596802",
      "created_at" : "Thu Dec 01 11:28:20 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @ashleevance not in a trillion years",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1598244265326706688"
          ],
          "editableUntil" : "2022-12-01T09:45:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1598083625295089664",
      "id_str" : "1598244265326706688",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1598244265326706688",
      "in_reply_to_status_id" : "1598083625295089664",
      "created_at" : "Thu Dec 01 09:15:01 +0000 2022",
      "favorited" : false,
      "full_text" : "@StephenKing woke is pedo land",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1597616289702285312"
          ],
          "editableUntil" : "2022-11-29T16:09:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Liz Wheeler",
            "screen_name" : "Liz_Wheeler",
            "indices" : [
              "10",
              "22"
            ],
            "id_str" : "264361128",
            "id" : "264361128"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1597524485074485248",
      "id_str" : "1597616289702285312",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1597616289702285312",
      "in_reply_to_status_id" : "1597524485074485248",
      "created_at" : "Tue Nov 29 15:39:40 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @Liz_Wheeler Can you start banning the MAPs forever please.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1597508854266605568"
          ],
          "editableUntil" : "2022-11-29T09:02:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1597336812732575744",
      "id_str" : "1597508854266605568",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1597508854266605568",
      "in_reply_to_status_id" : "1597336812732575744",
      "created_at" : "Tue Nov 29 08:32:45 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk we'd like to know about the pedo infiltration",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1597508769403273216"
          ],
          "editableUntil" : "2022-11-29T09:02:25.560Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1597508769403273216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1597508769403273216",
      "created_at" : "Tue Nov 29 08:32:25 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: The Twitter Files on free speech suppression soon to be published on Twitter itself. The public deserves to know what really…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1597325663014641664"
          ],
          "editableUntil" : "2022-11-28T20:54:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1597165510595989504",
      "id_str" : "1597325663014641664",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1597325663014641664",
      "in_reply_to_status_id" : "1597165510595989504",
      "created_at" : "Mon Nov 28 20:24:49 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk Honestly Elon.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596839408325754886"
          ],
          "editableUntil" : "2022-11-27T12:42:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1596839408325754886",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596839408325754886",
      "created_at" : "Sun Nov 27 12:12:37 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596635318006030345"
          ],
          "editableUntil" : "2022-11-26T23:11:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Alex",
            "screen_name" : "alex_avoigt",
            "indices" : [
              "10",
              "22"
            ],
            "id_str" : "718747351792398336",
            "id" : "718747351792398336"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "155"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1596591361741889536",
      "id_str" : "1596635318006030345",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596635318006030345",
      "in_reply_to_status_id" : "1596591361741889536",
      "created_at" : "Sat Nov 26 22:41:38 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @alex_avoigt WOW, I would be ACE at your company ... except I'm a Woman so everyone would assume I'm an idiot ...\n\nAnd I have ZERO time for that.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596626256178839553"
          ],
          "editableUntil" : "2022-11-26T22:35:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "10",
              "22"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "87"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1596598352313208832",
      "id_str" : "1596626256178839553",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596626256178839553",
      "in_reply_to_status_id" : "1596598352313208832",
      "created_at" : "Sat Nov 26 22:05:38 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @StephenKing I know it's scary, but you're quietly-loudly forgetting the 50%.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596623169019781120"
          ],
          "editableUntil" : "2022-11-26T22:23:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "cryptocurrency",
            "indices" : [
              "0",
              "15"
            ]
          },
          {
            "text" : "win",
            "indices" : [
              "16",
              "20"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Paddy Power",
            "screen_name" : "paddypower",
            "indices" : [
              "21",
              "32"
            ],
            "id_str" : "14387275",
            "id" : "14387275"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "173"
      ],
      "favorite_count" : "0",
      "id_str" : "1596623169019781120",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596623169019781120",
      "created_at" : "Sat Nov 26 21:53:21 +0000 2022",
      "favorited" : false,
      "full_text" : "#cryptocurrency #win @paddypower  you'd be better of running bets on when gender surgeons for kids will be in jail ... and I'm all in for a number of them... esp . Gallagher",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596598303990304770"
          ],
          "editableUntil" : "2022-11-26T20:44:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Massimo",
            "screen_name" : "Rainmaker1973",
            "indices" : [
              "10",
              "24"
            ],
            "id_str" : "177101260",
            "id" : "177101260"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1596439328338890752",
      "id_str" : "1596598303990304770",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596598303990304770",
      "in_reply_to_status_id" : "1596439328338890752",
      "created_at" : "Sat Nov 26 20:14:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @Rainmaker1973 lint",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596582970798014464"
          ],
          "editableUntil" : "2022-11-26T19:43:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1596544741310857216",
      "id_str" : "1596582970798014464",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596582970798014464",
      "in_reply_to_status_id" : "1596544741310857216",
      "created_at" : "Sat Nov 26 19:13:37 +0000 2022",
      "favorited" : false,
      "full_text" : "@StephenKing Now apply that rock-solid logic to everything and .. ahem.. the world is saved.",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596197773317136385"
          ],
          "editableUntil" : "2022-11-25T18:12:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk Quotes",
            "screen_name" : "muskQu0tes",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1564277306641698817",
            "id" : "1564277306641698817"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "12",
              "21"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1595898482078158848",
      "id_str" : "1596197773317136385",
      "in_reply_to_user_id" : "1564277306641698817",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596197773317136385",
      "in_reply_to_status_id" : "1595898482078158848",
      "created_at" : "Fri Nov 25 17:42:59 +0000 2022",
      "favorited" : false,
      "full_text" : "@muskQu0tes @elonmusk More important, cos without a Mom, there's not even a person to have a career.",
      "lang" : "en",
      "in_reply_to_screen_name" : "muskQu0tes",
      "in_reply_to_user_id_str" : "1564277306641698817"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1596070102637498368"
          ],
          "editableUntil" : "2022-11-25T09:45:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1596070102637498368",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1596070102637498368",
      "created_at" : "Fri Nov 25 09:15:40 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1594984942102249472"
          ],
          "editableUntil" : "2022-11-22T09:53:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBVLc",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "114",
              "137"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1594984942102249472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1594984942102249472",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 22 09:23:38 +0000 2022",
      "favorited" : false,
      "full_text" : "Thanks so much to the folks at Alchemy!\n\nJust used your faucet and it worked like a charm!\n\nYou can find it here: https://t.co/jUMA9jBVLc ☘",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1594811799764967441"
          ],
          "editableUntil" : "2022-11-21T22:25:37.891Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "0",
      "id_str" : "1594811799764967441",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1594811799764967441",
      "created_at" : "Mon Nov 21 21:55:37 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: Fanaticism is always a function of repressed doubt – Dune",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1594757937695703061"
          ],
          "editableUntil" : "2022-11-21T18:51:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1594735452812189697",
      "id_str" : "1594757937695703061",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1594757937695703061",
      "in_reply_to_status_id" : "1594735452812189697",
      "created_at" : "Mon Nov 21 18:21:36 +0000 2022",
      "favorited" : false,
      "full_text" : "@StephenKing Did you pass some stinky wind Stephen?",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1594341808909197313"
          ],
          "editableUntil" : "2022-11-20T15:18:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBnVE",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "id_str" : "1594341808909197313",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1594341808909197313",
      "possibly_sensitive" : false,
      "created_at" : "Sun Nov 20 14:48:03 +0000 2022",
      "favorited" : false,
      "full_text" : "Boom! Just got some free Goerli ETH on https://t.co/jUMA9jBnVE in literally 1 minute.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1593700338477006850"
          ],
          "editableUntil" : "2022-11-18T20:49:04.870Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "0",
      "id_str" : "1593700338477006850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1593700338477006850",
      "created_at" : "Fri Nov 18 20:19:04 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @StephenKing: As Mark Twain might have said, \"The rumors of Twitter's death are greatly exaggerated.\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1593699906857803777"
          ],
          "editableUntil" : "2022-11-18T20:47:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "OriginolleY",
            "screen_name" : "HardcoreNolley",
            "indices" : [
              "10",
              "25"
            ],
            "id_str" : "142463798",
            "id" : "142463798"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1593681389937102851",
      "id_str" : "1593699906857803777",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1593699906857803777",
      "in_reply_to_status_id" : "1593681389937102851",
      "created_at" : "Fri Nov 18 20:17:21 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @HardcoreNolley Evidence of some sense.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1593524890535137280"
          ],
          "editableUntil" : "2022-11-18T09:11:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBnVE",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "0",
      "id_str" : "1593524890535137280",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1593524890535137280",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 18 08:41:54 +0000 2022",
      "favorited" : false,
      "full_text" : "Boom! Just got some free Goerli ETH on https://t.co/jUMA9jBnVE in literally 1 minute.   0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1592641524298264576"
          ],
          "editableUntil" : "2022-11-15T22:41:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1592618665933156352",
      "id_str" : "1592641524298264576",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1592641524298264576",
      "in_reply_to_status_id" : "1592618665933156352",
      "created_at" : "Tue Nov 15 22:11:43 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk Ligma didn't have time to change.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1592558456401457153"
          ],
          "editableUntil" : "2022-11-15T17:11:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBVLc",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "19",
              "42"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "114"
      ],
      "favorite_count" : "0",
      "id_str" : "1592558456401457153",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1592558456401457153",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 15 16:41:38 +0000 2022",
      "favorited" : false,
      "full_text" : "Just started using https://t.co/jUMA9jBVLc and it worked like a breeze!\n\nShoutout to Alchemy for making it happen.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1592117229126320130"
          ],
          "editableUntil" : "2022-11-14T11:58:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBVLc",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "1",
      "id_str" : "1592117229126320130",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1592117229126320130",
      "possibly_sensitive" : false,
      "created_at" : "Mon Nov 14 11:28:22 +0000 2022",
      "favorited" : false,
      "full_text" : "Boom! Just got some free Goerli ETH on https://t.co/jUMA9jBVLc in literally 1 minute.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1591817785633800193"
          ],
          "editableUntil" : "2022-11-13T16:08:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1591817785633800193",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1591817785633800193",
      "created_at" : "Sun Nov 13 15:38:29 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1591528749492748289"
          ],
          "editableUntil" : "2022-11-12T20:59:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBnVE",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "114",
              "137"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1591528749492748289",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1591528749492748289",
      "possibly_sensitive" : false,
      "created_at" : "Sat Nov 12 20:29:57 +0000 2022",
      "favorited" : false,
      "full_text" : "Thanks so much to the folks at Alchemy!\n\nJust used your faucet and it worked like a charm!\n\nYou can find it here: https://t.co/jUMA9jBnVE ☘",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1591332000929296384"
          ],
          "editableUntil" : "2022-11-12T07:58:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1591332000929296384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1591332000929296384",
      "created_at" : "Sat Nov 12 07:28:09 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1591048431912779779"
          ],
          "editableUntil" : "2022-11-11T13:11:21.075Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "1591048431912779779",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1591048431912779779",
      "created_at" : "Fri Nov 11 12:41:21 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: To be more precise, accounts doing parody impersonations. Basically, tricking people is not ok.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1591048387788697600"
          ],
          "editableUntil" : "2022-11-11T13:11:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "190"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1590886170543915009",
      "id_str" : "1591048387788697600",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1591048387788697600",
      "in_reply_to_status_id" : "1590886170543915009",
      "created_at" : "Fri Nov 11 12:41:10 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk Does that include accounts that set themselves up as being part of your community of like-minded individuals - that they hate - and then get you suspended when you take their bait?",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590997654905184256"
          ],
          "editableUntil" : "2022-11-11T09:49:34.893Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "RYAN SΞAN ADAMS - rsa.eth",
            "screen_name" : "RyanSAdams",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "14571055",
            "id" : "14571055"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "1590997654905184256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590997654905184256",
      "created_at" : "Fri Nov 11 09:19:34 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @RyanSAdams: Restore my faith.\n\nWho are the good people in crypto?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590997625997692928"
          ],
          "editableUntil" : "2022-11-11T09:49:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "RYAN SΞAN ADAMS - rsa.eth",
            "screen_name" : "RyanSAdams",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "14571055",
            "id" : "14571055"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef4ZzlJ",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1590844382353141760",
      "id_str" : "1590997625997692928",
      "in_reply_to_user_id" : "14571055",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590997625997692928",
      "in_reply_to_status_id" : "1590844382353141760",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 11 09:19:28 +0000 2022",
      "favorited" : false,
      "full_text" : "@RyanSAdams https://t.co/Iu5ef4ZzlJ",
      "lang" : "qme",
      "in_reply_to_screen_name" : "RyanSAdams",
      "in_reply_to_user_id_str" : "14571055"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590983816100732928"
          ],
          "editableUntil" : "2022-11-11T08:54:35.465Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "14",
              "26"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "id_str" : "1590983816100732928",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590983816100732928",
      "created_at" : "Fri Nov 11 08:24:35 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: @StephenKing 👻",
      "lang" : "qme"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590983805393055744"
          ],
          "editableUntil" : "2022-11-11T08:54:32.912Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "id_str" : "1590983805393055744",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590983805393055744",
      "created_at" : "Fri Nov 11 08:24:32 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @StephenKing: I think I liked Twitter better in the pre-Musk days. Less controversy, more fun.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590983685540818945"
          ],
          "editableUntil" : "2022-11-11T08:54:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "10",
              "22"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1590747753352933378",
      "id_str" : "1590983685540818945",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590983685540818945",
      "in_reply_to_status_id" : "1590747753352933378",
      "created_at" : "Fri Nov 11 08:24:04 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @StephenKing ahahahahahhhaaaaaaaa",
      "lang" : "tl",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590354286248341505"
          ],
          "editableUntil" : "2022-11-09T15:13:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBVLc",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "114",
              "137"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1590354286248341505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590354286248341505",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 09 14:43:03 +0000 2022",
      "favorited" : false,
      "full_text" : "Thanks so much to the folks at Alchemy!\n\nJust used your faucet and it worked like a charm!\n\nYou can find it here: https://t.co/jUMA9jBVLc ☘",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590056393792716801"
          ],
          "editableUntil" : "2022-11-08T19:29:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Q1bVeeCAOl",
            "expanded_url" : "https://university.alchemy.com/?a=223d0b8cc4",
            "display_url" : "university.alchemy.com/?a=223d0b8cc4",
            "indices" : [
              "192",
              "215"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "215"
      ],
      "favorite_count" : "0",
      "id_str" : "1590056393792716801",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590056393792716801",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 08 18:59:20 +0000 2022",
      "favorited" : false,
      "full_text" : "I did it!\n\nAfter days of FOMO, I’ve just claimed my early access NFT for Alchemy University 🚀\n\nCan’t wait to start diving deeper into web3 development!\n\nAlso, the applications are still open:\nhttps://t.co/Q1bVeeCAOl",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590021728599937025"
          ],
          "editableUntil" : "2022-11-08T17:11:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1590021728599937025",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590021728599937025",
      "created_at" : "Tue Nov 08 16:41:35 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589918856377925633"
          ],
          "editableUntil" : "2022-11-08T10:22:49.281Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anton Bukov 🦇🔊 ⚖️",
            "screen_name" : "k06a",
            "indices" : [
              "3",
              "8"
            ],
            "id_str" : "20413564",
            "id" : "20413564"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1589918856377925633",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589918856377925633",
      "created_at" : "Tue Nov 08 09:52:49 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @k06a: Who are you?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589710097843818497"
          ],
          "editableUntil" : "2022-11-07T20:33:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1589710097843818497",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589710097843818497",
      "created_at" : "Mon Nov 07 20:03:17 +0000 2022",
      "favorited" : false,
      "full_text" : "\"Who the hell are you people?\"",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589709683258187776"
          ],
          "editableUntil" : "2022-11-07T20:31:38.523Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "krinza.eth",
            "screen_name" : "kayprasla",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "874626622988603392",
            "id" : "874626622988603392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "id_str" : "1589709683258187776",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589709683258187776",
      "created_at" : "Mon Nov 07 20:01:38 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @kayprasla: Solidity for pleasure, Rust for money",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589709393230467073"
          ],
          "editableUntil" : "2022-11-07T20:30:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Eda",
            "screen_name" : "edatweets_",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1125494298059988992",
            "id" : "1125494298059988992"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1589684778789634050",
      "id_str" : "1589709393230467073",
      "in_reply_to_user_id" : "1125494298059988992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589709393230467073",
      "in_reply_to_status_id" : "1589684778789634050",
      "created_at" : "Mon Nov 07 20:00:29 +0000 2022",
      "favorited" : false,
      "full_text" : "@edatweets_ neither do they",
      "lang" : "en",
      "in_reply_to_screen_name" : "edatweets_",
      "in_reply_to_user_id_str" : "1125494298059988992"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695358438702760111"
          ],
          "editableUntil" : "2023-08-26T09:52:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "147",
              "170"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "183"
      ],
      "favorite_count" : "1",
      "id_str" : "1695358438702760111",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1695358438702760111",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 26 08:52:04 +0000 2023",
      "favorited" : false,
      "full_text" : "Ongoing frontend dev support.\n\nFuture dev ops infrastructure support.\n\nFuture backend engineering efforts (check out the whitepaper for details).\n\nhttps://t.co/6JUcz6pz0V\n\nInterested?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695339791888384197"
          ],
          "editableUntil" : "2023-08-26T08:37:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "id_str" : "1695339791888384197",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695339791888384197",
      "created_at" : "Sat Aug 26 07:37:58 +0000 2023",
      "favorited" : false,
      "full_text" : "Twipod requirements.\n\nInterested?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695338643383042493"
          ],
          "editableUntil" : "2023-08-26T08:33:25.108Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "crypto",
            "indices" : [
              "52",
              "59"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Altcoin Daily",
            "screen_name" : "AltcoinDailyio",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "958118843636854784",
            "id" : "958118843636854784"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "0",
      "id_str" : "1695338643383042493",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695338643383042493",
      "created_at" : "Sat Aug 26 07:33:25 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @AltcoinDailyio: Really feeling blessed to be in #crypto. So many big things coming. 😊🙏",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695162095304683675"
          ],
          "editableUntil" : "2023-08-25T20:51:52.766Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Justin Welsh",
            "screen_name" : "thejustinwelsh",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "19694536",
            "id" : "19694536"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "0",
      "id_str" : "1695162095304683675",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695162095304683675",
      "created_at" : "Fri Aug 25 19:51:52 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @thejustinwelsh: The riskiest move is always playing it safe.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695147414145925167"
          ],
          "editableUntil" : "2023-08-25T19:53:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "JAKE",
            "screen_name" : "JakeGagain",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1355014327988707329",
            "id" : "1355014327988707329"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1695104253776322727",
      "id_str" : "1695147414145925167",
      "in_reply_to_user_id" : "1355014327988707329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695147414145925167",
      "in_reply_to_status_id" : "1695104253776322727",
      "created_at" : "Fri Aug 25 18:53:32 +0000 2023",
      "favorited" : false,
      "full_text" : "@JakeGagain Bring it on.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JakeGagain",
      "in_reply_to_user_id_str" : "1355014327988707329"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695147389189857722"
          ],
          "editableUntil" : "2023-08-25T19:53:26.555Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "BullRun",
            "indices" : [
              "20",
              "28"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "JAKE",
            "screen_name" : "JakeGagain",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1355014327988707329",
            "id" : "1355014327988707329"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "id_str" : "1695147389189857722",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695147389189857722",
      "created_at" : "Fri Aug 25 18:53:26 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JakeGagain: The #BullRun Is Coming.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1695104192447180932"
          ],
          "editableUntil" : "2023-08-25T17:01:47.649Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Prof. Feynman",
            "screen_name" : "ProfFeynman",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "823518894182846464",
            "id" : "823518894182846464"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "id_str" : "1695104192447180932",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1695104192447180932",
      "created_at" : "Fri Aug 25 16:01:47 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ProfFeynman: If you cannot be corrected without being offended, then you’ll never truly grow in life.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694425642798887272"
          ],
          "editableUntil" : "2023-08-23T20:05:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Altcoin Daily",
            "screen_name" : "AltcoinDailyio",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "958118843636854784",
            "id" : "958118843636854784"
          },
          {
            "name" : "X",
            "screen_name" : "X",
            "indices" : [
              "16",
              "18"
            ],
            "id_str" : "783214",
            "id" : "783214"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1694151457623392459",
      "id_str" : "1694425642798887272",
      "in_reply_to_user_id" : "958118843636854784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694425642798887272",
      "in_reply_to_status_id" : "1694151457623392459",
      "created_at" : "Wed Aug 23 19:05:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@AltcoinDailyio @X He's gonna run the whole thing on DOGE nodes.",
      "lang" : "en",
      "in_reply_to_screen_name" : "AltcoinDailyio",
      "in_reply_to_user_id_str" : "958118843636854784"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694425570564604331"
          ],
          "editableUntil" : "2023-08-23T20:05:11.584Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Dogecoin",
            "indices" : [
              "124",
              "133"
            ]
          }
        ],
        "symbols" : [
          {
            "text" : "DOGE",
            "indices" : [
              "73",
              "78"
            ]
          }
        ],
        "user_mentions" : [
          {
            "name" : "Altcoin Daily",
            "screen_name" : "AltcoinDailyio",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "958118843636854784",
            "id" : "958118843636854784"
          },
          {
            "name" : "X",
            "screen_name" : "X",
            "indices" : [
              "93",
              "95"
            ],
            "id_str" : "783214",
            "id" : "783214"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1694425570564604331",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694425570564604331",
      "created_at" : "Wed Aug 23 19:05:11 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @AltcoinDailyio: There is a non-zero chance that Elon Musk integrates $DOGE natively into @X. \n\nIf/when that happens the #Dogecoin price…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694305545308524956"
          ],
          "editableUntil" : "2023-08-23T12:08:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Silvina Escudero",
            "screen_name" : "silvinaescudero",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "157149632",
            "id" : "157149632"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "17",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1694275265927561547",
      "id_str" : "1694305545308524956",
      "in_reply_to_user_id" : "157149632",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694305545308524956",
      "in_reply_to_status_id" : "1694275265927561547",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 23 11:08:15 +0000 2023",
      "favorited" : false,
      "full_text" : "@silvinaescudero https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "silvinaescudero",
      "in_reply_to_user_id_str" : "157149632"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694305416807649690"
          ],
          "editableUntil" : "2023-08-23T12:07:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Johnny",
            "screen_name" : "CryptoGodJohn",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "210623431",
            "id" : "210623431"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1694287537978683875",
      "id_str" : "1694305416807649690",
      "in_reply_to_user_id" : "210623431",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694305416807649690",
      "in_reply_to_status_id" : "1694287537978683875",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 23 11:07:44 +0000 2023",
      "favorited" : false,
      "full_text" : "@CryptoGodJohn https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "CryptoGodJohn",
      "in_reply_to_user_id_str" : "210623431"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694304973520089341"
          ],
          "editableUntil" : "2023-08-23T12:05:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Paulo Castagnoli",
            "screen_name" : "pcastagnoli",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "39394402",
            "id" : "39394402"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1694290682343473518",
      "id_str" : "1694304973520089341",
      "in_reply_to_user_id" : "39394402",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694304973520089341",
      "in_reply_to_status_id" : "1694290682343473518",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 23 11:05:59 +0000 2023",
      "favorited" : false,
      "full_text" : "@pcastagnoli https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "pcastagnoli",
      "in_reply_to_user_id_str" : "39394402"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694260259097866385"
          ],
          "editableUntil" : "2023-08-23T09:08:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Carlos",
            "screen_name" : "RealCarlosPaez_",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1609722012108201984",
            "id" : "1609722012108201984"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1693972387430097354",
      "id_str" : "1694260259097866385",
      "in_reply_to_user_id" : "1609722012108201984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694260259097866385",
      "in_reply_to_status_id" : "1693972387430097354",
      "created_at" : "Wed Aug 23 08:08:18 +0000 2023",
      "favorited" : false,
      "full_text" : "@RealCarlosPaez_ pearls before swine",
      "lang" : "en",
      "in_reply_to_screen_name" : "RealCarlosPaez_",
      "in_reply_to_user_id_str" : "1609722012108201984"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694227480465318334"
          ],
          "editableUntil" : "2023-08-23T06:58:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "JAKE",
            "screen_name" : "JakeGagain",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1355014327988707329",
            "id" : "1355014327988707329"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1693889239212253502",
      "id_str" : "1694227480465318334",
      "in_reply_to_user_id" : "1355014327988707329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694227480465318334",
      "in_reply_to_status_id" : "1693889239212253502",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 23 05:58:03 +0000 2023",
      "favorited" : false,
      "full_text" : "@JakeGagain https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "JakeGagain",
      "in_reply_to_user_id_str" : "1355014327988707329"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694042113577550119"
          ],
          "editableUntil" : "2023-08-22T18:41:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "non aesthetic things",
            "screen_name" : "PicturesFoIder",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "2538322138",
            "id" : "2538322138"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1693846181196243259",
      "id_str" : "1694042113577550119",
      "in_reply_to_user_id" : "2538322138",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694042113577550119",
      "in_reply_to_status_id" : "1693846181196243259",
      "created_at" : "Tue Aug 22 17:41:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@PicturesFoIder Once-upon-a-time, in my boxers...",
      "lang" : "en",
      "in_reply_to_screen_name" : "PicturesFoIder",
      "in_reply_to_user_id_str" : "2538322138"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1694020366019047621"
          ],
          "editableUntil" : "2023-08-22T17:15:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Andrew Hoyer",
            "screen_name" : "andrewhoyer",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "19413704",
            "id" : "19413704"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1693655448870867451",
      "id_str" : "1694020366019047621",
      "in_reply_to_user_id" : "19413704",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1694020366019047621",
      "in_reply_to_status_id" : "1693655448870867451",
      "created_at" : "Tue Aug 22 16:15:03 +0000 2023",
      "favorited" : false,
      "full_text" : "@andrewhoyer yup",
      "lang" : "und",
      "in_reply_to_screen_name" : "andrewhoyer",
      "in_reply_to_user_id_str" : "19413704"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692992134482178215"
          ],
          "editableUntil" : "2023-08-19T21:09:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kevin Zarantonello",
            "screen_name" : "kevfeelsgood",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1253745177459646466",
            "id" : "1253745177459646466"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1692907180951765452",
      "id_str" : "1692992134482178215",
      "in_reply_to_user_id" : "1253745177459646466",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692992134482178215",
      "in_reply_to_status_id" : "1692907180951765452",
      "created_at" : "Sat Aug 19 20:09:13 +0000 2023",
      "favorited" : false,
      "full_text" : "@kevfeelsgood bruv dude",
      "lang" : "en",
      "in_reply_to_screen_name" : "kevfeelsgood",
      "in_reply_to_user_id_str" : "1253745177459646466"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692991987614462005"
          ],
          "editableUntil" : "2023-08-19T21:08:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692991987614462005/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/eRrztgXxLk",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/F363G5YWsAEuD0T.jpg",
            "id_str" : "1692991839047954433",
            "id" : "1692991839047954433",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/F363G5YWsAEuD0T.jpg",
            "sizes" : {
              "small" : {
                "w" : "294",
                "h" : "294",
                "resize" : "fit"
              },
              "large" : {
                "w" : "294",
                "h" : "294",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "294",
                "h" : "294",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/eRrztgXxLk"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "0",
      "id_str" : "1692991987614462005",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692991987614462005",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 19 20:08:38 +0000 2023",
      "favorited" : false,
      "full_text" : "Maybe ...\n\n(.. no, not YOU, blackeyed-pea aka donut!) https://t.co/eRrztgXxLk",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692991987614462005/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/eRrztgXxLk",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/F363G5YWsAEuD0T.jpg",
            "id_str" : "1692991839047954433",
            "video_info" : {
              "aspect_ratio" : [
                "1",
                "1"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/F363G5YWsAEuD0T.mp4"
                }
              ]
            },
            "id" : "1692991839047954433",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/F363G5YWsAEuD0T.jpg",
            "sizes" : {
              "small" : {
                "w" : "294",
                "h" : "294",
                "resize" : "fit"
              },
              "large" : {
                "w" : "294",
                "h" : "294",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "294",
                "h" : "294",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/eRrztgXxLk"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692976378386296982"
          ],
          "editableUntil" : "2023-08-19T20:06:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Bright 🏴",
            "screen_name" : "brightraphael_",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1672812696",
            "id" : "1672812696"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1692899046577340425",
      "id_str" : "1692976378386296982",
      "in_reply_to_user_id" : "1672812696",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692976378386296982",
      "in_reply_to_status_id" : "1692899046577340425",
      "created_at" : "Sat Aug 19 19:06:37 +0000 2023",
      "favorited" : false,
      "full_text" : "@brightraphael_ Most definitely.",
      "lang" : "en",
      "in_reply_to_screen_name" : "brightraphael_",
      "in_reply_to_user_id_str" : "1672812696"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692657005574393867"
          ],
          "editableUntil" : "2023-08-18T22:57:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "JAKE",
            "screen_name" : "JakeGagain",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1355014327988707329",
            "id" : "1355014327988707329"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692616855020814718",
      "id_str" : "1692657005574393867",
      "in_reply_to_user_id" : "1355014327988707329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692657005574393867",
      "in_reply_to_status_id" : "1692616855020814718",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 18 21:57:32 +0000 2023",
      "favorited" : false,
      "full_text" : "@JakeGagain https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "JakeGagain",
      "in_reply_to_user_id_str" : "1355014327988707329"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589600331826335750"
          ],
          "editableUntil" : "2022-11-07T13:17:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "crypto",
            "indices" : [
              "67",
              "74"
            ]
          },
          {
            "text" : "testeth",
            "indices" : [
              "75",
              "83"
            ]
          },
          {
            "text" : "help",
            "indices" : [
              "84",
              "89"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "id_str" : "1589600331826335750",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589600331826335750",
      "created_at" : "Mon Nov 07 12:47:07 +0000 2022",
      "favorited" : false,
      "full_text" : "can you follow me please, i need &gt;50 followers to get Georli... #crypto #testeth #help",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589596614297260032"
          ],
          "editableUntil" : "2022-11-07T13:02:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1589596614297260032",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589596614297260032",
      "created_at" : "Mon Nov 07 12:32:20 +0000 2022",
      "favorited" : false,
      "full_text" : "0x746c8a5640e6D1CAF62f03E6a896788D462Ad0F4",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589259488695308288"
          ],
          "editableUntil" : "2022-11-06T14:42:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "0",
      "id_str" : "1589259488695308288",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589259488695308288",
      "created_at" : "Sun Nov 06 14:12:43 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C perhaps the faucet isn't working like it used to",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589258959092797440"
          ],
          "editableUntil" : "2022-11-06T14:40:37.508Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "crypto",
            "indices" : [
              "93",
              "100"
            ]
          },
          {
            "text" : "altcoins",
            "indices" : [
              "101",
              "110"
            ]
          },
          {
            "text" : "investing",
            "indices" : [
              "111",
              "121"
            ]
          },
          {
            "text" : "Cryptocurency",
            "indices" : [
              "122",
              "136"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SmoothyC",
            "screen_name" : "chrisLudwick28",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "1272543651982344194",
            "id" : "1272543651982344194"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "1589258959092797440",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589258959092797440",
      "created_at" : "Sun Nov 06 14:10:37 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @chrisLudwick28: What coin is your favorite and one you have big hopes for next bull run \n#crypto #altcoins #investing #Cryptocurency",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589258931070996485"
          ],
          "editableUntil" : "2022-11-06T14:40:30.827Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MedievalEmpires",
            "indices" : [
              "99",
              "115"
            ]
          },
          {
            "text" : "PlayToEarn",
            "indices" : [
              "116",
              "127"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SmoothyC",
            "screen_name" : "chrisLudwick28",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "1272543651982344194",
            "id" : "1272543651982344194"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1589258931070996485",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589258931070996485",
      "created_at" : "Sun Nov 06 14:10:30 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @chrisLudwick28: Medieval empires is going to massive , get on board , and get ready to battle.\n#MedievalEmpires #PlayToEarn #CryptoGami…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589212339580329984"
          ],
          "editableUntil" : "2022-11-06T11:35:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1589212339580329984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589212339580329984",
      "created_at" : "Sun Nov 06 11:05:22 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588582843458146304"
          ],
          "editableUntil" : "2022-11-04T17:53:58.979Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Eda",
            "screen_name" : "edatweets_",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1125494298059988992",
            "id" : "1125494298059988992"
          },
          {
            "name" : "Mina Protocol 🪶",
            "screen_name" : "MinaProtocol",
            "indices" : [
              "45",
              "58"
            ],
            "id_str" : "991439317053591552",
            "id" : "991439317053591552"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "id_str" : "1588582843458146304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588582843458146304",
      "created_at" : "Fri Nov 04 17:23:58 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @edatweets_: Created my first zkApp using @MinaProtocol 👩‍💻",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588582803368992768"
          ],
          "editableUntil" : "2022-11-04T17:53:49.421Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mudit Gupta",
            "screen_name" : "Mudit__Gupta",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "122360573",
            "id" : "122360573"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1588582803368992768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588582803368992768",
      "created_at" : "Fri Nov 04 17:23:49 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @Mudit__Gupta: My Goerli faucet is out of funds. The faucet got over 1 million requests yesterday.\n\nI don't think it's worth topping it…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588581358846509056"
          ],
          "editableUntil" : "2022-11-04T17:48:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "YouTube India",
            "screen_name" : "YouTubeIndia",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "180380465",
            "id" : "180380465"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1588510226176937986",
      "id_str" : "1588581358846509056",
      "in_reply_to_user_id" : "180380465",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588581358846509056",
      "in_reply_to_status_id" : "1588510226176937986",
      "created_at" : "Fri Nov 04 17:18:05 +0000 2022",
      "favorited" : false,
      "full_text" : "@YouTubeIndia This is the end.",
      "lang" : "en",
      "in_reply_to_screen_name" : "YouTubeIndia",
      "in_reply_to_user_id_str" : "180380465"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588581228646928387"
          ],
          "editableUntil" : "2022-11-04T17:47:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "1588581228646928387",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588581228646928387",
      "created_at" : "Fri Nov 04 17:17:33 +0000 2022",
      "favorited" : false,
      "full_text" : "How many tweets does a person need to get Goerli.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588580912622899200"
          ],
          "editableUntil" : "2022-11-04T17:46:18.632Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1588580912622899200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588580912622899200",
      "created_at" : "Fri Nov 04 17:16:18 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: Twitter has had a massive drop in revenue, due to activist groups pressuring advertisers, even though nothing has changed wit…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588580177952804864"
          ],
          "editableUntil" : "2022-11-04T17:43:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBVLc",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "19",
              "42"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "114"
      ],
      "favorite_count" : "0",
      "id_str" : "1588580177952804864",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588580177952804864",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 04 17:13:23 +0000 2022",
      "favorited" : false,
      "full_text" : "Just started using https://t.co/jUMA9jBVLc and it worked like a breeze!\n\nShoutout to Alchemy for making it happen.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588476796915572738"
          ],
          "editableUntil" : "2022-11-04T10:52:35.513Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Fabri",
            "screen_name" : "fabriguespe",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "150509030",
            "id" : "150509030"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "id_str" : "1588476796915572738",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588476796915572738",
      "created_at" : "Fri Nov 04 10:22:35 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @fabriguespe: I'm leaving web 2.0",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588476668733427714"
          ],
          "editableUntil" : "2022-11-04T10:52:04.952Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tim Urban",
            "screen_name" : "waitbutwhy",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1282121312",
            "id" : "1282121312"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "0",
      "id_str" : "1588476668733427714",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588476668733427714",
      "created_at" : "Fri Nov 04 10:22:04 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @waitbutwhy: What’s the craziest conspiracy theory you think might be true?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588476301991874561"
          ],
          "editableUntil" : "2022-11-04T10:50:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "0",
      "id_str" : "1588476301991874561",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588476301991874561",
      "created_at" : "Fri Nov 04 10:20:37 +0000 2022",
      "favorited" : false,
      "full_text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C Goerli Goerli",
      "lang" : "it"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588107136869060608"
          ],
          "editableUntil" : "2022-11-03T10:23:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBnVE",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "46",
              "69"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "id_str" : "1588107136869060608",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588107136869060608",
      "possibly_sensitive" : false,
      "created_at" : "Thu Nov 03 09:53:41 +0000 2022",
      "favorited" : false,
      "full_text" : "The rain animation💦🔥. Huge props to Alchemy!\n\nhttps://t.co/jUMA9jBnVE\n⬆⬆⬇⬇⬅➡⬅➡🅱🅰",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586685488815038464"
          ],
          "editableUntil" : "2022-10-30T12:14:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1586680643831836677",
      "id_str" : "1586685488815038464",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586685488815038464",
      "in_reply_to_status_id" : "1586680643831836677",
      "created_at" : "Sun Oct 30 11:44:34 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk My mate's just been suspended for satire.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586088406634795008"
          ],
          "editableUntil" : "2022-10-28T20:41:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Republicans against Trump",
            "screen_name" : "RpsAgainstTrump",
            "indices" : [
              "10",
              "26"
            ],
            "id_str" : "1221462414744596483",
            "id" : "1221462414744596483"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1586073042534297601",
      "id_str" : "1586088406634795008",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586088406634795008",
      "in_reply_to_status_id" : "1586073042534297601",
      "created_at" : "Fri Oct 28 20:11:58 +0000 2022",
      "favorited" : false,
      "full_text" : "@elonmusk @RpsAgainstTrump It's all about pre-acquisition and post-inquisition.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586088221804331009"
          ],
          "editableUntil" : "2022-10-28T20:41:14.829Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1586088221804331009",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586088221804331009",
      "created_at" : "Fri Oct 28 20:11:14 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: Twitter will be forming a content moderation council with widely diverse viewpoints. \n\nNo major content decisions or account…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586088144931373058"
          ],
          "editableUntil" : "2022-10-28T20:40:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Abhijit Majumder",
            "screen_name" : "abhijitmajumder",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "56039856",
            "id" : "56039856"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1585729498670305280",
      "id_str" : "1586088144931373058",
      "in_reply_to_user_id" : "56039856",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586088144931373058",
      "in_reply_to_status_id" : "1585729498670305280",
      "created_at" : "Fri Oct 28 20:10:56 +0000 2022",
      "favorited" : false,
      "full_text" : "@abhijitmajumder Jai Sita Ram.",
      "lang" : "in",
      "in_reply_to_screen_name" : "abhijitmajumder",
      "in_reply_to_user_id_str" : "56039856"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586087478918012928"
          ],
          "editableUntil" : "2022-10-28T20:38:17.711Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Abhijit Majumder",
            "screen_name" : "abhijitmajumder",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "56039856",
            "id" : "56039856"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/abhijitmajumder/status/1585729498670305280/video/1",
            "source_status_id" : "1585729498670305280",
            "indices" : [
              "72",
              "95"
            ],
            "url" : "https://t.co/RWW105fPLx",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1585729234987003904/img/DsdA6cQUpAwzrUho.jpg",
            "id_str" : "1585729234987003904",
            "source_user_id" : "56039856",
            "id" : "1585729234987003904",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1585729234987003904/img/DsdA6cQUpAwzrUho.jpg",
            "source_user_id_str" : "56039856",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1585729498670305280",
            "display_url" : "pic.twitter.com/RWW105fPLx"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "95"
      ],
      "favorite_count" : "0",
      "id_str" : "1586087478918012928",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586087478918012928",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 28 20:08:17 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @abhijitmajumder: Science marvels at the bridge that Lord Ram built. https://t.co/RWW105fPLx",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/abhijitmajumder/status/1585729498670305280/video/1",
            "source_status_id" : "1585729498670305280",
            "indices" : [
              "72",
              "95"
            ],
            "url" : "https://t.co/RWW105fPLx",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1585729234987003904/img/DsdA6cQUpAwzrUho.jpg",
            "id_str" : "1585729234987003904",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "145984",
              "variants" : [
                {
                  "bitrate" : "288000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1585729234987003904/vid/480x270/QRlSrjRV7Gtv8IL9.mp4?tag=14"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1585729234987003904/vid/640x360/vb99KQgl9q26tOrr.mp4?tag=14"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/amplify_video/1585729234987003904/pl/A-LV_3Rj6VjOGNpc.m3u8?tag=14&container=fmp4"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1585729234987003904/vid/1280x720/afTLyt6XU4sAZXU8.mp4?tag=14"
                }
              ]
            },
            "source_user_id" : "56039856",
            "additional_media_info" : {
              "title" : "",
              "description" : "",
              "embeddable" : true,
              "monetizable" : false
            },
            "id" : "1585729234987003904",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1585729234987003904/img/DsdA6cQUpAwzrUho.jpg",
            "source_user_id_str" : "56039856",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1585729498670305280",
            "display_url" : "pic.twitter.com/RWW105fPLx"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586084887630843904"
          ],
          "editableUntil" : "2022-10-28T20:27:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SmoothyC",
            "screen_name" : "chrisLudwick28",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1272543651982344194",
            "id" : "1272543651982344194"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "id_str" : "1586084887630843904",
      "in_reply_to_user_id" : "1272543651982344194",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586084887630843904",
      "created_at" : "Fri Oct 28 19:57:59 +0000 2022",
      "favorited" : false,
      "full_text" : "@chrisLudwick28 Happy Birthday Chris &lt;3 hoping it's a fab one.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chrisLudwick28",
      "in_reply_to_user_id_str" : "1272543651982344194"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586083678664335360"
          ],
          "editableUntil" : "2022-10-28T20:23:11.660Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1586083678664335360",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586083678664335360",
      "created_at" : "Fri Oct 28 19:53:11 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @elonmusk: 🎶 let the good times roll 🎶",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582381533125840896"
          ],
          "editableUntil" : "2022-10-18T15:12:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "16",
              "32"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/jUMA9jBVLc",
            "expanded_url" : "http://GoerliFaucet.com",
            "display_url" : "GoerliFaucet.com",
            "indices" : [
              "107",
              "130"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "0",
      "id_str" : "1582381533125840896",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582381533125840896",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 18 14:42:11 +0000 2022",
      "favorited" : false,
      "full_text" : "Thank you folks @AlchemyPlatform\n\nJust used your faucet and it worked like a charm!\n\nYou can find it here: https://t.co/jUMA9jBVLc ☘",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263440274231296"
          ],
          "editableUntil" : "2022-10-12T18:55:38.693Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263440274231296",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263440274231296",
      "created_at" : "Wed Oct 12 18:25:38 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 11 / Ready to build?\n\nThe AU website is LIVE today, with courses launching very soon!\n\n- Apply for early access using…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263409219559425"
          ],
          "editableUntil" : "2022-10-12T18:55:31.289Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263409219559425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263409219559425",
      "created_at" : "Wed Oct 12 18:25:31 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 8/ New to coding or don’t know JavaScript yet?\n\nThen AU’s JS Fundamentals course is the perfect foundation for becomin…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263399455264768"
          ],
          "editableUntil" : "2022-10-12T18:55:28.961Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263399455264768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263399455264768",
      "created_at" : "Wed Oct 12 18:25:28 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 7/ A killer collab:\n\nCombining Chainshot’s iconic bootcamps &amp; teachers w/ Alchemy programs like Road to Web3 makes AU…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263387174690817"
          ],
          "editableUntil" : "2022-10-12T18:55:26.033Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263387174690817",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263387174690817",
      "created_at" : "Wed Oct 12 18:25:26 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 6/ Project-based learning\n\nThe best way to learn is by building projects.\n\nThat’s why you’ll build your dApp portfolio…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263373551243264"
          ],
          "editableUntil" : "2022-10-12T18:55:22.785Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263373551243264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263373551243264",
      "created_at" : "Wed Oct 12 18:25:22 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 5/ Alongside 1000s of fellow builders, you’ll take part in practical bootcamps covering: \n\n✅ Cryptography\n✅ Solidity d…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263356782387200"
          ],
          "editableUntil" : "2022-10-12T18:55:18.787Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263356782387200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263356782387200",
      "created_at" : "Wed Oct 12 18:25:18 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 4/ Alchemy University isn’t just a web3 dev course, it’s an entire ecosystem for building your skills &amp; network.\n\nBein…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263344623464449"
          ],
          "editableUntil" : "2022-10-12T18:55:15.888Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263344623464449",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263344623464449",
      "created_at" : "Wed Oct 12 18:25:15 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 3/ Learning something new is tough, and accountability is hard.\n\nThat’s why we set out to create an education experien…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263314537357312"
          ],
          "editableUntil" : "2022-10-12T18:55:08.715Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263314537357312",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263314537357312",
      "created_at" : "Wed Oct 12 18:25:08 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 2/ We have a mission: to bring web3 to 1 billion people.\n\nThat means providing devs with the resources they need to bu…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580263280295411713"
          ],
          "editableUntil" : "2022-10-12T18:55:00.551Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Alchemy | The web3 developer platform",
            "screen_name" : "AlchemyPlatform",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "953748782394499072",
            "id" : "953748782394499072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1580263280295411713",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580263280295411713",
      "created_at" : "Wed Oct 12 18:25:00 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @AlchemyPlatform: 1/ Want to become a web3 dev?\n\nWhat if we told you we’re releasing the ultimate web3 learning platform… for free?\n\nCha…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692621037681197419"
          ],
          "editableUntil" : "2023-08-18T20:34:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "274"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692620444254310845",
      "id_str" : "1692621037681197419",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692621037681197419",
      "in_reply_to_status_id" : "1692620444254310845",
      "created_at" : "Fri Aug 18 19:34:37 +0000 2023",
      "favorited" : false,
      "full_text" : "We will write you any letter of truce you require.\n\nIt will say exactly what you need to say to resolve a situation amicably, and without fear of reprisal.\n\nGive us a shout and we'll get to work.\n\nAll you have to do is copy the letter and send it.\n\nMoney back guarantee.\n\n2)",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692620444254310845"
          ],
          "editableUntil" : "2023-08-18T20:32:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "184"
      ],
      "favorite_count" : "0",
      "id_str" : "1692620444254310845",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692620444254310845",
      "created_at" : "Fri Aug 18 19:32:15 +0000 2023",
      "favorited" : false,
      "full_text" : "🧵\n\nEver found yourself so deeply in the shite you didn't know which way to turn?\n\nEver wanted to resolve a situation, but had no idea what to do to fix it?\n\nYOUR WAIT IS OVER .... \n\n1)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692619720720052672"
          ],
          "editableUntil" : "2023-08-18T20:29:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Suvadeep Paul",
            "screen_name" : "paul_suvadeep",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1012993604481150977",
            "id" : "1012993604481150977"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "87"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1692530827329180132",
      "id_str" : "1692619720720052672",
      "in_reply_to_user_id" : "1012993604481150977",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692619720720052672",
      "in_reply_to_status_id" : "1692530827329180132",
      "created_at" : "Fri Aug 18 19:29:23 +0000 2023",
      "favorited" : false,
      "full_text" : "@paul_suvadeep but it costs £100M for a brain transplant so they can write a unique one",
      "lang" : "en",
      "in_reply_to_screen_name" : "paul_suvadeep",
      "in_reply_to_user_id_str" : "1012993604481150977"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692580122119778734"
          ],
          "editableUntil" : "2023-08-18T17:52:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "NotMyMess",
            "indices" : [
              "0",
              "10"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "10"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692578870392717471",
      "id_str" : "1692580122119778734",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692580122119778734",
      "in_reply_to_status_id" : "1692578870392717471",
      "created_at" : "Fri Aug 18 16:52:02 +0000 2023",
      "favorited" : false,
      "full_text" : "#NotMyMess",
      "lang" : "qht",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692578870392717471"
          ],
          "editableUntil" : "2023-08-18T17:47:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692578870392717471/photo/1",
            "indices" : [
              "18",
              "41"
            ],
            "url" : "https://t.co/ggjpi98zfq",
            "media_url" : "http://pbs.twimg.com/media/F30_fbMXwAo9UPl.jpg",
            "id_str" : "1692578844069314570",
            "id" : "1692578844069314570",
            "media_url_https" : "https://pbs.twimg.com/media/F30_fbMXwAo9UPl.jpg",
            "sizes" : {
              "medium" : {
                "w" : "601",
                "h" : "447",
                "resize" : "fit"
              },
              "large" : {
                "w" : "601",
                "h" : "447",
                "resize" : "fit"
              },
              "small" : {
                "w" : "601",
                "h" : "447",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ggjpi98zfq"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1692578870392717471",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692578870392717471",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 18 16:47:03 +0000 2023",
      "favorited" : false,
      "full_text" : "Although ... oops https://t.co/ggjpi98zfq",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692578870392717471/photo/1",
            "indices" : [
              "18",
              "41"
            ],
            "url" : "https://t.co/ggjpi98zfq",
            "media_url" : "http://pbs.twimg.com/media/F30_fbMXwAo9UPl.jpg",
            "id_str" : "1692578844069314570",
            "id" : "1692578844069314570",
            "media_url_https" : "https://pbs.twimg.com/media/F30_fbMXwAo9UPl.jpg",
            "sizes" : {
              "medium" : {
                "w" : "601",
                "h" : "447",
                "resize" : "fit"
              },
              "large" : {
                "w" : "601",
                "h" : "447",
                "resize" : "fit"
              },
              "small" : {
                "w" : "601",
                "h" : "447",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ggjpi98zfq"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692576452347101349"
          ],
          "editableUntil" : "2023-08-18T17:37:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "NotAGoodLook",
            "indices" : [
              "69",
              "82"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "82"
      ],
      "favorite_count" : "0",
      "id_str" : "1692576452347101349",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692576452347101349",
      "created_at" : "Fri Aug 18 16:37:27 +0000 2023",
      "favorited" : false,
      "full_text" : "Someone knows the inner workings of the world-of-incel, don't they.\n\n#NotAGoodLook",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692575059641090254"
          ],
          "editableUntil" : "2023-08-18T17:31:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692575000841142681",
      "id_str" : "1692575059641090254",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692575059641090254",
      "in_reply_to_status_id" : "1692575000841142681",
      "created_at" : "Fri Aug 18 16:31:55 +0000 2023",
      "favorited" : false,
      "full_text" : "Thank you and good night.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692575000841142681"
          ],
          "editableUntil" : "2023-08-18T17:31:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692575000841142681/photo/1",
            "indices" : [
              "57",
              "80"
            ],
            "url" : "https://t.co/cVGi3sL3qd",
            "media_url" : "http://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "id_str" : "1692574949863571456",
            "id" : "1692574949863571456",
            "media_url_https" : "https://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "635",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/cVGi3sL3qd"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1692574110004527427",
      "id_str" : "1692575000841142681",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1692575000841142681",
      "in_reply_to_status_id" : "1692574110004527427",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 18 16:31:41 +0000 2023",
      "favorited" : false,
      "full_text" : "And we would all appreciate very much it if you would .. https://t.co/cVGi3sL3qd",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692575000841142681/photo/1",
            "indices" : [
              "57",
              "80"
            ],
            "url" : "https://t.co/cVGi3sL3qd",
            "media_url" : "http://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "id_str" : "1692574949863571456",
            "id" : "1692574949863571456",
            "media_url_https" : "https://pbs.twimg.com/media/F3078wJXwAAT49W.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "635",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "800",
                "h" : "747",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/cVGi3sL3qd"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692574110004527427"
          ],
          "editableUntil" : "2023-08-18T17:28:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692574110004527427/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/tNDAmcurk5",
            "media_url" : "http://pbs.twimg.com/media/F307LHSW4AAIR6I.jpg",
            "id_str" : "1692574097081819136",
            "id" : "1692574097081819136",
            "media_url_https" : "https://pbs.twimg.com/media/F307LHSW4AAIR6I.jpg",
            "sizes" : {
              "medium" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "large" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/tNDAmcurk5"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692574034251202761",
      "id_str" : "1692574110004527427",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692574110004527427",
      "in_reply_to_status_id" : "1692574034251202761",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 18 16:28:08 +0000 2023",
      "favorited" : false,
      "full_text" : "As long as you https://t.co/tNDAmcurk5",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692574110004527427/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/tNDAmcurk5",
            "media_url" : "http://pbs.twimg.com/media/F307LHSW4AAIR6I.jpg",
            "id_str" : "1692574097081819136",
            "id" : "1692574097081819136",
            "media_url_https" : "https://pbs.twimg.com/media/F307LHSW4AAIR6I.jpg",
            "sizes" : {
              "medium" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "large" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/tNDAmcurk5"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692574034251202761"
          ],
          "editableUntil" : "2023-08-18T17:27:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692574034251202761/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/TBrHxdrfYy",
            "media_url" : "http://pbs.twimg.com/media/F307G6ZXwA4J995.png",
            "id_str" : "1692574024902098958",
            "id" : "1692574024902098958",
            "media_url_https" : "https://pbs.twimg.com/media/F307G6ZXwA4J995.png",
            "sizes" : {
              "large" : {
                "w" : "540",
                "h" : "303",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "540",
                "h" : "303",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "303",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TBrHxdrfYy"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "1692574034251202761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692574034251202761",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 18 16:27:50 +0000 2023",
      "favorited" : false,
      "full_text" : "There's ... https://t.co/TBrHxdrfYy",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1692574034251202761/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/TBrHxdrfYy",
            "media_url" : "http://pbs.twimg.com/media/F307G6ZXwA4J995.png",
            "id_str" : "1692574024902098958",
            "id" : "1692574024902098958",
            "media_url_https" : "https://pbs.twimg.com/media/F307G6ZXwA4J995.png",
            "sizes" : {
              "large" : {
                "w" : "540",
                "h" : "303",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "540",
                "h" : "303",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "303",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TBrHxdrfYy"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692496552441381026"
          ],
          "editableUntil" : "2023-08-18T12:19:57.824Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "crypto",
            "indices" : [
              "20",
              "27"
            ]
          },
          {
            "text" : "1000x",
            "indices" : [
              "54",
              "60"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Paulo Castagnoli",
            "screen_name" : "pcastagnoli",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "39394402",
            "id" : "39394402"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "0",
      "id_str" : "1692496552441381026",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692496552441381026",
      "created_at" : "Fri Aug 18 11:19:57 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @pcastagnoli: GM #crypto fam!💎 \n\nShill me the next #1000x 🔥👇",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692477888514170929"
          ],
          "editableUntil" : "2023-08-18T11:05:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ryan M 🖋🌎",
            "screen_name" : "ryanantm",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1650268092520341504",
            "id" : "1650268092520341504"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692190294752813342",
      "id_str" : "1692477888514170929",
      "in_reply_to_user_id" : "1650268092520341504",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692477888514170929",
      "in_reply_to_status_id" : "1692190294752813342",
      "created_at" : "Fri Aug 18 10:05:47 +0000 2023",
      "favorited" : false,
      "full_text" : "@ryanantm Oh yes, we are indeed.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ryanantm",
      "in_reply_to_user_id_str" : "1650268092520341504"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692477519931363617"
          ],
          "editableUntil" : "2023-08-18T11:04:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Rice Tycoon",
            "screen_name" : "TheRiceTycoon",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1653403712600014854",
            "id" : "1653403712600014854"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692162611981496661",
      "id_str" : "1692477519931363617",
      "in_reply_to_user_id" : "1653403712600014854",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692477519931363617",
      "in_reply_to_status_id" : "1692162611981496661",
      "created_at" : "Fri Aug 18 10:04:20 +0000 2023",
      "favorited" : false,
      "full_text" : "@TheRiceTycoon Music is the love of my life.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TheRiceTycoon",
      "in_reply_to_user_id_str" : "1653403712600014854"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692467857450229863"
          ],
          "editableUntil" : "2023-08-18T10:25:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ThePatrator",
            "screen_name" : "ThePatrator",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1661092412968583186",
            "id" : "1661092412968583186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1692224771466072449",
      "id_str" : "1692467857450229863",
      "in_reply_to_user_id" : "1661092412968583186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692467857450229863",
      "in_reply_to_status_id" : "1692224771466072449",
      "created_at" : "Fri Aug 18 09:25:56 +0000 2023",
      "favorited" : false,
      "full_text" : "@ThePatrator ... being a chef and scratching his nuts all day long.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ThePatrator",
      "in_reply_to_user_id_str" : "1661092412968583186"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692450081427820818"
          ],
          "editableUntil" : "2023-08-18T09:15:18.271Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "id_str" : "1692450081427820818",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692450081427820818",
      "created_at" : "Fri Aug 18 08:15:18 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @elonmusk: What do you want to make of it?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692450067502747844"
          ],
          "editableUntil" : "2023-08-18T09:15:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692310375872749625",
      "id_str" : "1692450067502747844",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692450067502747844",
      "in_reply_to_status_id" : "1692310375872749625",
      "created_at" : "Fri Aug 18 08:15:14 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk Healing.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692277560523047305"
          ],
          "editableUntil" : "2023-08-17T21:49:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jazmin Pinedo",
            "screen_name" : "jazminpinedo",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "239241254",
            "id" : "239241254"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692271024417407405",
      "id_str" : "1692277560523047305",
      "in_reply_to_user_id" : "239241254",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692277560523047305",
      "in_reply_to_status_id" : "1692271024417407405",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 17 20:49:46 +0000 2023",
      "favorited" : false,
      "full_text" : "@jazminpinedo https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "jazminpinedo",
      "in_reply_to_user_id_str" : "239241254"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692277400908767460"
          ],
          "editableUntil" : "2023-08-17T21:49:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Amen Dhahri",
            "screen_name" : "dev_amendh",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1510013777001029640",
            "id" : "1510013777001029640"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1692151792883396899",
      "id_str" : "1692277400908767460",
      "in_reply_to_user_id" : "1510013777001029640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692277400908767460",
      "in_reply_to_status_id" : "1692151792883396899",
      "created_at" : "Thu Aug 17 20:49:08 +0000 2023",
      "favorited" : false,
      "full_text" : "@dev_amendh With a very big stick.",
      "lang" : "en",
      "in_reply_to_screen_name" : "dev_amendh",
      "in_reply_to_user_id_str" : "1510013777001029640"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692267481996345377"
          ],
          "editableUntil" : "2023-08-17T21:09:43.174Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Fox Crypto",
            "screen_name" : "FoxCryptoBSC",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "419697640",
            "id" : "419697640"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "1692267481996345377",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692267481996345377",
      "created_at" : "Thu Aug 17 20:09:43 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @FoxCryptoBSC: 🚀      🚀       🔥🔥        🚀🚀       🔥 \n🚀      🚀    🔥       🔥    🚀    🚀   🔥                                     \n🚀🚀🚀   🔥…",
      "lang" : "art"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1692247104767295937"
          ],
          "editableUntil" : "2023-08-17T19:48:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Shibetoshi Nakamoto",
            "screen_name" : "BillyM2k",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "30699048",
            "id" : "30699048"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1692238375942775262",
      "id_str" : "1692247104767295937",
      "in_reply_to_user_id" : "30699048",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1692247104767295937",
      "in_reply_to_status_id" : "1692238375942775262",
      "created_at" : "Thu Aug 17 18:48:44 +0000 2023",
      "favorited" : false,
      "full_text" : "@BillyM2k God NO, I'm sooooo annoying.",
      "lang" : "en",
      "in_reply_to_screen_name" : "BillyM2k",
      "in_reply_to_user_id_str" : "30699048"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691956575852761406"
          ],
          "editableUntil" : "2023-08-17T00:34:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Charlie Bullen",
            "screen_name" : "ImCharlieBullen",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1615008233353093122",
            "id" : "1615008233353093122"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691856101594071218",
      "id_str" : "1691956575852761406",
      "in_reply_to_user_id" : "1615008233353093122",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691956575852761406",
      "in_reply_to_status_id" : "1691856101594071218",
      "created_at" : "Wed Aug 16 23:34:17 +0000 2023",
      "favorited" : false,
      "full_text" : "@ImCharlieBullen more like a saw-tooth non-narrative",
      "lang" : "en",
      "in_reply_to_screen_name" : "ImCharlieBullen",
      "in_reply_to_user_id_str" : "1615008233353093122"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691924318421184623"
          ],
          "editableUntil" : "2023-08-16T22:26:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1691790248886632535",
      "id_str" : "1691924318421184623",
      "in_reply_to_user_id" : "1601800309960888320",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691924318421184623",
      "in_reply_to_status_id" : "1691790248886632535",
      "created_at" : "Wed Aug 16 21:26:06 +0000 2023",
      "favorited" : false,
      "full_text" : "@NicholasBTY I AM happiness.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ItsNickJonesy",
      "in_reply_to_user_id_str" : "1601800309960888320"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691924091551289716"
          ],
          "editableUntil" : "2023-08-16T22:25:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Justin Welsh",
            "screen_name" : "thejustinwelsh",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "19694536",
            "id" : "19694536"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1691834605001715773",
      "id_str" : "1691924091551289716",
      "in_reply_to_user_id" : "19694536",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691924091551289716",
      "in_reply_to_status_id" : "1691834605001715773",
      "created_at" : "Wed Aug 16 21:25:12 +0000 2023",
      "favorited" : false,
      "full_text" : "@thejustinwelsh When I made my first million by simply being amazing.",
      "lang" : "en",
      "in_reply_to_screen_name" : "thejustinwelsh",
      "in_reply_to_user_id_str" : "19694536"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691923890182737941"
          ],
          "editableUntil" : "2023-08-16T22:24:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SlumDOGE Millionaire",
            "screen_name" : "ProTheDoge",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1358176095850229761",
            "id" : "1358176095850229761"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691919778053800171",
      "id_str" : "1691923890182737941",
      "in_reply_to_user_id" : "1358176095850229761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691923890182737941",
      "in_reply_to_status_id" : "1691919778053800171",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 16 21:24:24 +0000 2023",
      "favorited" : false,
      "full_text" : "@ProTheDoge https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ProTheDoge",
      "in_reply_to_user_id_str" : "1358176095850229761"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691886664539361450"
          ],
          "editableUntil" : "2023-08-16T19:56:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kristijan | Digital Ace",
            "screen_name" : "vilibic",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "4615583081",
            "id" : "4615583081"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691770373774139458",
      "id_str" : "1691886664539361450",
      "in_reply_to_user_id" : "4615583081",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691886664539361450",
      "in_reply_to_status_id" : "1691770373774139458",
      "created_at" : "Wed Aug 16 18:56:29 +0000 2023",
      "favorited" : false,
      "full_text" : "@vilibic Reality.",
      "lang" : "en",
      "in_reply_to_screen_name" : "vilibic",
      "in_reply_to_user_id_str" : "4615583081"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691810411740360845"
          ],
          "editableUntil" : "2023-08-16T14:53:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Daniel Cranney 🇬🇧",
            "screen_name" : "danielcranney",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1360916557476597768",
            "id" : "1360916557476597768"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691712399739355321",
      "id_str" : "1691810411740360845",
      "in_reply_to_user_id" : "1360916557476597768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691810411740360845",
      "in_reply_to_status_id" : "1691712399739355321",
      "created_at" : "Wed Aug 16 13:53:29 +0000 2023",
      "favorited" : false,
      "full_text" : "@danielcranney No further info required.",
      "lang" : "en",
      "in_reply_to_screen_name" : "danielcranney",
      "in_reply_to_user_id_str" : "1360916557476597768"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691716129763291414"
          ],
          "editableUntil" : "2023-08-16T08:38:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691691661640778019",
      "id_str" : "1691716129763291414",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691716129763291414",
      "in_reply_to_status_id" : "1691691661640778019",
      "created_at" : "Wed Aug 16 07:38:50 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk Needle in a hackstack.\n\nBug in a rug.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691504833021276160"
          ],
          "editableUntil" : "2023-08-15T18:39:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CoinMarketCap",
            "screen_name" : "CoinMarketCap",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "2260491445",
            "id" : "2260491445"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691487413888339968",
      "id_str" : "1691504833021276160",
      "in_reply_to_user_id" : "2260491445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691504833021276160",
      "in_reply_to_status_id" : "1691487413888339968",
      "created_at" : "Tue Aug 15 17:39:13 +0000 2023",
      "favorited" : false,
      "full_text" : "@CoinMarketCap BTC, of course",
      "lang" : "en",
      "in_reply_to_screen_name" : "CoinMarketCap",
      "in_reply_to_user_id_str" : "2260491445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691332871108055040"
          ],
          "editableUntil" : "2023-08-15T07:15:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "JAKE",
            "screen_name" : "JakeGagain",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1355014327988707329",
            "id" : "1355014327988707329"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691318298435309568",
      "id_str" : "1691332871108055040",
      "in_reply_to_user_id" : "1355014327988707329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691332871108055040",
      "in_reply_to_status_id" : "1691318298435309568",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 15 06:15:54 +0000 2023",
      "favorited" : false,
      "full_text" : "@JakeGagain https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "JakeGagain",
      "in_reply_to_user_id_str" : "1355014327988707329"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691331654696992768"
          ],
          "editableUntil" : "2023-08-15T07:11:04.559Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "19",
              "28"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "0",
      "id_str" : "1691331654696992768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691331654696992768",
      "created_at" : "Tue Aug 15 06:11:04 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: @elonmusk Hey Elon, what about gang stalking by government officials?\n\nAsking for a friend.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691331499881041920"
          ],
          "editableUntil" : "2023-08-15T07:10:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1688022163574439937",
      "id_str" : "1691331499881041920",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1691331499881041920",
      "in_reply_to_status_id" : "1688022163574439937",
      "created_at" : "Tue Aug 15 06:10:27 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk Hey Elon, what about gang stalking by government officials?\n\nAsking for a friend.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691070036889174016"
          ],
          "editableUntil" : "2023-08-14T13:51:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sofia Zamolo",
            "screen_name" : "sofizamolo",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "153243904",
            "id" : "153243904"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691054943774355456",
      "id_str" : "1691070036889174016",
      "in_reply_to_user_id" : "153243904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691070036889174016",
      "in_reply_to_status_id" : "1691054943774355456",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 14 12:51:30 +0000 2023",
      "favorited" : false,
      "full_text" : "@sofizamolo https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "sofizamolo",
      "in_reply_to_user_id_str" : "153243904"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691069891615379456"
          ],
          "editableUntil" : "2023-08-14T13:50:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SharksCoins 🦈 Gem Hunter",
            "screen_name" : "SharksCoins",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1568227771",
            "id" : "1568227771"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691068653888827392",
      "id_str" : "1691069891615379456",
      "in_reply_to_user_id" : "1568227771",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691069891615379456",
      "in_reply_to_status_id" : "1691068653888827392",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 14 12:50:55 +0000 2023",
      "favorited" : false,
      "full_text" : "@SharksCoins https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "SharksCoins",
      "in_reply_to_user_id_str" : "1568227771"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1691049115730264064"
          ],
          "editableUntil" : "2023-08-14T12:28:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Paulo Castagnoli",
            "screen_name" : "pcastagnoli",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "39394402",
            "id" : "39394402"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1691003811144306689",
      "id_str" : "1691049115730264064",
      "in_reply_to_user_id" : "39394402",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1691049115730264064",
      "in_reply_to_status_id" : "1691003811144306689",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 14 11:28:22 +0000 2023",
      "favorited" : false,
      "full_text" : "@pcastagnoli https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "pcastagnoli",
      "in_reply_to_user_id_str" : "39394402"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690864888267059200"
          ],
          "editableUntil" : "2023-08-14T00:16:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "YourPOP",
            "screen_name" : "Yourpop8",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1347777544649641985",
            "id" : "1347777544649641985"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "10",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1690836886183378944",
      "id_str" : "1690864888267059200",
      "in_reply_to_user_id" : "1347777544649641985",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690864888267059200",
      "in_reply_to_status_id" : "1690836886183378944",
      "possibly_sensitive" : false,
      "created_at" : "Sun Aug 13 23:16:18 +0000 2023",
      "favorited" : false,
      "full_text" : "@Yourpop8 https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Yourpop8",
      "in_reply_to_user_id_str" : "1347777544649641985"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690811864081403905"
          ],
          "editableUntil" : "2023-08-13T20:45:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1690743970450620416",
      "id_str" : "1690811864081403905",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690811864081403905",
      "in_reply_to_status_id" : "1690743970450620416",
      "created_at" : "Sun Aug 13 19:45:36 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk o god help us",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690670898066432000"
          ],
          "editableUntil" : "2023-08-13T11:25:27.902Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1690670898066432000",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690670898066432000",
      "created_at" : "Sun Aug 13 10:25:27 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @_david__wright_: Have you taken feedback to heart and got emotional about it? How do you deal with harsh sometimes what feels like atta…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690637190051536896"
          ],
          "editableUntil" : "2023-08-13T09:11:31.285Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "id_str" : "1690637190051536896",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690637190051536896",
      "created_at" : "Sun Aug 13 08:11:31 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @_david__wright_: Where do you find your comfort?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690637170384519168"
          ],
          "editableUntil" : "2023-08-13T09:11:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Wright ☀️",
            "screen_name" : "_david__wright_",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "2883228803",
            "id" : "2883228803"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1690504446260719616",
      "id_str" : "1690637170384519168",
      "in_reply_to_user_id" : "2883228803",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690637170384519168",
      "in_reply_to_status_id" : "1690504446260719616",
      "created_at" : "Sun Aug 13 08:11:26 +0000 2023",
      "favorited" : false,
      "full_text" : "@_david__wright_ In nature: in wind, rain, sun, snow, cloud, mist, clarity. \n\nIn the forest, on the sea, up the high mountains.\n\nNature.",
      "lang" : "en",
      "in_reply_to_screen_name" : "_david__wright_",
      "in_reply_to_user_id_str" : "2883228803"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690472014673223680"
          ],
          "editableUntil" : "2023-08-12T22:15:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "place where cat shouldn't be",
            "screen_name" : "catshouldnt",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1333062067356532736",
            "id" : "1333062067356532736"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689726774576381952",
      "id_str" : "1690472014673223680",
      "in_reply_to_user_id" : "1333062067356532736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690472014673223680",
      "in_reply_to_status_id" : "1689726774576381952",
      "created_at" : "Sat Aug 12 21:15:10 +0000 2023",
      "favorited" : false,
      "full_text" : "@catshouldnt I hope that cat's not dead bruv.",
      "lang" : "en",
      "in_reply_to_screen_name" : "catshouldnt",
      "in_reply_to_user_id_str" : "1333062067356532736"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690471706261897216"
          ],
          "editableUntil" : "2023-08-12T22:13:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "YourPOP",
            "screen_name" : "Yourpop8",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1347777544649641985",
            "id" : "1347777544649641985"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "10",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1690423342786912256",
      "id_str" : "1690471706261897216",
      "in_reply_to_user_id" : "1347777544649641985",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690471706261897216",
      "in_reply_to_status_id" : "1690423342786912256",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 12 21:13:56 +0000 2023",
      "favorited" : false,
      "full_text" : "@Yourpop8 https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Yourpop8",
      "in_reply_to_user_id_str" : "1347777544649641985"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690276710669807617"
          ],
          "editableUntil" : "2023-08-12T09:19:06.303Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dogecoin",
            "screen_name" : "dogecoin",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "2235729541",
            "id" : "2235729541"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/dogecoin/status/1651659742974976000/photo/1",
            "source_status_id" : "1651659742974976000",
            "indices" : [
              "14",
              "37"
            ],
            "url" : "https://t.co/fdGc5bvVDY",
            "media_url" : "http://pbs.twimg.com/media/FuvfyCPWIDAQnyc.jpg",
            "id_str" : "1651659739049107504",
            "source_user_id" : "2235729541",
            "id" : "1651659739049107504",
            "media_url_https" : "https://pbs.twimg.com/media/FuvfyCPWIDAQnyc.jpg",
            "source_user_id_str" : "2235729541",
            "sizes" : {
              "small" : {
                "w" : "500",
                "h" : "666",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "500",
                "h" : "666",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "500",
                "h" : "666",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1651659742974976000",
            "display_url" : "pic.twitter.com/fdGc5bvVDY"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "1690276710669807617",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690276710669807617",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 12 08:19:06 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @dogecoin: https://t.co/fdGc5bvVDY",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/dogecoin/status/1651659742974976000/photo/1",
            "source_status_id" : "1651659742974976000",
            "indices" : [
              "14",
              "37"
            ],
            "url" : "https://t.co/fdGc5bvVDY",
            "media_url" : "http://pbs.twimg.com/media/FuvfyCPWIDAQnyc.jpg",
            "id_str" : "1651659739049107504",
            "source_user_id" : "2235729541",
            "id" : "1651659739049107504",
            "media_url_https" : "https://pbs.twimg.com/media/FuvfyCPWIDAQnyc.jpg",
            "source_user_id_str" : "2235729541",
            "sizes" : {
              "small" : {
                "w" : "500",
                "h" : "666",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "500",
                "h" : "666",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "500",
                "h" : "666",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1651659742974976000",
            "display_url" : "pic.twitter.com/fdGc5bvVDY"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690276640675258369"
          ],
          "editableUntil" : "2023-08-12T09:18:49.615Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "curt",
            "screen_name" : "akaCurt",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "1044634861686771712",
            "id" : "1044634861686771712"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/akaCurt/status/1661931818483068931/photo/1",
            "source_status_id" : "1661931818483068931",
            "indices" : [
              "33",
              "56"
            ],
            "url" : "https://t.co/Y8ROMxO7Rq",
            "media_url" : "http://pbs.twimg.com/media/FxBeLkzaAAA2Ryl.jpg",
            "id_str" : "1661931815450574848",
            "source_user_id" : "1044634861686771712",
            "id" : "1661931815450574848",
            "media_url_https" : "https://pbs.twimg.com/media/FxBeLkzaAAA2Ryl.jpg",
            "source_user_id_str" : "1044634861686771712",
            "sizes" : {
              "small" : {
                "w" : "622",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "903",
                "h" : "987",
                "resize" : "fit"
              },
              "large" : {
                "w" : "903",
                "h" : "987",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1661931818483068931",
            "display_url" : "pic.twitter.com/Y8ROMxO7Rq"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "0",
      "id_str" : "1690276640675258369",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690276640675258369",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 12 08:18:49 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @akaCurt: Who likes to color? https://t.co/Y8ROMxO7Rq",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/akaCurt/status/1661931818483068931/photo/1",
            "source_status_id" : "1661931818483068931",
            "indices" : [
              "33",
              "56"
            ],
            "url" : "https://t.co/Y8ROMxO7Rq",
            "media_url" : "http://pbs.twimg.com/media/FxBeLkzaAAA2Ryl.jpg",
            "id_str" : "1661931815450574848",
            "source_user_id" : "1044634861686771712",
            "id" : "1661931815450574848",
            "media_url_https" : "https://pbs.twimg.com/media/FxBeLkzaAAA2Ryl.jpg",
            "source_user_id_str" : "1044634861686771712",
            "sizes" : {
              "small" : {
                "w" : "622",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "903",
                "h" : "987",
                "resize" : "fit"
              },
              "large" : {
                "w" : "903",
                "h" : "987",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1661931818483068931",
            "display_url" : "pic.twitter.com/Y8ROMxO7Rq"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690108934072209408"
          ],
          "editableUntil" : "2023-08-11T22:12:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "271"
      ],
      "favorite_count" : "0",
      "id_str" : "1690108934072209408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690108934072209408",
      "created_at" : "Fri Aug 11 21:12:25 +0000 2023",
      "favorited" : false,
      "full_text" : "If this takes off folks, there'll be tons of seriously well-paid jobs, AND, AAANNNNNDDDDD, stocks/shares/tokens.\n\nSo. Keep it coming. I like it.\n\nI'm REALLY good at some stuff, totally useless at other stuff.\n\nMarketing and networking, I suck at, as you may have noticed.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690106996328902656"
          ],
          "editableUntil" : "2023-08-11T22:04:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1690106639993413632",
      "id_str" : "1690106996328902656",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690106996328902656",
      "in_reply_to_status_id" : "1690106639993413632",
      "created_at" : "Fri Aug 11 21:04:43 +0000 2023",
      "favorited" : false,
      "full_text" : "Or, I love you person, or two, I really do.\n\nYou crack me up and make me smile.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690106639993413632"
          ],
          "editableUntil" : "2023-08-11T22:03:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "id_str" : "1690106639993413632",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690106639993413632",
      "created_at" : "Fri Aug 11 21:03:18 +0000 2023",
      "favorited" : false,
      "full_text" : "I love you people. I really do.\n\nYou crack me up and make me smile.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690106202909188096"
          ],
          "editableUntil" : "2023-08-11T22:01:34.085Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "place where cat shouldn't be",
            "screen_name" : "catshouldnt",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1333062067356532736",
            "id" : "1333062067356532736"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/catshouldnt/status/1689726774576381952/video/1",
            "source_status_id" : "1689726774576381952",
            "indices" : [
              "50",
              "73"
            ],
            "url" : "https://t.co/i9MkHgWlJJ",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1689725871303598080/pu/img/i_FbN6kiXkQ3sclN.jpg",
            "id_str" : "1689725871303598080",
            "source_user_id" : "1333062067356532736",
            "id" : "1689725871303598080",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1689725871303598080/pu/img/i_FbN6kiXkQ3sclN.jpg",
            "source_user_id_str" : "1333062067356532736",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "1280",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1689726774576381952",
            "display_url" : "pic.twitter.com/i9MkHgWlJJ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "0",
      "id_str" : "1690106202909188096",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690106202909188096",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 11 21:01:34 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @catshouldnt: She found perfect place to sleep https://t.co/i9MkHgWlJJ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/catshouldnt/status/1689726774576381952/video/1",
            "source_status_id" : "1689726774576381952",
            "indices" : [
              "50",
              "73"
            ],
            "url" : "https://t.co/i9MkHgWlJJ",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1689725871303598080/pu/img/i_FbN6kiXkQ3sclN.jpg",
            "id_str" : "1689725871303598080",
            "video_info" : {
              "aspect_ratio" : [
                "9",
                "16"
              ],
              "duration_millis" : "8597",
              "variants" : [
                {
                  "bitrate" : "950000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1689725871303598080/pu/vid/480x852/aHaAIdt3YEm_HrnJ.mp4?tag=12"
                },
                {
                  "bitrate" : "632000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1689725871303598080/pu/vid/320x568/NNNdILWb32vDbjkT.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1689725871303598080/pu/pl/ornRrafWYkP1EZeW.m3u8?tag=12&container=fmp4&v=e55"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1689725871303598080/pu/vid/720x1280/iYM0t9HbDJ0Z7Q6D.mp4?tag=12"
                }
              ]
            },
            "source_user_id" : "1333062067356532736",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1689725871303598080",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1689725871303598080/pu/img/i_FbN6kiXkQ3sclN.jpg",
            "source_user_id_str" : "1333062067356532736",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "1280",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1689726774576381952",
            "display_url" : "pic.twitter.com/i9MkHgWlJJ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690103385767198721"
          ],
          "editableUntil" : "2023-08-11T21:50:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Bitcoin",
            "indices" : [
              "39",
              "47"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SlumDOGE Millionaire",
            "screen_name" : "ProTheDoge",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1358176095850229761",
            "id" : "1358176095850229761"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1689815133454057472",
      "id_str" : "1690103385767198721",
      "in_reply_to_user_id" : "1358176095850229761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690103385767198721",
      "in_reply_to_status_id" : "1689815133454057472",
      "created_at" : "Fri Aug 11 20:50:22 +0000 2023",
      "favorited" : false,
      "full_text" : "@ProTheDoge We're gonna see a $100,000 #Bitcoin shortly I expect.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ProTheDoge",
      "in_reply_to_user_id_str" : "1358176095850229761"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690102992161173505"
          ],
          "editableUntil" : "2023-08-11T21:48:48.583Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SlumDOGE Millionaire",
            "screen_name" : "ProTheDoge",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1358176095850229761",
            "id" : "1358176095850229761"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "id_str" : "1690102992161173505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690102992161173505",
      "created_at" : "Fri Aug 11 20:48:48 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ProTheDoge: What is the most underrated meme coin right now?! 🤔🚀 go! 👇🏼",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690102484310585345"
          ],
          "editableUntil" : "2023-08-11T21:46:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SlumDOGE Millionaire",
            "screen_name" : "ProTheDoge",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1358176095850229761",
            "id" : "1358176095850229761"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1690073338423705603",
      "id_str" : "1690102484310585345",
      "in_reply_to_user_id" : "1358176095850229761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690102484310585345",
      "in_reply_to_status_id" : "1690073338423705603",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 11 20:46:47 +0000 2023",
      "favorited" : false,
      "full_text" : "@ProTheDoge https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ProTheDoge",
      "in_reply_to_user_id_str" : "1358176095850229761"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690101633227579393"
          ],
          "editableUntil" : "2023-08-11T21:43:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Nathan James",
            "screen_name" : "nsjames_",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1138211041614147584",
            "id" : "1138211041614147584"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689926515327152128",
      "id_str" : "1690101633227579393",
      "in_reply_to_user_id" : "1138211041614147584",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690101633227579393",
      "in_reply_to_status_id" : "1689926515327152128",
      "created_at" : "Fri Aug 11 20:43:24 +0000 2023",
      "favorited" : false,
      "full_text" : "@nsjames_ A girlfriend 😂😂🤣🤣😅 :(",
      "lang" : "en",
      "in_reply_to_screen_name" : "nsjames_",
      "in_reply_to_user_id_str" : "1138211041614147584"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690087210387746816"
          ],
          "editableUntil" : "2023-08-11T20:46:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Andy Griffiths",
            "screen_name" : "brandymedia",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "19739647",
            "id" : "19739647"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1689752407243132929",
      "id_str" : "1690087210387746816",
      "in_reply_to_user_id" : "19739647",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690087210387746816",
      "in_reply_to_status_id" : "1689752407243132929",
      "created_at" : "Fri Aug 11 19:46:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@brandymedia Backend.",
      "lang" : "en",
      "in_reply_to_screen_name" : "brandymedia",
      "in_reply_to_user_id_str" : "19739647"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690075431741870080"
          ],
          "editableUntil" : "2023-08-11T19:59:17.667Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Teslaconomics/status/1689692692622790656/video/1",
            "source_status_id" : "1689692692622790656",
            "indices" : [
              "14",
              "37"
            ],
            "url" : "https://t.co/vxMQiOsrfL",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1689692594081796096/img/utYJyPXyKcHFso5v.jpg",
            "id_str" : "1689692594081796096",
            "source_user_id" : "985243593538338816",
            "id" : "1689692594081796096",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1689692594081796096/img/utYJyPXyKcHFso5v.jpg",
            "source_user_id_str" : "985243593538338816",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "540",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "306",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "864",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1689692692622790656",
            "display_url" : "pic.twitter.com/vxMQiOsrfL"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "1690075431741870080",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690075431741870080",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 11 18:59:17 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @elonmusk: https://t.co/vxMQiOsrfL",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/Teslaconomics/status/1689692692622790656/video/1",
            "source_status_id" : "1689692692622790656",
            "indices" : [
              "14",
              "37"
            ],
            "url" : "https://t.co/vxMQiOsrfL",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1689692594081796096/img/utYJyPXyKcHFso5v.jpg",
            "id_str" : "1689692594081796096",
            "video_info" : {
              "aspect_ratio" : [
                "20",
                "9"
              ],
              "duration_millis" : "17866",
              "variants" : [
                {
                  "bitrate" : "288000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1689692594081796096/vid/600x270/oSdKOYYTtUosvSKH.mp4?tag=14"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1689692594081796096/vid/800x360/M7XoAuP-zuJnuEWS.mp4?tag=14"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/amplify_video/1689692594081796096/pl/H-anYRnHlzeI3KNt.m3u8?tag=14&container=fmp4"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1689692594081796096/vid/1600x720/tpI2Yy4Xqjm_dDDn.mp4?tag=14"
                }
              ]
            },
            "source_user_id" : "985243593538338816",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1689692594081796096",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1689692594081796096/img/utYJyPXyKcHFso5v.jpg",
            "source_user_id_str" : "985243593538338816",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "540",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "306",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "864",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1689692692622790656",
            "display_url" : "pic.twitter.com/vxMQiOsrfL"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1690075068687106048"
          ],
          "editableUntil" : "2023-08-11T19:57:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "10",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1690026529785356288",
      "id_str" : "1690075068687106048",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1690075068687106048",
      "in_reply_to_status_id" : "1690026529785356288",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 11 18:57:51 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689736659850649600"
          ],
          "editableUntil" : "2023-08-10T21:33:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "unusual_whales",
            "screen_name" : "unusual_whales",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1200616796295847936",
            "id" : "1200616796295847936"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689640493242892288",
      "id_str" : "1689736659850649600",
      "in_reply_to_user_id" : "1200616796295847936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689736659850649600",
      "in_reply_to_status_id" : "1689640493242892288",
      "created_at" : "Thu Aug 10 20:33:08 +0000 2023",
      "favorited" : false,
      "full_text" : "@unusual_whales Right now, it's 29.9%.",
      "lang" : "en",
      "in_reply_to_screen_name" : "unusual_whales",
      "in_reply_to_user_id_str" : "1200616796295847936"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689736548789506048"
          ],
          "editableUntil" : "2023-08-10T21:32:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "YourPOP",
            "screen_name" : "Yourpop8",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1347777544649641985",
            "id" : "1347777544649641985"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "10",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689649487218913280",
      "id_str" : "1689736548789506048",
      "in_reply_to_user_id" : "1347777544649641985",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689736548789506048",
      "in_reply_to_status_id" : "1689649487218913280",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 20:32:41 +0000 2023",
      "favorited" : false,
      "full_text" : "@Yourpop8 https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Yourpop8",
      "in_reply_to_user_id_str" : "1347777544649641985"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689736426760327169"
          ],
          "editableUntil" : "2023-08-10T21:32:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "mewtru •ᴗ•",
            "screen_name" : "trunarla",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "105669760",
            "id" : "105669760"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689411694030893057",
      "id_str" : "1689736426760327169",
      "in_reply_to_user_id" : "105669760",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689736426760327169",
      "in_reply_to_status_id" : "1689411694030893057",
      "created_at" : "Thu Aug 10 20:32:12 +0000 2023",
      "favorited" : false,
      "full_text" : "@trunarla Great interview question.",
      "lang" : "en",
      "in_reply_to_screen_name" : "trunarla",
      "in_reply_to_user_id_str" : "105669760"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689733812534542336"
          ],
          "editableUntil" : "2023-08-10T21:21:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Shibetoshi Nakamoto",
            "screen_name" : "BillyM2k",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "30699048",
            "id" : "30699048"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689679259315675136",
      "id_str" : "1689733812534542336",
      "in_reply_to_user_id" : "30699048",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689733812534542336",
      "in_reply_to_status_id" : "1689679259315675136",
      "created_at" : "Thu Aug 10 20:21:49 +0000 2023",
      "favorited" : false,
      "full_text" : "@BillyM2k February. No explanation required.",
      "lang" : "en",
      "in_reply_to_screen_name" : "BillyM2k",
      "in_reply_to_user_id_str" : "30699048"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689733533344915456"
          ],
          "editableUntil" : "2023-08-10T21:20:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Declaration of Memes",
            "screen_name" : "LibertyCappy",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1492007194388279333",
            "id" : "1492007194388279333"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689438611911917569",
      "id_str" : "1689733533344915456",
      "in_reply_to_user_id" : "1492007194388279333",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689733533344915456",
      "in_reply_to_status_id" : "1689438611911917569",
      "created_at" : "Thu Aug 10 20:20:42 +0000 2023",
      "favorited" : false,
      "full_text" : "@LibertyCappy Hand her the bullets.",
      "lang" : "en",
      "in_reply_to_screen_name" : "LibertyCappy",
      "in_reply_to_user_id_str" : "1492007194388279333"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689730963423510530"
          ],
          "editableUntil" : "2023-08-10T21:10:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Gokhshtein",
            "screen_name" : "davidgokhshtein",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "170049408",
            "id" : "170049408"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "17",
              "40"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689416239913820160",
      "id_str" : "1689730963423510530",
      "in_reply_to_user_id" : "170049408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689730963423510530",
      "in_reply_to_status_id" : "1689416239913820160",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 20:10:30 +0000 2023",
      "favorited" : false,
      "full_text" : "@davidgokhshtein https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "davidgokhshtein",
      "in_reply_to_user_id_str" : "170049408"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689730859367059456"
          ],
          "editableUntil" : "2023-08-10T21:10:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Andrew Marshall",
            "screen_name" : "Andtism",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1543611251347128322",
            "id" : "1543611251347128322"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1689697942762934272",
      "id_str" : "1689730859367059456",
      "in_reply_to_user_id" : "1543611251347128322",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689730859367059456",
      "in_reply_to_status_id" : "1689697942762934272",
      "created_at" : "Thu Aug 10 20:10:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@Andtism It's called the Binge-Purge Program for Young Professionals.\n\nDM for details.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Andtism",
      "in_reply_to_user_id_str" : "1543611251347128322"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689727056496492544"
          ],
          "editableUntil" : "2023-08-10T20:54:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "JAKE",
            "screen_name" : "JakeGagain",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1355014327988707329",
            "id" : "1355014327988707329"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689608784975626240",
      "id_str" : "1689727056496492544",
      "in_reply_to_user_id" : "1355014327988707329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689727056496492544",
      "in_reply_to_status_id" : "1689608784975626240",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 19:54:58 +0000 2023",
      "favorited" : false,
      "full_text" : "@JakeGagain https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "JakeGagain",
      "in_reply_to_user_id_str" : "1355014327988707329"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689726963944972288"
          ],
          "editableUntil" : "2023-08-10T20:54:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Fox Crypto",
            "screen_name" : "FoxCryptoBSC",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "419697640",
            "id" : "419697640"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689708692512428033",
      "id_str" : "1689726963944972288",
      "in_reply_to_user_id" : "419697640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689726963944972288",
      "in_reply_to_status_id" : "1689708692512428033",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 19:54:36 +0000 2023",
      "favorited" : false,
      "full_text" : "@FoxCryptoBSC https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "FoxCryptoBSC",
      "in_reply_to_user_id_str" : "419697640"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689726769694150657"
          ],
          "editableUntil" : "2023-08-10T20:53:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ian Heinisch",
            "screen_name" : "ianheinischmma",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "2428287120",
            "id" : "2428287120"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689714481524297728",
      "id_str" : "1689726769694150657",
      "in_reply_to_user_id" : "2428287120",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689726769694150657",
      "in_reply_to_status_id" : "1689714481524297728",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 19:53:50 +0000 2023",
      "favorited" : false,
      "full_text" : "@ianheinischmma https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "ianheinischmma",
      "in_reply_to_user_id_str" : "2428287120"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689723900295335937"
          ],
          "editableUntil" : "2023-08-10T20:42:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sofia Zamolo",
            "screen_name" : "sofizamolo",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "153243904",
            "id" : "153243904"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "12",
              "35"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689610928658984961",
      "id_str" : "1689723900295335937",
      "in_reply_to_user_id" : "153243904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689723900295335937",
      "in_reply_to_status_id" : "1689610928658984961",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 19:42:26 +0000 2023",
      "favorited" : false,
      "full_text" : "@sofizamolo https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "sofizamolo",
      "in_reply_to_user_id_str" : "153243904"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689719164754096128"
          ],
          "editableUntil" : "2023-08-10T20:23:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris",
            "screen_name" : "_ChrisWrites_",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1597699877806477313",
            "id" : "1597699877806477313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689537508567031808",
      "id_str" : "1689719164754096128",
      "in_reply_to_user_id" : "1597699877806477313",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689719164754096128",
      "in_reply_to_status_id" : "1689537508567031808",
      "created_at" : "Thu Aug 10 19:23:36 +0000 2023",
      "favorited" : false,
      "full_text" : "@_ChrisWrites_ It's gotta be done. \n\nWhen you're inspired by something very powerful, how can you say no?",
      "lang" : "en",
      "in_reply_to_screen_name" : "_ChrisWrites_",
      "in_reply_to_user_id_str" : "1597699877806477313"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689719001205686272"
          ],
          "editableUntil" : "2023-08-10T20:22:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689698126620196865",
      "id_str" : "1689719001205686272",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689719001205686272",
      "in_reply_to_status_id" : "1689698126620196865",
      "created_at" : "Thu Aug 10 19:22:58 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj That's right.",
      "lang" : "en",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689718966288084992"
          ],
          "editableUntil" : "2023-08-10T20:22:49.680Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "crypto",
            "indices" : [
              "23",
              "30"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "0",
      "id_str" : "1689718966288084992",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689718966288084992",
      "created_at" : "Thu Aug 10 19:22:49 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @yourcryptodj: With #crypto, it is possible to change your life 🙋‍♂️",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689717035180175361"
          ],
          "editableUntil" : "2023-08-10T20:15:09.268Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Whale",
            "screen_name" : "WhaleChart",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "3359503481",
            "id" : "3359503481"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "1689717035180175361",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689717035180175361",
      "created_at" : "Thu Aug 10 19:15:09 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @WhaleChart: Dogecoin is better money than USD",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689716231798976512"
          ],
          "editableUntil" : "2023-08-10T20:11:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Physics In History",
            "screen_name" : "PhysInHistory",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1288841746898534401",
            "id" : "1288841746898534401"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "19"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689650032126160896",
      "id_str" : "1689716231798976512",
      "in_reply_to_user_id" : "1288841746898534401",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689716231798976512",
      "in_reply_to_status_id" : "1689650032126160896",
      "created_at" : "Thu Aug 10 19:11:57 +0000 2023",
      "favorited" : false,
      "full_text" : "@PhysInHistory God.",
      "lang" : "und",
      "in_reply_to_screen_name" : "PhysInHistory",
      "in_reply_to_user_id_str" : "1288841746898534401"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689715948763172864"
          ],
          "editableUntil" : "2023-08-10T20:10:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689713558177644545",
      "id_str" : "1689715948763172864",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689715948763172864",
      "in_reply_to_status_id" : "1689713558177644545",
      "created_at" : "Thu Aug 10 19:10:50 +0000 2023",
      "favorited" : false,
      "full_text" : "...and if he wasn't, he should \n\n...and if he needs any help, he only has to ask the JackC",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689713558177644545"
          ],
          "editableUntil" : "2023-08-10T20:01:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1689713558177644545/photo/1",
            "indices" : [
              "274",
              "297"
            ],
            "url" : "https://t.co/FFW0dP9eKL",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/F3MRcEdWoAAO2gF.jpg",
            "id_str" : "1689713459124936704",
            "id" : "1689713459124936704",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/F3MRcEdWoAAO2gF.jpg",
            "sizes" : {
              "large" : {
                "w" : "498",
                "h" : "498",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "498",
                "h" : "498",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "498",
                "h" : "498",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/FFW0dP9eKL"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "297"
      ],
      "favorite_count" : "0",
      "id_str" : "1689713558177644545",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689713558177644545",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 19:01:20 +0000 2023",
      "favorited" : false,
      "full_text" : "There's no doubt in my mind... Elon is going to...\n\n- Decentralize Twitter\n- Run it entirely on the DOGE network\n- Let us mere mortal users run nodes\n- Have DOGE as the incentivization coin\n- And we'll all be members of the DEGEN-X community\n\nMeine Gotte. \n\nIt's beautiful. https://t.co/FFW0dP9eKL",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1689713558177644545/photo/1",
            "indices" : [
              "274",
              "297"
            ],
            "url" : "https://t.co/FFW0dP9eKL",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/F3MRcEdWoAAO2gF.jpg",
            "id_str" : "1689713459124936704",
            "video_info" : {
              "aspect_ratio" : [
                "1",
                "1"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/F3MRcEdWoAAO2gF.mp4"
                }
              ]
            },
            "id" : "1689713459124936704",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/F3MRcEdWoAAO2gF.jpg",
            "sizes" : {
              "large" : {
                "w" : "498",
                "h" : "498",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "498",
                "h" : "498",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "498",
                "h" : "498",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/FFW0dP9eKL"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689702011711688705"
          ],
          "editableUntil" : "2023-08-10T19:15:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Rupali Haldiya",
            "screen_name" : "rupali_codes",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1391356559431802882",
            "id" : "1391356559431802882"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689574447664267264",
      "id_str" : "1689702011711688705",
      "in_reply_to_user_id" : "1391356559431802882",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689702011711688705",
      "in_reply_to_status_id" : "1689574447664267264",
      "created_at" : "Thu Aug 10 18:15:27 +0000 2023",
      "favorited" : false,
      "full_text" : "@rupali_codes as long as it works, i don't care",
      "lang" : "en",
      "in_reply_to_screen_name" : "rupali_codes",
      "in_reply_to_user_id_str" : "1391356559431802882"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689701823257468928"
          ],
          "editableUntil" : "2023-08-10T19:14:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Amrin",
            "screen_name" : "CoderAmrin",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1428524211799089155",
            "id" : "1428524211799089155"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689641924477825026",
      "id_str" : "1689701823257468928",
      "in_reply_to_user_id" : "1428524211799089155",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689701823257468928",
      "in_reply_to_status_id" : "1689641924477825026",
      "created_at" : "Thu Aug 10 18:14:42 +0000 2023",
      "favorited" : false,
      "full_text" : "@CoderAmrin yoga",
      "lang" : "in",
      "in_reply_to_screen_name" : "CoderAmrin",
      "in_reply_to_user_id_str" : "1428524211799089155"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689690093903097870"
          ],
          "editableUntil" : "2023-08-10T18:28:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Daniel Cranney 🇬🇧",
            "screen_name" : "danielcranney",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1360916557476597768",
            "id" : "1360916557476597768"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689663172708302848",
      "id_str" : "1689690093903097870",
      "in_reply_to_user_id" : "1360916557476597768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689690093903097870",
      "in_reply_to_status_id" : "1689663172708302848",
      "created_at" : "Thu Aug 10 17:28:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@danielcranney Pigeon racing mostly.",
      "lang" : "en",
      "in_reply_to_screen_name" : "danielcranney",
      "in_reply_to_user_id_str" : "1360916557476597768"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689685641913671681"
          ],
          "editableUntil" : "2023-08-10T18:10:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen",
            "screen_name" : "TheStephenProm",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1657953058029203456",
            "id" : "1657953058029203456"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1689622702938636289",
      "id_str" : "1689685641913671681",
      "in_reply_to_user_id" : "1657953058029203456",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689685641913671681",
      "in_reply_to_status_id" : "1689622702938636289",
      "created_at" : "Thu Aug 10 17:10:24 +0000 2023",
      "favorited" : false,
      "full_text" : "@TheStephenProm A plumber.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TheStephenProm",
      "in_reply_to_user_id_str" : "1657953058029203456"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689674414386814976"
          ],
          "editableUntil" : "2023-08-10T17:25:47.679Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Prof. Feynman",
            "screen_name" : "ProfFeynman",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "823518894182846464",
            "id" : "823518894182846464"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ProfFeynman/status/1689468022849748993/photo/1",
            "source_status_id" : "1689468022849748993",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/4JHbI5D8hA",
            "media_url" : "http://pbs.twimg.com/media/F3IyI4xXwAE4EuH.jpg",
            "id_str" : "1689467938477162497",
            "source_user_id" : "823518894182846464",
            "id" : "1689467938477162497",
            "media_url_https" : "https://pbs.twimg.com/media/F3IyI4xXwAE4EuH.jpg",
            "source_user_id_str" : "823518894182846464",
            "sizes" : {
              "large" : {
                "w" : "564",
                "h" : "737",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "520",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "564",
                "h" : "737",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1689468022849748993",
            "display_url" : "pic.twitter.com/4JHbI5D8hA"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "0",
      "id_str" : "1689674414386814976",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689674414386814976",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 16:25:47 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ProfFeynman: Equations that changed the world. https://t.co/4JHbI5D8hA",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/ProfFeynman/status/1689468022849748993/photo/1",
            "source_status_id" : "1689468022849748993",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/4JHbI5D8hA",
            "media_url" : "http://pbs.twimg.com/media/F3IyI4xXwAE4EuH.jpg",
            "id_str" : "1689467938477162497",
            "source_user_id" : "823518894182846464",
            "id" : "1689467938477162497",
            "media_url_https" : "https://pbs.twimg.com/media/F3IyI4xXwAE4EuH.jpg",
            "source_user_id_str" : "823518894182846464",
            "sizes" : {
              "large" : {
                "w" : "564",
                "h" : "737",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "520",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "564",
                "h" : "737",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1689468022849748993",
            "display_url" : "pic.twitter.com/4JHbI5D8hA"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689635232281145344"
          ],
          "editableUntil" : "2023-08-10T14:50:05.937Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Whale",
            "screen_name" : "WhaleChart",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "3359503481",
            "id" : "3359503481"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "0",
      "id_str" : "1689635232281145344",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689635232281145344",
      "created_at" : "Thu Aug 10 13:50:05 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @WhaleChart: JUST IN:\n\nPayPal to offer interest reward for Bitcoin and crypto deposits",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689623399755059200"
          ],
          "editableUntil" : "2023-08-10T14:03:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Whale",
            "screen_name" : "WhaleChart",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "3359503481",
            "id" : "3359503481"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1689623115897188352",
      "id_str" : "1689623399755059200",
      "in_reply_to_user_id" : "3359503481",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689623399755059200",
      "in_reply_to_status_id" : "1689623115897188352",
      "created_at" : "Thu Aug 10 13:03:04 +0000 2023",
      "favorited" : false,
      "full_text" : "@WhaleChart OH REALLY!",
      "lang" : "en",
      "in_reply_to_screen_name" : "WhaleChart",
      "in_reply_to_user_id_str" : "3359503481"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689621327341068289"
          ],
          "editableUntil" : "2023-08-10T13:54:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1689579889794695168",
      "id_str" : "1689621327341068289",
      "in_reply_to_user_id" : "1613830464774754304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689621327341068289",
      "in_reply_to_status_id" : "1689579889794695168",
      "created_at" : "Thu Aug 10 12:54:50 +0000 2023",
      "favorited" : false,
      "full_text" : "@DoneByRyan sorry dude",
      "lang" : "en",
      "in_reply_to_screen_name" : "ItsRyanHughes",
      "in_reply_to_user_id_str" : "1613830464774754304"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689621198777339904"
          ],
          "editableUntil" : "2023-08-10T13:54:20.089Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Anastasia",
            "screen_name" : "sdhjra",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1503499710111555584",
            "id" : "1503499710111555584"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/sdhjra/status/1666687677440352257/photo/1",
            "source_status_id" : "1666687677440352257",
            "indices" : [
              "44",
              "67"
            ],
            "url" : "https://t.co/a4JcH5fGeQ",
            "media_url" : "http://pbs.twimg.com/media/FyFDl6CacAcfdQC.jpg",
            "id_str" : "1666687655617392647",
            "source_user_id" : "1503499710111555584",
            "id" : "1666687655617392647",
            "media_url_https" : "https://pbs.twimg.com/media/FyFDl6CacAcfdQC.jpg",
            "source_user_id_str" : "1503499710111555584",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1666687677440352257",
            "display_url" : "pic.twitter.com/a4JcH5fGeQ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "id_str" : "1689621198777339904",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689621198777339904",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 12:54:20 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @sdhjra: Today we have a cat meeting.😂😂😂 https://t.co/a4JcH5fGeQ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/sdhjra/status/1666687677440352257/photo/1",
            "source_status_id" : "1666687677440352257",
            "indices" : [
              "44",
              "67"
            ],
            "url" : "https://t.co/a4JcH5fGeQ",
            "media_url" : "http://pbs.twimg.com/media/FyFDl6CacAcfdQC.jpg",
            "id_str" : "1666687655617392647",
            "source_user_id" : "1503499710111555584",
            "id" : "1666687655617392647",
            "media_url_https" : "https://pbs.twimg.com/media/FyFDl6CacAcfdQC.jpg",
            "source_user_id_str" : "1503499710111555584",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1666687677440352257",
            "display_url" : "pic.twitter.com/a4JcH5fGeQ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689620529030795264"
          ],
          "editableUntil" : "2023-08-10T13:51:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "⭒𝐯𝐥𝐨𝐞⭒",
            "screen_name" : "v3nusangels",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "849633295830847488",
            "id" : "849633295830847488"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/RBHsMcKClW",
            "expanded_url" : "https://www.youtube.com/watch?v=x3ov9USxVxY",
            "display_url" : "youtube.com/watch?v=x3ov9U…",
            "indices" : [
              "44",
              "67"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "14",
      "in_reply_to_status_id_str" : "1689424701192392704",
      "id_str" : "1689620529030795264",
      "in_reply_to_user_id" : "849633295830847488",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1689620529030795264",
      "in_reply_to_status_id" : "1689424701192392704",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 10 12:51:40 +0000 2023",
      "favorited" : false,
      "full_text" : "@v3nusangels Hmm actually, maybe this one:\n\nhttps://t.co/RBHsMcKClW",
      "lang" : "en",
      "in_reply_to_screen_name" : "v3nusangels",
      "in_reply_to_user_id_str" : "849633295830847488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689619678870589440"
          ],
          "editableUntil" : "2023-08-10T13:48:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Yousef يوسف",
            "screen_name" : "Yousef__Shadid",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "750609036",
            "id" : "750609036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1689557013741842432",
      "id_str" : "1689619678870589440",
      "in_reply_to_user_id" : "750609036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689619678870589440",
      "in_reply_to_status_id" : "1689557013741842432",
      "created_at" : "Thu Aug 10 12:48:17 +0000 2023",
      "favorited" : false,
      "full_text" : "@Yousef__Shadid Pure vanity bruv.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Yousef__Shadid",
      "in_reply_to_user_id_str" : "750609036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689619500163792896"
          ],
          "editableUntil" : "2023-08-10T13:47:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ha Le Huy",
            "screen_name" : "iamhuyha",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1621472129979154432",
            "id" : "1621472129979154432"
          },
          {
            "name" : "Milos Perisic",
            "screen_name" : "themilosperisic",
            "indices" : [
              "10",
              "26"
            ],
            "id_str" : "1645686088491495424",
            "id" : "1645686088491495424"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689607806603931648",
      "id_str" : "1689619500163792896",
      "in_reply_to_user_id" : "1621472129979154432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689619500163792896",
      "in_reply_to_status_id" : "1689607806603931648",
      "created_at" : "Thu Aug 10 12:47:35 +0000 2023",
      "favorited" : false,
      "full_text" : "@iamhuyha @themilosperisic WOW me too!",
      "lang" : "en",
      "in_reply_to_screen_name" : "iamhuyha",
      "in_reply_to_user_id_str" : "1621472129979154432"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689399013659791360"
          ],
          "editableUntil" : "2023-08-09T23:11:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Whale",
            "screen_name" : "WhaleChart",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "3359503481",
            "id" : "3359503481"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689233675966124033",
      "id_str" : "1689399013659791360",
      "in_reply_to_user_id" : "3359503481",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689399013659791360",
      "in_reply_to_status_id" : "1689233675966124033",
      "created_at" : "Wed Aug 09 22:11:27 +0000 2023",
      "favorited" : false,
      "full_text" : "@WhaleChart aliums",
      "lang" : "lt",
      "in_reply_to_screen_name" : "WhaleChart",
      "in_reply_to_user_id_str" : "3359503481"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689348953123241985"
          ],
          "editableUntil" : "2023-08-09T19:52:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Charlie Bullen",
            "screen_name" : "ImCharlieBullen",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1615008233353093122",
            "id" : "1615008233353093122"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689255301382348801",
      "id_str" : "1689348953123241985",
      "in_reply_to_user_id" : "1615008233353093122",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689348953123241985",
      "in_reply_to_status_id" : "1689255301382348801",
      "created_at" : "Wed Aug 09 18:52:31 +0000 2023",
      "favorited" : false,
      "full_text" : "@ImCharlieBullen When they can answer every question without even getting out of bed.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ImCharlieBullen",
      "in_reply_to_user_id_str" : "1615008233353093122"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689348699569168384"
          ],
          "editableUntil" : "2023-08-09T19:51:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689230138163003392",
      "id_str" : "1689348699569168384",
      "in_reply_to_user_id" : "1601800309960888320",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689348699569168384",
      "in_reply_to_status_id" : "1689230138163003392",
      "created_at" : "Wed Aug 09 18:51:31 +0000 2023",
      "favorited" : false,
      "full_text" : "@NicholasBTY Faithlessness.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ItsNickJonesy",
      "in_reply_to_user_id_str" : "1601800309960888320"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689316514082566144"
          ],
          "editableUntil" : "2023-08-09T17:43:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Cryptic Poet",
            "screen_name" : "1CrypticPoet",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1033739483609481216",
            "id" : "1033739483609481216"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688981696849260544",
      "id_str" : "1689316514082566144",
      "in_reply_to_user_id" : "1033739483609481216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689316514082566144",
      "in_reply_to_status_id" : "1688981696849260544",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 09 16:43:37 +0000 2023",
      "favorited" : false,
      "full_text" : "@1CrypticPoet https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "1CrypticPoet",
      "in_reply_to_user_id_str" : "1033739483609481216"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689234432861827073"
          ],
          "editableUntil" : "2023-08-09T12:17:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "1689234432861827073",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689234432861827073",
      "created_at" : "Wed Aug 09 11:17:27 +0000 2023",
      "favorited" : false,
      "full_text" : "I know, it is overwhelming.\n\nImagine being ME!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689230511003029506"
          ],
          "editableUntil" : "2023-08-09T12:01:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CoinMarketCap",
            "screen_name" : "CoinMarketCap",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "2260491445",
            "id" : "2260491445"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1689109245126451200",
      "id_str" : "1689230511003029506",
      "in_reply_to_user_id" : "2260491445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689230511003029506",
      "in_reply_to_status_id" : "1689109245126451200",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 09 11:01:52 +0000 2023",
      "favorited" : false,
      "full_text" : "@CoinMarketCap https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "CoinMarketCap",
      "in_reply_to_user_id_str" : "2260491445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689176123517603840"
          ],
          "editableUntil" : "2023-08-09T08:25:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Lewis",
            "screen_name" : "TheLewisW",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1650130719174270979",
            "id" : "1650130719174270979"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688927813527838721",
      "id_str" : "1689176123517603840",
      "in_reply_to_user_id" : "1650130719174270979",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689176123517603840",
      "in_reply_to_status_id" : "1688927813527838721",
      "created_at" : "Wed Aug 09 07:25:45 +0000 2023",
      "favorited" : false,
      "full_text" : "@TheLewisW Transmute.",
      "lang" : "de",
      "in_reply_to_screen_name" : "TheLewisW",
      "in_reply_to_user_id_str" : "1650130719174270979"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1689006895984771072"
          ],
          "editableUntil" : "2023-08-08T21:13:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1689003548485574656",
      "id_str" : "1689006895984771072",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1689006895984771072",
      "in_reply_to_status_id" : "1689003548485574656",
      "created_at" : "Tue Aug 08 20:13:18 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj BTC",
      "lang" : "und",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688967296226627596"
          ],
          "editableUntil" : "2023-08-08T18:35:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/9hn942jY65",
            "expanded_url" : "https://dailyhodl.com/2023/02/13/investor-who-called-crypto-bottom-predicts-next-bull-market-narratives-says-eth-ready-for-rallies/",
            "display_url" : "dailyhodl.com/2023/02/13/inv…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1688967296226627596",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688967296226627596",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 08 17:35:57 +0000 2023",
      "favorited" : false,
      "full_text" : "https://t.co/9hn942jY65",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688961512759562240"
          ],
          "editableUntil" : "2023-08-08T18:12:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SharksCoins 🦈 Gem Hunter",
            "screen_name" : "SharksCoins",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1568227771",
            "id" : "1568227771"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688876155456069633",
      "id_str" : "1688961512759562240",
      "in_reply_to_user_id" : "1568227771",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688961512759562240",
      "in_reply_to_status_id" : "1688876155456069633",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 08 17:12:58 +0000 2023",
      "favorited" : false,
      "full_text" : "@SharksCoins https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "SharksCoins",
      "in_reply_to_user_id_str" : "1568227771"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688854547358248960"
          ],
          "editableUntil" : "2023-08-08T11:07:56.147Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "crypto bullet 📈",
            "screen_name" : "SilverBulletBTC",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "1394583744",
            "id" : "1394583744"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SilverBulletBTC/status/1599769978143924225/photo/1",
            "source_status_id" : "1599769978143924225",
            "indices" : [
              "34",
              "57"
            ],
            "url" : "https://t.co/L1XR2SssmX",
            "media_url" : "http://pbs.twimg.com/media/FjOGTGeXEAAqKzh.jpg",
            "id_str" : "1599769955360247808",
            "source_user_id" : "1394583744",
            "id" : "1599769955360247808",
            "media_url_https" : "https://pbs.twimg.com/media/FjOGTGeXEAAqKzh.jpg",
            "source_user_id_str" : "1394583744",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "643",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1162",
                "h" : "1098",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1162",
                "h" : "1098",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1599769978143924225",
            "display_url" : "pic.twitter.com/L1XR2SssmX"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "0",
      "id_str" : "1688854547358248960",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688854547358248960",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 08 10:07:56 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @SilverBulletBTC: We made it 😂 https://t.co/L1XR2SssmX",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/SilverBulletBTC/status/1599769978143924225/photo/1",
            "source_status_id" : "1599769978143924225",
            "indices" : [
              "34",
              "57"
            ],
            "url" : "https://t.co/L1XR2SssmX",
            "media_url" : "http://pbs.twimg.com/media/FjOGTGeXEAAqKzh.jpg",
            "id_str" : "1599769955360247808",
            "source_user_id" : "1394583744",
            "id" : "1599769955360247808",
            "media_url_https" : "https://pbs.twimg.com/media/FjOGTGeXEAAqKzh.jpg",
            "source_user_id_str" : "1394583744",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "643",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1162",
                "h" : "1098",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1162",
                "h" : "1098",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1599769978143924225",
            "display_url" : "pic.twitter.com/L1XR2SssmX"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688845786052739073"
          ],
          "editableUntil" : "2023-08-08T10:33:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mirha Afridi",
            "screen_name" : "MirhaAfridi",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "762865952161542144",
            "id" : "762865952161542144"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688750988365078528",
      "id_str" : "1688845786052739073",
      "in_reply_to_user_id" : "762865952161542144",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688845786052739073",
      "in_reply_to_status_id" : "1688750988365078528",
      "created_at" : "Tue Aug 08 09:33:07 +0000 2023",
      "favorited" : false,
      "full_text" : "@MirhaAfridi 2,5 is better",
      "lang" : "en",
      "in_reply_to_screen_name" : "MirhaAfridi",
      "in_reply_to_user_id_str" : "762865952161542144"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688845621292060672"
          ],
          "editableUntil" : "2023-08-08T10:32:28.007Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jack Chardwood",
            "screen_name" : "JackChardwood",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1568722551580278786",
            "id" : "1568722551580278786"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1688845621292060672",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688845621292060672",
      "created_at" : "Tue Aug 08 09:32:28 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JackChardwood: Frens.\n\nThe forgivenet is now up and running again.\n\nFor all yous trying to say sorry and failing, try again, and earn y…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688845239841120257"
          ],
          "editableUntil" : "2023-08-08T10:30:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SharksCoins 🦈 Gem Hunter",
            "screen_name" : "SharksCoins",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1568227771",
            "id" : "1568227771"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1688840799117606913",
      "id_str" : "1688845239841120257",
      "in_reply_to_user_id" : "1568227771",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688845239841120257",
      "in_reply_to_status_id" : "1688840799117606913",
      "possibly_sensitive" : false,
      "created_at" : "Tue Aug 08 09:30:57 +0000 2023",
      "favorited" : false,
      "full_text" : "@SharksCoins https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "SharksCoins",
      "in_reply_to_user_id_str" : "1568227771"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688668253814419457"
          ],
          "editableUntil" : "2023-08-07T22:47:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Josh Lawrence",
            "screen_name" : "WndrJosh",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1633170625991790593",
            "id" : "1633170625991790593"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688566258667524097",
      "id_str" : "1688668253814419457",
      "in_reply_to_user_id" : "1633170625991790593",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688668253814419457",
      "in_reply_to_status_id" : "1688566258667524097",
      "created_at" : "Mon Aug 07 21:47:40 +0000 2023",
      "favorited" : false,
      "full_text" : "@WndrJosh Saying sorry.",
      "lang" : "en",
      "in_reply_to_screen_name" : "WndrJosh",
      "in_reply_to_user_id_str" : "1633170625991790593"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688649826907357184"
          ],
          "editableUntil" : "2023-08-07T21:34:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dividend Hero",
            "screen_name" : "HeroDividend",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1257845875717607424",
            "id" : "1257845875717607424"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688591494758776840",
      "id_str" : "1688649826907357184",
      "in_reply_to_user_id" : "1257845875717607424",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688649826907357184",
      "in_reply_to_status_id" : "1688591494758776840",
      "created_at" : "Mon Aug 07 20:34:26 +0000 2023",
      "favorited" : false,
      "full_text" : "@HeroDividend quite right",
      "lang" : "en",
      "in_reply_to_screen_name" : "HeroDividend",
      "in_reply_to_user_id_str" : "1257845875717607424"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688619518333960192"
          ],
          "editableUntil" : "2023-08-07T19:34:00.861Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Crypto",
            "indices" : [
              "39",
              "46"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CoinMarketCap",
            "screen_name" : "CoinMarketCap",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "2260491445",
            "id" : "2260491445"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "0",
      "id_str" : "1688619518333960192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688619518333960192",
      "created_at" : "Mon Aug 07 18:34:00 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @CoinMarketCap: The most unexpected #Crypto Token, in your opinion? 😉",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688619485375164416"
          ],
          "editableUntil" : "2023-08-07T19:33:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CoinMarketCap",
            "screen_name" : "CoinMarketCap",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "2260491445",
            "id" : "2260491445"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688588311135240200",
      "id_str" : "1688619485375164416",
      "in_reply_to_user_id" : "2260491445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688619485375164416",
      "in_reply_to_status_id" : "1688588311135240200",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 07 18:33:53 +0000 2023",
      "favorited" : false,
      "full_text" : "@CoinMarketCap https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "CoinMarketCap",
      "in_reply_to_user_id_str" : "2260491445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688618714613121025"
          ],
          "editableUntil" : "2023-08-07T19:30:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Vic 🌮",
            "screen_name" : "VicVijayakumar",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "15433238",
            "id" : "15433238"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688303894105841664",
      "id_str" : "1688618714613121025",
      "in_reply_to_user_id" : "15433238",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688618714613121025",
      "in_reply_to_status_id" : "1688303894105841664",
      "created_at" : "Mon Aug 07 18:30:49 +0000 2023",
      "favorited" : false,
      "full_text" : "@VicVijayakumar I blame the bats.",
      "lang" : "en",
      "in_reply_to_screen_name" : "VicVijayakumar",
      "in_reply_to_user_id_str" : "15433238"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688589635276951553"
          ],
          "editableUntil" : "2023-08-07T17:35:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SharksCoins 🦈 Gem Hunter",
            "screen_name" : "SharksCoins",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1568227771",
            "id" : "1568227771"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688544962097426432",
      "id_str" : "1688589635276951553",
      "in_reply_to_user_id" : "1568227771",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688589635276951553",
      "in_reply_to_status_id" : "1688544962097426432",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 07 16:35:16 +0000 2023",
      "favorited" : false,
      "full_text" : "@SharksCoins https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "SharksCoins",
      "in_reply_to_user_id_str" : "1568227771"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688588616589545472"
          ],
          "editableUntil" : "2023-08-07T17:31:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Lewis",
            "screen_name" : "TheLewisW",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1650130719174270979",
            "id" : "1650130719174270979"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1688246074773839873",
      "id_str" : "1688588616589545472",
      "in_reply_to_user_id" : "1650130719174270979",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688588616589545472",
      "in_reply_to_status_id" : "1688246074773839873",
      "created_at" : "Mon Aug 07 16:31:13 +0000 2023",
      "favorited" : false,
      "full_text" : "@TheLewisW Tap dancing, mostly. Some tango.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TheLewisW",
      "in_reply_to_user_id_str" : "1650130719174270979"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688581383206092801"
          ],
          "editableUntil" : "2023-08-07T17:02:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mirha Afridi",
            "screen_name" : "MirhaAfridi",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "762865952161542144",
            "id" : "762865952161542144"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688237891086962688",
      "id_str" : "1688581383206092801",
      "in_reply_to_user_id" : "762865952161542144",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688581383206092801",
      "in_reply_to_status_id" : "1688237891086962688",
      "created_at" : "Mon Aug 07 16:02:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@MirhaAfridi Love",
      "lang" : "en",
      "in_reply_to_screen_name" : "MirhaAfridi",
      "in_reply_to_user_id_str" : "762865952161542144"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688501858518589441"
          ],
          "editableUntil" : "2023-08-07T11:46:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Josh Rosella",
            "screen_name" : "JoshRosella",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1658864493521190912",
            "id" : "1658864493521190912"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "44",
              "67"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688460013285593088",
      "id_str" : "1688501858518589441",
      "in_reply_to_user_id" : "1658864493521190912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688501858518589441",
      "in_reply_to_status_id" : "1688460013285593088",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 07 10:46:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@JoshRosella Android app for the forgivenet https://t.co/6JUcz6pz0V",
      "lang" : "en",
      "in_reply_to_screen_name" : "JoshRosella",
      "in_reply_to_user_id_str" : "1658864493521190912"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688488837075374080"
          ],
          "editableUntil" : "2023-08-07T10:54:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "82"
      ],
      "favorite_count" : "0",
      "id_str" : "1688488837075374080",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688488837075374080",
      "created_at" : "Mon Aug 07 09:54:44 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk sorry, but ...\n\n... no-one is EVER going to stop calling Twitter TWITTER",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688488701796454401"
          ],
          "editableUntil" : "2023-08-07T10:54:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mehul Sharan",
            "screen_name" : "mehul_sharan",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1613942583117615104",
            "id" : "1613942583117615104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1688205420660416512",
      "id_str" : "1688488701796454401",
      "in_reply_to_user_id" : "1613942583117615104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688488701796454401",
      "in_reply_to_status_id" : "1688205420660416512",
      "created_at" : "Mon Aug 07 09:54:11 +0000 2023",
      "favorited" : false,
      "full_text" : "@mehul_sharan no",
      "lang" : "und",
      "in_reply_to_screen_name" : "mehul_sharan",
      "in_reply_to_user_id_str" : "1613942583117615104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688474869732651008"
          ],
          "editableUntil" : "2023-08-07T09:59:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Iu5ef5haKj",
            "expanded_url" : "https://1frgvn.com/",
            "display_url" : "1frgvn.com",
            "indices" : [
              "134",
              "157"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "254"
      ],
      "favorite_count" : "1",
      "id_str" : "1688474869732651008",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1688474869732651008",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 07 08:59:13 +0000 2023",
      "favorited" : false,
      "full_text" : "Frens.\n\nThe forgivenet is now up and running again.\n\nFor all yous trying to say sorry and failing, try again, and earn your 1 FRGVN.\n\nhttps://t.co/Iu5ef5haKj\n\nMy dev told me he'd had some issues but he's OK now. You just can't get the staff these days 🤣🤣",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688462815558819840"
          ],
          "editableUntil" : "2023-08-07T09:11:20.008Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1688462815558819840",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688462815558819840",
      "created_at" : "Mon Aug 07 08:11:20 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @elonmusk: If you were unfairly treated by your employer due to posting or liking something on this platform, we will fund your legal bi…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1688282779421720577"
          ],
          "editableUntil" : "2023-08-06T21:15:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Andrew Lokenauth",
            "screen_name" : "FluentInFinance",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1370163747973632003",
            "id" : "1370163747973632003"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687940038339031040",
      "id_str" : "1688282779421720577",
      "in_reply_to_user_id" : "1370163747973632003",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1688282779421720577",
      "in_reply_to_status_id" : "1687940038339031040",
      "created_at" : "Sun Aug 06 20:15:56 +0000 2023",
      "favorited" : false,
      "full_text" : "@FluentInFinance I plan to.",
      "lang" : "en",
      "in_reply_to_screen_name" : "FluentInFinance",
      "in_reply_to_user_id_str" : "1370163747973632003"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687968723431280640"
          ],
          "editableUntil" : "2023-08-06T00:27:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "id_str" : "1687968723431280640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687968723431280640",
      "created_at" : "Sat Aug 05 23:27:59 +0000 2023",
      "favorited" : false,
      "full_text" : "Sab kuch milega.\n\nLiterally.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687968407197474816"
          ],
          "editableUntil" : "2023-08-06T00:26:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jonathan 👾",
            "screen_name" : "jonathanfeliz_",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1591616504000282625",
            "id" : "1591616504000282625"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687923778561392642",
      "id_str" : "1687968407197474816",
      "in_reply_to_user_id" : "1591616504000282625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687968407197474816",
      "in_reply_to_status_id" : "1687923778561392642",
      "created_at" : "Sat Aug 05 23:26:43 +0000 2023",
      "favorited" : false,
      "full_text" : "@jonathanfeliz_ They already know they are wrong.",
      "lang" : "en",
      "in_reply_to_screen_name" : "jonathanfeliz_",
      "in_reply_to_user_id_str" : "1591616504000282625"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687967374580834304"
          ],
          "editableUntil" : "2023-08-06T00:22:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/0JUy1YpVEw",
            "expanded_url" : "https://www.youtube.com/watch?v=HWsX39KVlas",
            "display_url" : "youtube.com/watch?v=HWsX39…",
            "indices" : [
              "10",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "1",
      "id_str" : "1687967374580834304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687967374580834304",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 05 23:22:37 +0000 2023",
      "favorited" : false,
      "full_text" : "GN frens\n\nhttps://t.co/0JUy1YpVEw",
      "lang" : "de"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687964606671593473"
          ],
          "editableUntil" : "2023-08-06T00:11:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Francesco",
            "screen_name" : "FrancescoCiull4",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1704118916",
            "id" : "1704118916"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687687101670731777",
      "id_str" : "1687964606671593473",
      "in_reply_to_user_id" : "1704118916",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687964606671593473",
      "in_reply_to_status_id" : "1687687101670731777",
      "created_at" : "Sat Aug 05 23:11:37 +0000 2023",
      "favorited" : false,
      "full_text" : "@FrancescoCiull4 that shit happens dude",
      "lang" : "en",
      "in_reply_to_screen_name" : "FrancescoCiull4",
      "in_reply_to_user_id_str" : "1704118916"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687912090898415616"
          ],
          "editableUntil" : "2023-08-05T20:42:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687707927556325376",
      "id_str" : "1687912090898415616",
      "in_reply_to_user_id" : "1372781203774791686",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687912090898415616",
      "in_reply_to_status_id" : "1687707927556325376",
      "created_at" : "Sat Aug 05 19:42:57 +0000 2023",
      "favorited" : false,
      "full_text" : "@parh_lo_riday Story of my life.",
      "lang" : "en",
      "in_reply_to_screen_name" : "oyee_riday",
      "in_reply_to_user_id_str" : "1372781203774791686"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687868979245948928"
          ],
          "editableUntil" : "2023-08-05T17:51:38.398Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matt Wallace",
            "screen_name" : "MattWallace888",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "805532293951606785",
            "id" : "805532293951606785"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/MattWallace888/status/1687630539275034626/photo/1",
            "source_status_id" : "1687630539275034626",
            "indices" : [
              "96",
              "119"
            ],
            "url" : "https://t.co/8JAsmlayBx",
            "media_url" : "http://pbs.twimg.com/media/F2urCBpWkAAiCyt.jpg",
            "id_str" : "1687630536670351360",
            "source_user_id" : "805532293951606785",
            "id" : "1687630536670351360",
            "media_url_https" : "https://pbs.twimg.com/media/F2urCBpWkAAiCyt.jpg",
            "source_user_id_str" : "805532293951606785",
            "sizes" : {
              "large" : {
                "w" : "768",
                "h" : "432",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "768",
                "h" : "432",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1687630539275034626",
            "display_url" : "pic.twitter.com/8JAsmlayBx"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "119"
      ],
      "favorite_count" : "0",
      "id_str" : "1687868979245948928",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687868979245948928",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 05 16:51:38 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @MattWallace888: Should transgender athletes be banned from competing in all women’s sports? https://t.co/8JAsmlayBx",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/MattWallace888/status/1687630539275034626/photo/1",
            "source_status_id" : "1687630539275034626",
            "indices" : [
              "96",
              "119"
            ],
            "url" : "https://t.co/8JAsmlayBx",
            "media_url" : "http://pbs.twimg.com/media/F2urCBpWkAAiCyt.jpg",
            "id_str" : "1687630536670351360",
            "source_user_id" : "805532293951606785",
            "id" : "1687630536670351360",
            "media_url_https" : "https://pbs.twimg.com/media/F2urCBpWkAAiCyt.jpg",
            "source_user_id_str" : "805532293951606785",
            "sizes" : {
              "large" : {
                "w" : "768",
                "h" : "432",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "768",
                "h" : "432",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1687630539275034626",
            "display_url" : "pic.twitter.com/8JAsmlayBx"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687868955254480896"
          ],
          "editableUntil" : "2023-08-05T17:51:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matt Wallace",
            "screen_name" : "MattWallace888",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "805532293951606785",
            "id" : "805532293951606785"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687630539275034626",
      "id_str" : "1687868955254480896",
      "in_reply_to_user_id" : "805532293951606785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687868955254480896",
      "in_reply_to_status_id" : "1687630539275034626",
      "created_at" : "Sat Aug 05 16:51:32 +0000 2023",
      "favorited" : false,
      "full_text" : "@MattWallace888 obvs",
      "lang" : "en",
      "in_reply_to_screen_name" : "MattWallace888",
      "in_reply_to_user_id_str" : "805532293951606785"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687850580717314048"
          ],
          "editableUntil" : "2023-08-05T16:38:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687765392524222464",
      "id_str" : "1687850580717314048",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687850580717314048",
      "in_reply_to_status_id" : "1687765392524222464",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 05 15:38:31 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687747845623812096"
          ],
          "editableUntil" : "2023-08-05T09:50:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Morten Reenberg",
            "screen_name" : "MortenReenberg",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1476518302620991492",
            "id" : "1476518302620991492"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1687726793149575168",
      "id_str" : "1687747845623812096",
      "in_reply_to_user_id" : "1476518302620991492",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687747845623812096",
      "in_reply_to_status_id" : "1687726793149575168",
      "created_at" : "Sat Aug 05 08:50:17 +0000 2023",
      "favorited" : false,
      "full_text" : "@MortenReenberg by lobotomy? or something else.. ?",
      "lang" : "en",
      "in_reply_to_screen_name" : "MortenReenberg",
      "in_reply_to_user_id_str" : "1476518302620991492"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687742166808879105"
          ],
          "editableUntil" : "2023-08-05T09:27:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Your Crypto DJ",
            "screen_name" : "yourcryptodj",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1265223205230383104",
            "id" : "1265223205230383104"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "14",
              "37"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687704993606823936",
      "id_str" : "1687742166808879105",
      "in_reply_to_user_id" : "1265223205230383104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687742166808879105",
      "in_reply_to_status_id" : "1687704993606823936",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 05 08:27:43 +0000 2023",
      "favorited" : false,
      "full_text" : "@yourcryptodj https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "yourcryptodj",
      "in_reply_to_user_id_str" : "1265223205230383104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687735729365889024"
          ],
          "editableUntil" : "2023-08-05T09:02:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Fabio | Money ain't wealth",
            "screen_name" : "fmarciano",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "20338422",
            "id" : "20338422"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1687537143604772882",
      "id_str" : "1687735729365889024",
      "in_reply_to_user_id" : "20338422",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687735729365889024",
      "in_reply_to_status_id" : "1687537143604772882",
      "created_at" : "Sat Aug 05 08:02:09 +0000 2023",
      "favorited" : false,
      "full_text" : "@fmarciano To stop farting.",
      "lang" : "en",
      "in_reply_to_screen_name" : "fmarciano",
      "in_reply_to_user_id_str" : "20338422"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687591344649142273"
          ],
          "editableUntil" : "2023-08-04T23:28:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "iii",
            "indices" : [
              "55",
              "59"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "id_str" : "1687591344649142273",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687591344649142273",
      "created_at" : "Fri Aug 04 22:28:25 +0000 2023",
      "favorited" : false,
      "full_text" : "I'm here to save crypto from inbuilt-insipid-inertia.\n\n#iii",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687587253038583808"
          ],
          "editableUntil" : "2023-08-04T23:12:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Hailey 👩🏼‍💻💻",
            "screen_name" : "haileyjocodes",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "3599003912",
            "id" : "3599003912"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687246355511869447",
      "id_str" : "1687587253038583808",
      "in_reply_to_user_id" : "3599003912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687587253038583808",
      "in_reply_to_status_id" : "1687246355511869447",
      "created_at" : "Fri Aug 04 22:12:09 +0000 2023",
      "favorited" : false,
      "full_text" : "@haileyjocodes It's easy-peasy.",
      "lang" : "en",
      "in_reply_to_screen_name" : "haileyjocodes",
      "in_reply_to_user_id_str" : "3599003912"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687582979697119232"
          ],
          "editableUntil" : "2023-08-04T22:55:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "William Nguyen",
            "screen_name" : "NguyenWils",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1372538201173286918",
            "id" : "1372538201173286918"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687581714833403904",
      "id_str" : "1687582979697119232",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687582979697119232",
      "in_reply_to_status_id" : "1687581714833403904",
      "created_at" : "Fri Aug 04 21:55:10 +0000 2023",
      "favorited" : false,
      "full_text" : "@NguyenWils where's that follow Nguyen??? :D",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687581714833403904"
          ],
          "editableUntil" : "2023-08-04T22:50:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "William Nguyen",
            "screen_name" : "NguyenWils",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1372538201173286918",
            "id" : "1372538201173286918"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1687515239120879616",
      "id_str" : "1687581714833403904",
      "in_reply_to_user_id" : "1372538201173286918",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687581714833403904",
      "in_reply_to_status_id" : "1687515239120879616",
      "created_at" : "Fri Aug 04 21:50:09 +0000 2023",
      "favorited" : false,
      "full_text" : "@NguyenWils Yeah, sometimes I tweet about soya lattes.",
      "lang" : "en",
      "in_reply_to_screen_name" : "NguyenWils",
      "in_reply_to_user_id_str" : "1372538201173286918"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687540525061046273"
          ],
          "editableUntil" : "2023-08-04T20:06:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Starbucks Coffee",
            "screen_name" : "Starbucks",
            "indices" : [
              "10",
              "20"
            ],
            "id_str" : "30973",
            "id" : "30973"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "176"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687531487141453824",
      "id_str" : "1687540525061046273",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687540525061046273",
      "in_reply_to_status_id" : "1687531487141453824",
      "created_at" : "Fri Aug 04 19:06:28 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk @Starbucks Ack-chool-ois ...\n\n... it has to be said that Starbucks is way better outside the US where pretty much everything is dosed with a ton of unnecessary sugar.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687539488619167750"
          ],
          "editableUntil" : "2023-08-04T20:02:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "greg",
            "screen_name" : "greg16676935420",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1356434353623093249",
            "id" : "1356434353623093249"
          },
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "17",
              "26"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Starbucks Coffee",
            "screen_name" : "Starbucks",
            "indices" : [
              "27",
              "37"
            ],
            "id_str" : "30973",
            "id" : "30973"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1687532963867590670",
      "id_str" : "1687539488619167750",
      "in_reply_to_user_id" : "1356434353623093249",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687539488619167750",
      "in_reply_to_status_id" : "1687532963867590670",
      "created_at" : "Fri Aug 04 19:02:21 +0000 2023",
      "favorited" : false,
      "full_text" : "@greg16676935420 @elonmusk @Starbucks God, I had that TOO!!!",
      "lang" : "en",
      "in_reply_to_screen_name" : "greg16676935420",
      "in_reply_to_user_id_str" : "1356434353623093249"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687539401578971166"
          ],
          "editableUntil" : "2023-08-04T20:02:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          },
          {
            "name" : "Starbucks Coffee",
            "screen_name" : "Starbucks",
            "indices" : [
              "10",
              "20"
            ],
            "id_str" : "30973",
            "id" : "30973"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687531487141453824",
      "id_str" : "1687539401578971166",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687539401578971166",
      "in_reply_to_status_id" : "1687531487141453824",
      "created_at" : "Fri Aug 04 19:02:00 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk @Starbucks They do superlative soya lattes. Nearly as good as mine, but not quite.",
      "lang" : "en",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687474190734024704"
          ],
          "editableUntil" : "2023-08-04T15:42:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687072785883860992",
      "id_str" : "1687474190734024704",
      "in_reply_to_user_id" : "1568722551580278786",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687474190734024704",
      "in_reply_to_status_id" : "1687072785883860992",
      "created_at" : "Fri Aug 04 14:42:53 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk This is a good question.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JackChardwood",
      "in_reply_to_user_id_str" : "1568722551580278786"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687473566667644928"
          ],
          "editableUntil" : "2023-08-04T15:40:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Stephen King",
            "screen_name" : "StephenKing",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2233154425",
            "id" : "2233154425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687471886026854400",
      "id_str" : "1687473566667644928",
      "in_reply_to_user_id" : "2233154425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687473566667644928",
      "in_reply_to_status_id" : "1687471886026854400",
      "created_at" : "Fri Aug 04 14:40:24 +0000 2023",
      "favorited" : false,
      "full_text" : "@StephenKing Nope, still the pedo-holics.",
      "lang" : "en",
      "in_reply_to_screen_name" : "StephenKing",
      "in_reply_to_user_id_str" : "2233154425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687471129080770560"
          ],
          "editableUntil" : "2023-08-04T15:30:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Bryan Searson",
            "screen_name" : "BryanSearson_",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1625170146774990861",
            "id" : "1625170146774990861"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1687347764689084416",
      "id_str" : "1687471129080770560",
      "in_reply_to_user_id" : "1625170146774990861",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687471129080770560",
      "in_reply_to_status_id" : "1687347764689084416",
      "created_at" : "Fri Aug 04 14:30:43 +0000 2023",
      "favorited" : false,
      "full_text" : "@BryanSearson_ Nice.",
      "lang" : "en",
      "in_reply_to_screen_name" : "BryanSearson_",
      "in_reply_to_user_id_str" : "1625170146774990861"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687448319990140928"
          ],
          "editableUntil" : "2023-08-04T14:00:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Altcoin Daily",
            "screen_name" : "AltcoinDailyio",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "958118843636854784",
            "id" : "958118843636854784"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6JUcz6pz0V",
            "expanded_url" : "http://1frgvn.com",
            "display_url" : "1frgvn.com",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687447039960121344",
      "id_str" : "1687448319990140928",
      "in_reply_to_user_id" : "958118843636854784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687448319990140928",
      "in_reply_to_status_id" : "1687447039960121344",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 04 13:00:05 +0000 2023",
      "favorited" : false,
      "full_text" : "@AltcoinDailyio https://t.co/6JUcz6pz0V",
      "lang" : "qme",
      "in_reply_to_screen_name" : "AltcoinDailyio",
      "in_reply_to_user_id_str" : "958118843636854784"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687383917924327424"
          ],
          "editableUntil" : "2023-08-04T09:44:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1687383917924327424/photo/1",
            "indices" : [
              "63",
              "86"
            ],
            "url" : "https://t.co/WdIPWlz2QX",
            "media_url" : "http://pbs.twimg.com/media/F2rKrhVWcAEXwRV.png",
            "id_str" : "1687383859434778625",
            "id" : "1687383859434778625",
            "media_url_https" : "https://pbs.twimg.com/media/F2rKrhVWcAEXwRV.png",
            "sizes" : {
              "medium" : {
                "w" : "441",
                "h" : "439",
                "resize" : "fit"
              },
              "small" : {
                "w" : "441",
                "h" : "439",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "441",
                "h" : "439",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/WdIPWlz2QX"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "0",
      "id_str" : "1687383917924327424",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687383917924327424",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 04 08:44:10 +0000 2023",
      "favorited" : false,
      "full_text" : "Bots be like ... \n\n👇 please believe me                  👇 oops https://t.co/WdIPWlz2QX",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/JackChardwood/status/1687383917924327424/photo/1",
            "indices" : [
              "63",
              "86"
            ],
            "url" : "https://t.co/WdIPWlz2QX",
            "media_url" : "http://pbs.twimg.com/media/F2rKrhVWcAEXwRV.png",
            "id_str" : "1687383859434778625",
            "id" : "1687383859434778625",
            "media_url_https" : "https://pbs.twimg.com/media/F2rKrhVWcAEXwRV.png",
            "sizes" : {
              "medium" : {
                "w" : "441",
                "h" : "439",
                "resize" : "fit"
              },
              "small" : {
                "w" : "441",
                "h" : "439",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "441",
                "h" : "439",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/WdIPWlz2QX"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687380236348903424"
          ],
          "editableUntil" : "2023-08-04T09:29:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Cryptic Poet",
            "screen_name" : "1CrypticPoet",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1033739483609481216",
            "id" : "1033739483609481216"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1380898299184566289",
      "id_str" : "1687380236348903424",
      "in_reply_to_user_id" : "1033739483609481216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687380236348903424",
      "in_reply_to_status_id" : "1380898299184566289",
      "created_at" : "Fri Aug 04 08:29:33 +0000 2023",
      "favorited" : false,
      "full_text" : "@1CrypticPoet I taught myself Solidity.",
      "lang" : "en",
      "in_reply_to_screen_name" : "1CrypticPoet",
      "in_reply_to_user_id_str" : "1033739483609481216"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687379488932302849"
          ],
          "editableUntil" : "2023-08-04T09:26:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687372232232947713",
      "id_str" : "1687379488932302849",
      "in_reply_to_user_id" : "44196397",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687379488932302849",
      "in_reply_to_status_id" : "1687372232232947713",
      "created_at" : "Fri Aug 04 08:26:34 +0000 2023",
      "favorited" : false,
      "full_text" : "@elonmusk Har-har-dee-har-har.",
      "lang" : "sv",
      "in_reply_to_screen_name" : "elonmusk",
      "in_reply_to_user_id_str" : "44196397"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687272532569694209"
          ],
          "editableUntil" : "2023-08-04T02:21:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Lan Vu",
            "screen_name" : "GrowToGhost",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1642112049600950274",
            "id" : "1642112049600950274"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687132055627280385",
      "id_str" : "1687272532569694209",
      "in_reply_to_user_id" : "1642112049600950274",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687272532569694209",
      "in_reply_to_status_id" : "1687132055627280385",
      "created_at" : "Fri Aug 04 01:21:34 +0000 2023",
      "favorited" : false,
      "full_text" : "@GrowToGhost A ball head?",
      "lang" : "en",
      "in_reply_to_screen_name" : "GrowToGhost",
      "in_reply_to_user_id_str" : "1642112049600950274"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1687272016552853505"
          ],
          "editableUntil" : "2023-08-04T02:19:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Altcoin Daily",
            "screen_name" : "AltcoinDailyio",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "958118843636854784",
            "id" : "958118843636854784"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1687123155821707264",
      "id_str" : "1687272016552853505",
      "in_reply_to_user_id" : "958118843636854784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1687272016552853505",
      "in_reply_to_status_id" : "1687123155821707264",
      "created_at" : "Fri Aug 04 01:19:31 +0000 2023",
      "favorited" : false,
      "full_text" : "@AltcoinDailyio Yes, even more so if we're having dosa.",
      "lang" : "en",
      "in_reply_to_screen_name" : "AltcoinDailyio",
      "in_reply_to_user_id_str" : "958118843636854784"
    }
  }
]