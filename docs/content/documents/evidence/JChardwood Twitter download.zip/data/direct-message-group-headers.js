window.YTD.direct_message_group_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1698243967467327619",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1698244137630285941",
            "senderId" : "1595273832914644993",
            "createdAt" : "2023-09-03T07:58:48.947Z"
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "1595273832914644993",
            "participantsSnapshot" : [
              "1595273832914644993",
              "1568722551580278786",
              "1050635996491001857",
              "1001484063344136193"
            ],
            "createdAt" : "2023-09-03T07:58:19.684Z"
          }
        }
      ]
    }
  }
]