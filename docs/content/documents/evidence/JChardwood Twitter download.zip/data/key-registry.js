window.YTD.key_registry.part0 = [
  {
    "registeredDevices" : {
      "deviceMetadataList" : [
        {
          "userAgent" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36",
          "registrationToken" : "8086f5ea267ff5e95ca1798991a169c4",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEtUXvd4eL9dL3r8ehm6r0kT1So/LmfADb60GZeRtA6K0brl7Da6G4GGdSiq0367jwOJ3BGDFW8BtX9JsUXyxjVQ==",
          "createdAt" : "2023-05-12T07:27:27.113Z",
          "deviceId" : "33c5739a-e198-44e6-a846-2aa692c12a4c"
        },
        {
          "userAgent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
          "registrationToken" : "1cd59daa620523b5ecc2a54f2081b552",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEbUllHvsb4KYW3Oth+cGkMtxfbO4QQsgcHNVkLNdx92Wnl9Ak99jZcb28QePJU+PaZKRndqJcbDd419eoOAVISQ==",
          "createdAt" : "2023-05-10T13:54:57.009Z",
          "deviceId" : "59507f1b-4dc8-4e6f-ac75-a11da15616c2"
        },
        {
          "userAgent" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
          "registrationToken" : "4f50a0d360577a307be2ab42da2ae5ca",
          "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAElkc3704sAqsv67O/XloOfjaBf6HsXMbPLgx+x09NZ875IAfVKnYB2gODu8YOB4+vUevtvQ6XGDH+bSZjJOiIkQ==",
          "createdAt" : "2023-09-01T08:13:02.408Z",
          "deviceId" : "b51f6838-30fe-46d0-830e-3edb4ca6f049"
        }
      ]
    }
  }
]