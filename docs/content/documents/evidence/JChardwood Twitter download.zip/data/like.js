window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1698177649875558591",
      "fullText" : "@1FRGVN Please DM me, I understand you can’t trust anyone right now, so I won’t try to convince you.",
      "expandedUrl" : "https://twitter.com/i/web/status/1698177649875558591"
    }
  },
  {
    "like" : {
      "tweetId" : "1698168861088997437",
      "fullText" : "@1FRGVN @TuckerCarlson",
      "expandedUrl" : "https://twitter.com/i/web/status/1698168861088997437"
    }
  },
  {
    "like" : {
      "tweetId" : "1698168162875797772",
      "fullText" : "@1FRGVN @Support @elonmusk @JackChardwood Get verified! It increases engagement 10 fold for a very short time. I had one comment reach 140k views so far.",
      "expandedUrl" : "https://twitter.com/i/web/status/1698168162875797772"
    }
  },
  {
    "like" : {
      "tweetId" : "1698194741505249548",
      "fullText" : "@1FRGVN @Support @elonmusk @JackChardwood I wish he'd do something about all the account theft bots...🙄",
      "expandedUrl" : "https://twitter.com/i/web/status/1698194741505249548"
    }
  },
  {
    "like" : {
      "tweetId" : "1697888860246614469",
      "fullText" : "Why do only the youngsters have to have gender-affirming surgery while the old, white, fat, middle-aged, middle-class men don't?",
      "expandedUrl" : "https://twitter.com/i/web/status/1697888860246614469"
    }
  },
  {
    "like" : {
      "tweetId" : "1698128441587986695",
      "fullText" : "@Support no one is seeing my tweets @elonmusk and I have been gang stalked and hacked on here (and at @jackchardwood) for months",
      "expandedUrl" : "https://twitter.com/i/web/status/1698128441587986695"
    }
  },
  {
    "like" : {
      "tweetId" : "1698016819951423781",
      "fullText" : "If I die in suspicious circumstances, I want my epitaph to read:\n\n\"All I wanted was to play the piano.\"\n\n&lt;3",
      "expandedUrl" : "https://twitter.com/i/web/status/1698016819951423781"
    }
  },
  {
    "like" : {
      "tweetId" : "1698121721457365343",
      "fullText" : "I've just gone public.\n\nThe reason is because I believe I am about to be arrested in Spain for something related to my GC beliefs.\n\nI have been gang stalked since last October and this is the culmination of that.\n\nI don't know what the lie about me is, yet.",
      "expandedUrl" : "https://twitter.com/i/web/status/1698121721457365343"
    }
  },
  {
    "like" : {
      "tweetId" : "1698123274469642293",
      "fullText" : "@ukinspain\n@IrlEmbMadrid",
      "expandedUrl" : "https://twitter.com/i/web/status/1698123274469642293"
    }
  },
  {
    "like" : {
      "tweetId" : "1698122498506633256",
      "fullText" : "I've just gone public after years being anonymous on Twitter because it's safer for Women that way.\n\nI have been targeted by #TRA/#MRA s for ages and I am on the list.\n\nI want you to know that whatever they have said I did, is a lie.\n\n#gangstalking #gcbeliefs #FreeSpeech",
      "expandedUrl" : "https://twitter.com/i/web/status/1698122498506633256"
    }
  },
  {
    "like" : {
      "tweetId" : "1698125256349626537",
      "fullText" : "Can anyone see my tweets?",
      "expandedUrl" : "https://twitter.com/i/web/status/1698125256349626537"
    }
  },
  {
    "like" : {
      "tweetId" : "1697735883871682755",
      "fullText" : "Imagine Elon Musk (me) gave you $1,000,000.\n\nWhat’s the first thing you would buy? https://t.co/3vaPNf0vyK",
      "expandedUrl" : "https://twitter.com/i/web/status/1697735883871682755"
    }
  },
  {
    "like" : {
      "tweetId" : "1696955958470054382",
      "fullText" : "Have the best Wednesday everyone 💙",
      "expandedUrl" : "https://twitter.com/i/web/status/1696955958470054382"
    }
  },
  {
    "like" : {
      "tweetId" : "1696912558354235636",
      "fullText" : "The measure of your intelligence is not your ability to acquire knowledge but how you handle uncertainty and navigate through it and behave when you don't know what to do.",
      "expandedUrl" : "https://twitter.com/i/web/status/1696912558354235636"
    }
  },
  {
    "like" : {
      "tweetId" : "1696555386755522918",
      "fullText" : "https://t.co/dUVMt30ZgL",
      "expandedUrl" : "https://twitter.com/i/web/status/1696555386755522918"
    }
  },
  {
    "like" : {
      "tweetId" : "1696849220278317383",
      "fullText" : "https://t.co/aV5lxxQbdn",
      "expandedUrl" : "https://twitter.com/i/web/status/1696849220278317383"
    }
  },
  {
    "like" : {
      "tweetId" : "1696359105219404203",
      "fullText" : "https://t.co/gJvv7zbZM7",
      "expandedUrl" : "https://twitter.com/i/web/status/1696359105219404203"
    }
  },
  {
    "like" : {
      "tweetId" : "1696450029685486007",
      "fullText" : "Aww her reaction https://t.co/ZahYgzgGVA",
      "expandedUrl" : "https://twitter.com/i/web/status/1696450029685486007"
    }
  },
  {
    "like" : {
      "tweetId" : "1696412780033937676",
      "fullText" : "Little kiss https://t.co/NvzpiCMD4G",
      "expandedUrl" : "https://twitter.com/i/web/status/1696412780033937676"
    }
  },
  {
    "like" : {
      "tweetId" : "1696420968036716776",
      "fullText" : "https://t.co/9gKJoBYrxt",
      "expandedUrl" : "https://twitter.com/i/web/status/1696420968036716776"
    }
  },
  {
    "like" : {
      "tweetId" : "1695966364027293857",
      "fullText" : "when someone says you are one in a million it’s actually an insult since you are one in 400,000,000,000,000",
      "expandedUrl" : "https://twitter.com/i/web/status/1695966364027293857"
    }
  },
  {
    "like" : {
      "tweetId" : "1696198277212049686",
      "fullText" : "You will never live if you are looking for the meaning of life. Fall in love with some activity and do it! Nobody ever figures out what life is all about and it doesn't matter.",
      "expandedUrl" : "https://twitter.com/i/web/status/1696198277212049686"
    }
  },
  {
    "like" : {
      "tweetId" : "1696190479245746202",
      "fullText" : "Stop telling people about your big ideas.\n\nGo execute &amp; tell us about what happened.",
      "expandedUrl" : "https://twitter.com/i/web/status/1696190479245746202"
    }
  },
  {
    "like" : {
      "tweetId" : "1696115165815619820",
      "fullText" : "If you read this, well done I'm proud of what you're achieving a grateful for your time. Seriously, take a moment and appreciate how good you are and know that you can take the next step. ❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1696115165815619820"
    }
  },
  {
    "like" : {
      "tweetId" : "1695805133735772254",
      "fullText" : "Cultivating a culture of doubt, questioning, and skepticism among students about what they learn is the greatest form of education.",
      "expandedUrl" : "https://twitter.com/i/web/status/1695805133735772254"
    }
  },
  {
    "like" : {
      "tweetId" : "1696037143582519461",
      "fullText" : "• Intelligence: \nYou question everything you think you know.\n\n• Stupidity: \nYou think you know everything, without questioning.",
      "expandedUrl" : "https://twitter.com/i/web/status/1696037143582519461"
    }
  },
  {
    "like" : {
      "tweetId" : "1695580690140549390",
      "fullText" : "You already passed the technical interview.\n\nWanna do the human next step thing?",
      "expandedUrl" : "https://twitter.com/i/web/status/1695580690140549390"
    }
  },
  {
    "like" : {
      "tweetId" : "1695642828318142499",
      "fullText" : "There are two rules in life:\n\n1) Never give out all the information.",
      "expandedUrl" : "https://twitter.com/i/web/status/1695642828318142499"
    }
  },
  {
    "like" : {
      "tweetId" : "1695358438702760111",
      "fullText" : "Ongoing frontend dev support.\n\nFuture dev ops infrastructure support.\n\nFuture backend engineering efforts (check out the whitepaper for details).\n\nhttps://t.co/6JUcz6pz0V\n\nInterested?",
      "expandedUrl" : "https://twitter.com/i/web/status/1695358438702760111"
    }
  },
  {
    "like" : {
      "tweetId" : "1695472170326249834",
      "fullText" : "https://t.co/PNghhy1bWh",
      "expandedUrl" : "https://twitter.com/i/web/status/1695472170326249834"
    }
  },
  {
    "like" : {
      "tweetId" : "1695182519749017868",
      "fullText" : "Hope today is really nice for you ☀️❣️",
      "expandedUrl" : "https://twitter.com/i/web/status/1695182519749017868"
    }
  },
  {
    "like" : {
      "tweetId" : "1695264561060884615",
      "fullText" : "Let's have a coffee break, tell me what you've been up to today? #buildinpublic",
      "expandedUrl" : "https://twitter.com/i/web/status/1695264561060884615"
    }
  },
  {
    "like" : {
      "tweetId" : "1695173199506407522",
      "fullText" : "Buy 1 Bitcoin before these two buy them all. 🚀\n\n#Blackrock #MicroStrategy #Crypto https://t.co/svdRkQ68PA",
      "expandedUrl" : "https://twitter.com/i/web/status/1695173199506407522"
    }
  },
  {
    "like" : {
      "tweetId" : "1695133533046718787",
      "fullText" : "Really feeling blessed to be in #crypto. So many big things coming. 😊🙏",
      "expandedUrl" : "https://twitter.com/i/web/status/1695133533046718787"
    }
  },
  {
    "like" : {
      "tweetId" : "1695049667778842720",
      "fullText" : "Who hurt him https://t.co/KNM4kIUI5x",
      "expandedUrl" : "https://twitter.com/i/web/status/1695049667778842720"
    }
  },
  {
    "like" : {
      "tweetId" : "1695058210963546238",
      "fullText" : "@Z_Humphries Some groceries",
      "expandedUrl" : "https://twitter.com/i/web/status/1695058210963546238"
    }
  },
  {
    "like" : {
      "tweetId" : "1694704939677680090",
      "fullText" : "The riskiest move is always playing it safe.",
      "expandedUrl" : "https://twitter.com/i/web/status/1694704939677680090"
    }
  },
  {
    "like" : {
      "tweetId" : "1695073373192163446",
      "fullText" : "Insanely Bullish On $SHIB.",
      "expandedUrl" : "https://twitter.com/i/web/status/1695073373192163446"
    }
  },
  {
    "like" : {
      "tweetId" : "1695104253776322727",
      "fullText" : "The #BullRun Is Coming.",
      "expandedUrl" : "https://twitter.com/i/web/status/1695104253776322727"
    }
  },
  {
    "like" : {
      "tweetId" : "1695095875029078346",
      "fullText" : "If you cannot be corrected without being offended, then you’ll never truly grow in life.",
      "expandedUrl" : "https://twitter.com/i/web/status/1695095875029078346"
    }
  },
  {
    "like" : {
      "tweetId" : "1694151457623392459",
      "fullText" : "There is a non-zero chance that Elon Musk integrates $DOGE natively into @X. \n\nIf/when that happens the #Dogecoin price will EXPLODE!\n\n$1 $DOGE is programmed. $5 even possible. https://t.co/19rMHA0Rps",
      "expandedUrl" : "https://twitter.com/i/web/status/1694151457623392459"
    }
  },
  {
    "like" : {
      "tweetId" : "1694383666598932898",
      "fullText" : "https://t.co/ZbaLmQ7CCa",
      "expandedUrl" : "https://twitter.com/i/web/status/1694383666598932898"
    }
  },
  {
    "like" : {
      "tweetId" : "1694370440385646911",
      "fullText" : "pay me attention 😞 https://t.co/6JJzE3HvJb",
      "expandedUrl" : "https://twitter.com/i/web/status/1694370440385646911"
    }
  },
  {
    "like" : {
      "tweetId" : "1694354334740541465",
      "fullText" : "https://t.co/xOB04wetQ0",
      "expandedUrl" : "https://twitter.com/i/web/status/1694354334740541465"
    }
  },
  {
    "like" : {
      "tweetId" : "1694219133213397211",
      "fullText" : "https://t.co/MZPQK6vu3L",
      "expandedUrl" : "https://twitter.com/i/web/status/1694219133213397211"
    }
  },
  {
    "like" : {
      "tweetId" : "1694287537978683875",
      "fullText" : "What altcoins we apeing today",
      "expandedUrl" : "https://twitter.com/i/web/status/1694287537978683875"
    }
  },
  {
    "like" : {
      "tweetId" : "1693972387430097354",
      "fullText" : "Don’t waste your time telling normal people with normal visions your abnormal goals.",
      "expandedUrl" : "https://twitter.com/i/web/status/1693972387430097354"
    }
  },
  {
    "like" : {
      "tweetId" : "1694231203975426069",
      "fullText" : "🫳\n   Gm \n🫴",
      "expandedUrl" : "https://twitter.com/i/web/status/1694231203975426069"
    }
  },
  {
    "like" : {
      "tweetId" : "1694026233011687867",
      "fullText" : "I did 30 calls.\n\nI learnt:\n\n• people are fun.\n• no one knows what they’re doing. \n• Nigerians are the coolest.\n\nWhat have calls taught you?",
      "expandedUrl" : "https://twitter.com/i/web/status/1694026233011687867"
    }
  },
  {
    "like" : {
      "tweetId" : "1693889239212253502",
      "fullText" : "Send ________ To The Billions.",
      "expandedUrl" : "https://twitter.com/i/web/status/1693889239212253502"
    }
  },
  {
    "like" : {
      "tweetId" : "1686486040503066624",
      "fullText" : "something big is about to happen very soon",
      "expandedUrl" : "https://twitter.com/i/web/status/1686486040503066624"
    }
  },
  {
    "like" : {
      "tweetId" : "1686802271709917194",
      "fullText" : "People who wear 4 hours of sleep as a badge of honour.\n\nCringe.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686802271709917194"
    }
  },
  {
    "like" : {
      "tweetId" : "1686791580642906112",
      "fullText" : "If #Bitcoin doesn’t hit $100,000 within 2 years\n\nI will give somebody who\n- Likes 👍 \n- Retweets ♻️ \n- Follows @MartiniGuyYT &amp; @CryptoSavingExp \n\n1 WHOLE #BITCOIN",
      "expandedUrl" : "https://twitter.com/i/web/status/1686791580642906112"
    }
  },
  {
    "like" : {
      "tweetId" : "1686633514685333504",
      "fullText" : "I just quit my 9-5. \n\nIt still hasn't sunk in.\n\nIn January I started tweeting.\n\nIn February I almost threw in the towel. \n\nThis month we did an $80k cohort launch. \n\n6 months of dedication has transformed my life. \n\nI'm in control now. \n\nThank you all - thread coming.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686633514685333504"
    }
  },
  {
    "like" : {
      "tweetId" : "1686507748731572224",
      "fullText" : "Who thinks that humility is important for growing a personal brand?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686507748731572224"
    }
  },
  {
    "like" : {
      "tweetId" : "1686621601457176577",
      "fullText" : "There is 97% chance that you are a Billionaire if you have a terrible handwriting.\n\nPure scientific fact.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686621601457176577"
    }
  },
  {
    "like" : {
      "tweetId" : "1686799020663160832",
      "fullText" : "Which ones do you #hodl?\n \n$BTC \n$BNB \n$ETH \n$XRP \n$CRO\n$KASTA\n$AVAX\n$SHIB\n$DOGE \n$ADA \n$MEE\n$MATIC\n$VPAD\n\n👇👇👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1686799020663160832"
    }
  },
  {
    "like" : {
      "tweetId" : "1686768722122301441",
      "fullText" : "If you do the crime, you must be prepared to do the time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686768722122301441"
    }
  },
  {
    "like" : {
      "tweetId" : "1686733111114039296",
      "fullText" : "@JackChardwood Okay, that's new 😄",
      "expandedUrl" : "https://twitter.com/i/web/status/1686733111114039296"
    }
  },
  {
    "like" : {
      "tweetId" : "1686672637194350592",
      "fullText" : "Slow growth? \n\nBe friendly. \n\nNo connections? \n\nBe friendly.\n\nNo deals or clients?\n\nBe friendly. \n\nIt's social media for a reason.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686672637194350592"
    }
  },
  {
    "like" : {
      "tweetId" : "1686718273977528321",
      "fullText" : "@JackChardwood Facts 👌",
      "expandedUrl" : "https://twitter.com/i/web/status/1686718273977528321"
    }
  },
  {
    "like" : {
      "tweetId" : "1686424549972234249",
      "fullText" : "What do you say if a client tells you:\n\n“I know people who charge less”.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686424549972234249"
    }
  },
  {
    "like" : {
      "tweetId" : "1686630731022262272",
      "fullText" : "What is something you learned as a developer that you can also utilize in your everyday life?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686630731022262272"
    }
  },
  {
    "like" : {
      "tweetId" : "1686617385984229376",
      "fullText" : "You tweet 1-2 times a day\n\nAnd expect people to notice you?\n\nThere are 1000s of new tweets every second!\n\nPut out some volume bro!",
      "expandedUrl" : "https://twitter.com/i/web/status/1686617385984229376"
    }
  },
  {
    "like" : {
      "tweetId" : "1686345289286754304",
      "fullText" : "Let's have a coffee break, tell me what you've been up to today? #buildinpublic",
      "expandedUrl" : "https://twitter.com/i/web/status/1686345289286754304"
    }
  },
  {
    "like" : {
      "tweetId" : "1686378348707299328",
      "fullText" : "The fastest way to grow on twitter is to build relationships.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686378348707299328"
    }
  },
  {
    "like" : {
      "tweetId" : "1686548630323228672",
      "fullText" : "Are you chasing $$$ or the solution to a problem?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686548630323228672"
    }
  },
  {
    "like" : {
      "tweetId" : "1686607516312977409",
      "fullText" : "Hope you're doing alright ❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1686607516312977409"
    }
  },
  {
    "like" : {
      "tweetId" : "1686444655104393216",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1686444655104393216"
    }
  },
  {
    "like" : {
      "tweetId" : "1686351078680383488",
      "fullText" : "Do you have less than 200 followers?\n\nIntroduce yourself and let's connect!🤜🏻🤛🏻",
      "expandedUrl" : "https://twitter.com/i/web/status/1686351078680383488"
    }
  },
  {
    "like" : {
      "tweetId" : "1686436921612914717",
      "fullText" : "Any good #memecoins today or total shit market?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686436921612914717"
    }
  },
  {
    "like" : {
      "tweetId" : "1686132648912306187",
      "fullText" : "Overheard some meth addicts in the marina saying, “At least we’re not addicted to Twitter”",
      "expandedUrl" : "https://twitter.com/i/web/status/1686132648912306187"
    }
  },
  {
    "like" : {
      "tweetId" : "1686320560421093376",
      "fullText" : "For anyone who has lost many things, God will restore them this August.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686320560421093376"
    }
  },
  {
    "like" : {
      "tweetId" : "1686383532040470528",
      "fullText" : "The next BILLIONAIRE‘S token is $_______ 🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1686383532040470528"
    }
  },
  {
    "like" : {
      "tweetId" : "1686341983692849155",
      "fullText" : "Which #Crypto do you want me to tweet about ? 👇🤩",
      "expandedUrl" : "https://twitter.com/i/web/status/1686341983692849155"
    }
  },
  {
    "like" : {
      "tweetId" : "1686369546003718144",
      "fullText" : "Unless there are a few issues where you at least slightly disagree with your political party, then you are not in a political party, you are in a cult",
      "expandedUrl" : "https://twitter.com/i/web/status/1686369546003718144"
    }
  },
  {
    "like" : {
      "tweetId" : "1686336723817476097",
      "fullText" : "Which #Memecoins Will Pump In August?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686336723817476097"
    }
  },
  {
    "like" : {
      "tweetId" : "1686300744042131456",
      "fullText" : "Financial freedom is possible with @ _________________ ?🧐",
      "expandedUrl" : "https://twitter.com/i/web/status/1686300744042131456"
    }
  },
  {
    "like" : {
      "tweetId" : "1667174815118098434",
      "fullText" : "https://t.co/urLC43eS4N\n\nHelping our dear crypto community with the thing I do best ❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1667174815118098434"
    }
  },
  {
    "like" : {
      "tweetId" : "1686074782763139075",
      "fullText" : "2️⃣0️⃣2️⃣4️⃣ will be the year of __________?? 🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1686074782763139075"
    }
  },
  {
    "like" : {
      "tweetId" : "1686255443629477888",
      "fullText" : "Shill me your gems! Only 100x potential pls.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686255443629477888"
    }
  },
  {
    "like" : {
      "tweetId" : "1686091105417490432",
      "fullText" : "Which #altcoin would you confidently invest $1,000 in right now?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686091105417490432"
    }
  },
  {
    "like" : {
      "tweetId" : "1686104447301345285",
      "fullText" : "Name the project you trust 100% 🫡⚖️",
      "expandedUrl" : "https://twitter.com/i/web/status/1686104447301345285"
    }
  },
  {
    "like" : {
      "tweetId" : "1685928163166048256",
      "fullText" : "Which #crypto will be trending in August? 👀🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1685928163166048256"
    }
  },
  {
    "like" : {
      "tweetId" : "1686048217853505536",
      "fullText" : "Which #altcoin is going to make you a millionaire?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686048217853505536"
    }
  },
  {
    "like" : {
      "tweetId" : "1686078639111364608",
      "fullText" : "GMMMMMMM!!! Guys happy Monday! \n\nWhat are we buying today? 🤔👇🏼",
      "expandedUrl" : "https://twitter.com/i/web/status/1686078639111364608"
    }
  },
  {
    "like" : {
      "tweetId" : "1685964053699588096",
      "fullText" : "Which project deserves a #PUMP? 🚀💸\n\n👇👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1685964053699588096"
    }
  },
  {
    "like" : {
      "tweetId" : "1685951488957325313",
      "fullText" : "What #Crypto project do you trust right now?🤝",
      "expandedUrl" : "https://twitter.com/i/web/status/1685951488957325313"
    }
  },
  {
    "like" : {
      "tweetId" : "1686074245942558724",
      "fullText" : "Time to buy _________ ?? 💳💸",
      "expandedUrl" : "https://twitter.com/i/web/status/1686074245942558724"
    }
  },
  {
    "like" : {
      "tweetId" : "1686029159712116736",
      "fullText" : "Is there any low cap #altcoin I should be aware of? 💎👇🏼",
      "expandedUrl" : "https://twitter.com/i/web/status/1686029159712116736"
    }
  },
  {
    "like" : {
      "tweetId" : "1686003461421158401",
      "fullText" : "Which #Altcoins are ready to explode ? 💎😏",
      "expandedUrl" : "https://twitter.com/i/web/status/1686003461421158401"
    }
  },
  {
    "like" : {
      "tweetId" : "1685560952257654784",
      "fullText" : "Hi",
      "expandedUrl" : "https://twitter.com/i/web/status/1685560952257654784"
    }
  },
  {
    "like" : {
      "tweetId" : "1686066505887473664",
      "fullText" : "@ElonMuskAOC This mode https://t.co/KdAh1xLIaH",
      "expandedUrl" : "https://twitter.com/i/web/status/1686066505887473664"
    }
  },
  {
    "like" : {
      "tweetId" : "1602365343841882112",
      "fullText" : "@Microsoft No, it's usually Shane Watson from Bangalore, sometimes Ronald Turnpike from Delhi.",
      "expandedUrl" : "https://twitter.com/i/web/status/1602365343841882112"
    }
  },
  {
    "like" : {
      "tweetId" : "1686039942198374400",
      "fullText" : "Real software engineers don’t use ChatGPT.\n\nThey don’t use Copilot.\n\nThey don’t use StackOverflow or Google.\n\nThey don’t use a code editor.\n\nIn fact, they don’t use computers.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686039942198374400"
    }
  },
  {
    "like" : {
      "tweetId" : "1685990504876683264",
      "fullText" : "What memecoin project should everyone buy? 🟢🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1685990504876683264"
    }
  },
  {
    "like" : {
      "tweetId" : "1685830731011141634",
      "fullText" : "Whats the next coin that’s gonna do this? 🤔 https://t.co/cdYJvDFvxV",
      "expandedUrl" : "https://twitter.com/i/web/status/1685830731011141634"
    }
  },
  {
    "like" : {
      "tweetId" : "1685853369485950976",
      "fullText" : "leave the code better than how you found it",
      "expandedUrl" : "https://twitter.com/i/web/status/1685853369485950976"
    }
  },
  {
    "like" : {
      "tweetId" : "1685961249647898624",
      "fullText" : "Shill me your biggest #altcoin holding! 💪 🚀 💎",
      "expandedUrl" : "https://twitter.com/i/web/status/1685961249647898624"
    }
  },
  {
    "like" : {
      "tweetId" : "1685048326213828608",
      "fullText" : "New water deluge system to protect against the immense heat &amp; force of Starship launch https://t.co/JMnBIH8UTM",
      "expandedUrl" : "https://twitter.com/i/web/status/1685048326213828608"
    }
  },
  {
    "like" : {
      "tweetId" : "1684604940310675456",
      "fullText" : "@AvieDev Mum says no cake,\nKid says mum 100000000 times\nMum breaks",
      "expandedUrl" : "https://twitter.com/i/web/status/1684604940310675456"
    }
  },
  {
    "like" : {
      "tweetId" : "1684939590098911232",
      "fullText" : "You can’t get time back.\n\nThat’s why I can’t afford to spend time in toxic workplaces anymore.\n\nOr spend time with toxic people. \n\nOr spend time on things that are not helping me.\n\nThe more I age, the more I realise how time flies. Time I can’t get back.\n\nSpend your time wisely!",
      "expandedUrl" : "https://twitter.com/i/web/status/1684939590098911232"
    }
  },
  {
    "like" : {
      "tweetId" : "1684619608873984002",
      "fullText" : "I'm old school.\n\nI prefer to use sticky notes for todos. \n\nI prefer to read physical books rather than digital ones.\n\nI prefer to break down concepts on paper.\n\nI prefer less tech surrounding me.\n\nI can’t be the only one! 😅",
      "expandedUrl" : "https://twitter.com/i/web/status/1684619608873984002"
    }
  },
  {
    "like" : {
      "tweetId" : "1684604680637480962",
      "fullText" : "|￣￣￣￣￣￣￣￣￣￣￣￣￣|\n        Real developers push \n              directly to main\n|＿＿＿＿＿＿＿＿＿＿＿＿＿|\n                     \\ (•◡•) / \n                       \\       / \n                        ——\n                         |     |\n                         |_   |_",
      "expandedUrl" : "https://twitter.com/i/web/status/1684604680637480962"
    }
  },
  {
    "like" : {
      "tweetId" : "1684298714205093891",
      "fullText" : "AI will replace all software engineers",
      "expandedUrl" : "https://twitter.com/i/web/status/1684298714205093891"
    }
  },
  {
    "like" : {
      "tweetId" : "1684188458410180608",
      "fullText" : "I apologize if I have ever said anything bad about Python.\n\nIt is quickly becoming my favorite programming language to work with.",
      "expandedUrl" : "https://twitter.com/i/web/status/1684188458410180608"
    }
  },
  {
    "like" : {
      "tweetId" : "1664626788268494850",
      "fullText" : "Here for the memories 🥹 https://t.co/B1K6vlK1Ly",
      "expandedUrl" : "https://twitter.com/i/web/status/1664626788268494850"
    }
  },
  {
    "like" : {
      "tweetId" : "1663711901484822530",
      "fullText" : "The staggering number of people trying to summit Mt. Everest 🤨\n\n🔊 https://t.co/zKTW5Uyh5s",
      "expandedUrl" : "https://twitter.com/i/web/status/1663711901484822530"
    }
  },
  {
    "like" : {
      "tweetId" : "1659779682093645824",
      "fullText" : "These are unusual whales: https://t.co/TjmIWwqjoI",
      "expandedUrl" : "https://twitter.com/i/web/status/1659779682093645824"
    }
  },
  {
    "like" : {
      "tweetId" : "1659344190331912198",
      "fullText" : "@elonmusk People frantically googling - elucidation. https://t.co/OrUzX2y2Po",
      "expandedUrl" : "https://twitter.com/i/web/status/1659344190331912198"
    }
  },
  {
    "like" : {
      "tweetId" : "1659340939477876737",
      "fullText" : "I hope this platform increasingly brings you joy &amp; elucidation",
      "expandedUrl" : "https://twitter.com/i/web/status/1659340939477876737"
    }
  },
  {
    "like" : {
      "tweetId" : "1659419397327339521",
      "fullText" : "I have spaceships",
      "expandedUrl" : "https://twitter.com/i/web/status/1659419397327339521"
    }
  },
  {
    "like" : {
      "tweetId" : "1654793087674138624",
      "fullText" : "Our true queen of hearts never forgotten  #Coronation https://t.co/x03gyxMAWT",
      "expandedUrl" : "https://twitter.com/i/web/status/1654793087674138624"
    }
  },
  {
    "like" : {
      "tweetId" : "1654636648032813056",
      "fullText" : "High Ethereum gas fees will push more adoption to layer 2s like optimism, Arbitrum, polygon, and ZkSync.\n\nThis was always the plan.\n\nBullish.",
      "expandedUrl" : "https://twitter.com/i/web/status/1654636648032813056"
    }
  },
  {
    "like" : {
      "tweetId" : "1652049254087811072",
      "fullText" : "@MuskUniversity Physics is the law, everything else is a recommendation. \n\nAnyone can break laws created by people, but I have yet to see anyone break the laws of physics.",
      "expandedUrl" : "https://twitter.com/i/web/status/1652049254087811072"
    }
  },
  {
    "like" : {
      "tweetId" : "1652217161820041218",
      "fullText" : "LFG! We’ve been chosen to  be in #AlchemyAmplify! We’re working with @alchemyplatform to build out the forgivenet. Check out https://t.co/Iu5ef5haKj https://t.co/bFu132YD7E",
      "expandedUrl" : "https://twitter.com/i/web/status/1652217161820041218"
    }
  },
  {
    "like" : {
      "tweetId" : "1646824088940232704",
      "fullText" : "@TRHLofficial Any parent or doctor who sterilizes a child before they are a consenting adult should go to prison for life",
      "expandedUrl" : "https://twitter.com/i/web/status/1646824088940232704"
    }
  },
  {
    "like" : {
      "tweetId" : "1646860498611077121",
      "fullText" : "@TwitterSupport @elonmusk https://t.co/EU49n3tHF9 https://t.co/FCFASWJCrh",
      "expandedUrl" : "https://twitter.com/i/web/status/1646860498611077121"
    }
  },
  {
    "like" : {
      "tweetId" : "1646864714729926657",
      "fullText" : "https://t.co/CtywpkEkd0",
      "expandedUrl" : "https://twitter.com/i/web/status/1646864714729926657"
    }
  },
  {
    "like" : {
      "tweetId" : "1646860036331929600",
      "fullText" : "THIS TWITTER ACCOUNT IS COMPROMISED!\n\nDo not trust it until confirmed by @the_matter_labs and @gluk64\n\n@TwitterSupport, @elonmusk please respond to support requests!",
      "expandedUrl" : "https://twitter.com/i/web/status/1646860036331929600"
    }
  },
  {
    "like" : {
      "tweetId" : "1646860946365722624",
      "fullText" : "@zksync @the_matter_labs @gluk64 @TwitterSupport @elonmusk The hacker on the other side of this tweet https://t.co/1OvwSvPu7y",
      "expandedUrl" : "https://twitter.com/i/web/status/1646860946365722624"
    }
  },
  {
    "like" : {
      "tweetId" : "1646861383349198848",
      "fullText" : "@zksync @the_matter_labs @gluk64 @TwitterSupport @elonmusk https://t.co/rqIwO27y6G",
      "expandedUrl" : "https://twitter.com/i/web/status/1646861383349198848"
    }
  },
  {
    "like" : {
      "tweetId" : "1643338514061295618",
      "fullText" : "@SenSchumer To avoid losing the trust of the American public, it is important that our justice system pursue Democrats and Republicans with equal vigor.\n\nWhichever party most puts justice before nepotism is the one that deserves trust.",
      "expandedUrl" : "https://twitter.com/i/web/status/1643338514061295618"
    }
  },
  {
    "like" : {
      "tweetId" : "1643226802565922816",
      "fullText" : "🤓📊  @zkSync Era - Understanding smart contract architecture made easy with this diagram! \n\nCheck out the components of this system including:\n• zkSync Diamond Proxy\n• Verifier\n• ValidatorTimelock\n• L1ERC20Bridge https://t.co/3EL4xYvoca",
      "expandedUrl" : "https://twitter.com/i/web/status/1643226802565922816"
    }
  },
  {
    "like" : {
      "tweetId" : "1640741135210672129",
      "fullText" : "Responsible disclosure and community contributions to security are critical for safeguarding zkSync Era. We’re excited to announce that the @Immunefi bug bounty reward has been increased to $1.1M, with all L2 assets now in scope.\n\nHelp secure zkSync Era: https://t.co/6LmwRAdmJZ https://t.co/NMnLL7AGKq",
      "expandedUrl" : "https://twitter.com/i/web/status/1640741135210672129"
    }
  },
  {
    "like" : {
      "tweetId" : "1641045287106912258",
      "fullText" : "Women don't apply to $100k roles as often as men, but they're hired for them more, per Bloomberg.",
      "expandedUrl" : "https://twitter.com/i/web/status/1641045287106912258"
    }
  },
  {
    "like" : {
      "tweetId" : "1640977505220984833",
      "fullText" : "@TeslaDiva99 Tesla car temp is automatically kept within a safe range, even when the car appears “off”, in order to protect infants &amp; pets.\n\nThat said, it would be more convenient to keep the car “on” for entertainment &amp; comfort if the camera detects occupants. We will make that change.",
      "expandedUrl" : "https://twitter.com/i/web/status/1640977505220984833"
    }
  },
  {
    "like" : {
      "tweetId" : "1640892417602727936",
      "fullText" : "Hey @elonmusk I left my teenager and little in the car to go into the store. The car instantly shut off and my oldest had to touch the screen to turn it back on. If an infant was left, the car would shut down. Can y’all do something to detect people in the car and keep temp on?",
      "expandedUrl" : "https://twitter.com/i/web/status/1640892417602727936"
    }
  },
  {
    "like" : {
      "tweetId" : "1637600073293918216",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1637600073293918216"
    }
  },
  {
    "like" : {
      "tweetId" : "1636898888287236099",
      "fullText" : "In the months ahead, we will use AI to detect &amp; highlight manipulation of public opinion on this platform.\n\nLet’s see what the psy ops cat drags in …",
      "expandedUrl" : "https://twitter.com/i/web/status/1636898888287236099"
    }
  },
  {
    "like" : {
      "tweetId" : "1624479812139077639",
      "fullText" : "It's time to give love to the forgivenetTM folks.\n\nhttps://t.co/K5oxxxIm0Y\n\nWe support safety for children and their happy adult lives.\n\nhttps://t.co/zDsB6KfXRF",
      "expandedUrl" : "https://twitter.com/i/web/status/1624479812139077639"
    }
  },
  {
    "like" : {
      "tweetId" : "1516490900532350980",
      "fullText" : "@ThisEgg_ How about some self inquiry about how groomed you all are. https://t.co/SKh3UVPtOe #groomedAsF",
      "expandedUrl" : "https://twitter.com/i/web/status/1516490900532350980"
    }
  },
  {
    "like" : {
      "tweetId" : "1545386193541632001",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1545386193541632001"
    }
  },
  {
    "like" : {
      "tweetId" : "1609604417128464384",
      "fullText" : "Happy new year everyone \nMy 1st tip for big returns next bull-run is \nAGIX singularity net \nThe best AI company in the world .\nEverything AI is the future , like or hate , its a fact .\n#Crypto #ArtificialIntelligence #CryptoInvestor",
      "expandedUrl" : "https://twitter.com/i/web/status/1609604417128464384"
    }
  },
  {
    "like" : {
      "tweetId" : "1612990869900075010",
      "fullText" : "What song would be playing on hell’s elevator going down? I vote for “Seasons in the Sun,” by Terry Jacks. What’s your thought on it?",
      "expandedUrl" : "https://twitter.com/i/web/status/1612990869900075010"
    }
  },
  {
    "like" : {
      "tweetId" : "1612191619826216961",
      "fullText" : "Request forgiveness. Earn a crypto reward.\n\nFEEL BETTER AFTERWARDS.\n\nhttps://t.co/Iu5ef5hIzR",
      "expandedUrl" : "https://twitter.com/i/web/status/1612191619826216961"
    }
  },
  {
    "like" : {
      "tweetId" : "1610686887085346817",
      "fullText" : "Elon Musk is calling for the Epstein client list to be released. Do you agree with him?",
      "expandedUrl" : "https://twitter.com/i/web/status/1610686887085346817"
    }
  },
  {
    "like" : {
      "tweetId" : "1609209529706872833",
      "fullText" : "@balajis Reaching the \"basic rollup scaling\" milestone in my roadmap diagram.\n\nThat means:\n\n* EIP-4844 rolled out\n* Rollups partially taking off training wheels, at least to \"stage 1\" as described here https://t.co/qNQonDQkzG https://t.co/7HePctWw1l",
      "expandedUrl" : "https://twitter.com/i/web/status/1609209529706872833"
    }
  },
  {
    "like" : {
      "tweetId" : "1605870381310439425",
      "fullText" : "@tunguz He’s great",
      "expandedUrl" : "https://twitter.com/i/web/status/1605870381310439425"
    }
  },
  {
    "like" : {
      "tweetId" : "1605651313240391681",
      "fullText" : "Web3, crypto, blockchain will continue to grow.",
      "expandedUrl" : "https://twitter.com/i/web/status/1605651313240391681"
    }
  },
  {
    "like" : {
      "tweetId" : "1604650028999405568",
      "fullText" : "Those who want power are the ones who least deserve it",
      "expandedUrl" : "https://twitter.com/i/web/status/1604650028999405568"
    }
  },
  {
    "like" : {
      "tweetId" : "1602783723673378816",
      "fullText" : "BREAKING: SBF has been denied bail.",
      "expandedUrl" : "https://twitter.com/i/web/status/1602783723673378816"
    }
  },
  {
    "like" : {
      "tweetId" : "1602022235023314949",
      "fullText" : "If @elonmusk is saving the “best for last”, the absolute most damning piece of evidence conceivable that would blow the minds of everyone, right and left, for the final reveal…\n\nWhat would it be?",
      "expandedUrl" : "https://twitter.com/i/web/status/1602022235023314949"
    }
  },
  {
    "like" : {
      "tweetId" : "1601073437056765952",
      "fullText" : "@unusual_whales Controversial decisions were often made without getting Jack’s approval and he was unaware of systemic bias. The inmates were running the asylum. \n\nJack has a pure heart imo.",
      "expandedUrl" : "https://twitter.com/i/web/status/1601073437056765952"
    }
  },
  {
    "like" : {
      "tweetId" : "1601042527322509312",
      "fullText" : "BREAKING: Twitter Files released by Elon Musk, Matt Taibbi &amp; Bari Weiss, have suggested that a secret group headed by Vijaya Gadde, the Head of Legal, Yoel Roth, the Head of Trust, CEOs Jack Dorsey &amp; Parag, &amp; others, made decisions secretly &amp; without overview to moderate Twitter.",
      "expandedUrl" : "https://twitter.com/i/web/status/1601042527322509312"
    }
  },
  {
    "like" : {
      "tweetId" : "1599448251563851776",
      "fullText" : "@AltcoinDailyio Man utd",
      "expandedUrl" : "https://twitter.com/i/web/status/1599448251563851776"
    }
  },
  {
    "like" : {
      "tweetId" : "1598990820665065472",
      "fullText" : "@OzraeliAvi I’ve seen a lot of concerning tweets about the recent Brazil election. If those tweets are accurate, it’s possible that Twitter personnel gave preference to left wing candidates.",
      "expandedUrl" : "https://twitter.com/i/web/status/1598990820665065472"
    }
  },
  {
    "like" : {
      "tweetId" : "1598064202400534528",
      "fullText" : "@jhall Cancel culture needs to be canceled!!",
      "expandedUrl" : "https://twitter.com/i/web/status/1598064202400534528"
    }
  },
  {
    "like" : {
      "tweetId" : "1597697534432280576",
      "fullText" : "Yes that’s Me … https://t.co/HBk3J8yYez",
      "expandedUrl" : "https://twitter.com/i/web/status/1597697534432280576"
    }
  },
  {
    "like" : {
      "tweetId" : "1597524485074485248",
      "fullText" : "@Liz_Wheeler This will forever be our top priority",
      "expandedUrl" : "https://twitter.com/i/web/status/1597524485074485248"
    }
  },
  {
    "like" : {
      "tweetId" : "1597336812732575744",
      "fullText" : "The Twitter Files on free speech suppression soon to be published on Twitter itself. The public deserves to know what really happened …",
      "expandedUrl" : "https://twitter.com/i/web/status/1597336812732575744"
    }
  },
  {
    "like" : {
      "tweetId" : "1596591361741889536",
      "fullText" : "@alex_avoigt Correct. Good thread.",
      "expandedUrl" : "https://twitter.com/i/web/status/1596591361741889536"
    }
  },
  {
    "like" : {
      "tweetId" : "1596183261843447809",
      "fullText" : "6) Use common sense\nIf a company rule doesn’t:\n- Make sense\n- Contribute to progress\n- Apply to your specific situation\nAvoid following the rule with your eyes closed.\nDon’t follow rules. Follow principles.",
      "expandedUrl" : "https://twitter.com/i/web/status/1596183261843447809"
    }
  },
  {
    "like" : {
      "tweetId" : "1596183161284665344",
      "fullText" : "You can resolve most issues without a meeting.\nInstead of meetings:\n- Send a text\n- Send an email\n- Communicate on a discord or slack channel\nDon’t interrupt your team’s workflow if it’s unnecessary.",
      "expandedUrl" : "https://twitter.com/i/web/status/1596183161284665344"
    }
  },
  {
    "like" : {
      "tweetId" : "1596183088455122944",
      "fullText" : "5) Ditch frequent meetings\nThere’s no better way to waste everyone’s time.\nUse meetings to:\n- Collaborate\n- Attack issues head-on\n- Solve urgent problems\nBut once you resolve the issue, frequent meetings are no longer necessary.",
      "expandedUrl" : "https://twitter.com/i/web/status/1596183088455122944"
    }
  },
  {
    "like" : {
      "tweetId" : "1596182887535198214",
      "fullText" : "4) Be clear, not clever\nAvoid nonsense words and technical jargon.\nIt slows down communication.\nChoose words that are:\n- Concise\n- To the point\n- Easy to understand\nDon’t sound smart. Be efficient.",
      "expandedUrl" : "https://twitter.com/i/web/status/1596182887535198214"
    }
  },
  {
    "like" : {
      "tweetId" : "1596182538611216384",
      "fullText" : "3) Forget the chain of command\nCommunicate with colleagues directly.\nNot through supervisors or managers.\nFast communicators make fast decisions.\nFast decisions = competitive advantage.",
      "expandedUrl" : "https://twitter.com/i/web/status/1596182538611216384"
    }
  },
  {
    "like" : {
      "tweetId" : "1596182443823960065",
      "fullText" : "... you’re certain they provide value to everyone\n\n2) Leave a meeting if you’re not contributing\nIf a meeting doesn’t require your:\n- Input\n- Value\n- Decisions\nYour presence is useless.\nIt’s not rude to leave a meeting.\nBut it’s rude to waste people’s time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1596182443823960065"
    }
  },
  {
    "like" : {
      "tweetId" : "1596182210159456256",
      "fullText" : "Elon reportedly send this mail to Tesla employees:\n\n1) Avoid large meetings\nLarge meetings waste valuable time &amp; energy\n- They discourage debate\n- People are more guarded than open\n- There’s not enough time for everyone to contribute\nDon’t schedule large meetings unless ...",
      "expandedUrl" : "https://twitter.com/i/web/status/1596182210159456256"
    }
  },
  {
    "like" : {
      "tweetId" : "1595869526469533701",
      "fullText" : "The people have spoken.\n\nAmnesty begins next week.\n\nVox Populi, Vox Dei.",
      "expandedUrl" : "https://twitter.com/i/web/status/1595869526469533701"
    }
  },
  {
    "like" : {
      "tweetId" : "1594763768772366341",
      "fullText" : "We would very much like to be excluded from this narrative. https://t.co/kkB5uVV7yf",
      "expandedUrl" : "https://twitter.com/i/web/status/1594763768772366341"
    }
  },
  {
    "like" : {
      "tweetId" : "1594684996828205056",
      "fullText" : "@edatweets_ Because they are?",
      "expandedUrl" : "https://twitter.com/i/web/status/1594684996828205056"
    }
  },
  {
    "like" : {
      "tweetId" : "1593693736277577728",
      "fullText" : "As Mark Twain might have said, \"The rumors of Twitter's death are greatly exaggerated.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1593693736277577728"
    }
  },
  {
    "like" : {
      "tweetId" : "1593681389937102851",
      "fullText" : "@HardcoreNolley No",
      "expandedUrl" : "https://twitter.com/i/web/status/1593681389937102851"
    }
  },
  {
    "like" : {
      "tweetId" : "1592171663952842755",
      "fullText" : "gm. \n\nwhat ya shipping? links only.",
      "expandedUrl" : "https://twitter.com/i/web/status/1592171663952842755"
    }
  },
  {
    "like" : {
      "tweetId" : "1592235372574277632",
      "fullText" : "back to work, new post tomorrow 🙂 time to go down the zk rabbit hole",
      "expandedUrl" : "https://twitter.com/i/web/status/1592235372574277632"
    }
  },
  {
    "like" : {
      "tweetId" : "1592259927875420160",
      "fullText" : "Is coinbase wallet safe to hold crypto ?",
      "expandedUrl" : "https://twitter.com/i/web/status/1592259927875420160"
    }
  },
  {
    "like" : {
      "tweetId" : "1591144707744501760",
      "fullText" : "@BlockFi November 9th 2022  I withdrew every penny I had in blockfi , \nI recieved all my funds  on the 10th November , no problem at all.",
      "expandedUrl" : "https://twitter.com/i/web/status/1591144707744501760"
    }
  },
  {
    "like" : {
      "tweetId" : "1591137259180666880",
      "fullText" : "@alexacrypto_ None … Trust no one ..",
      "expandedUrl" : "https://twitter.com/i/web/status/1591137259180666880"
    }
  },
  {
    "like" : {
      "tweetId" : "1590886170543915009",
      "fullText" : "To be more precise, accounts doing parody impersonations. Basically, tricking people is not ok.",
      "expandedUrl" : "https://twitter.com/i/web/status/1590886170543915009"
    }
  },
  {
    "like" : {
      "tweetId" : "1590844382353141760",
      "fullText" : "Restore my faith.\n\nWho are the good people in crypto?",
      "expandedUrl" : "https://twitter.com/i/web/status/1590844382353141760"
    }
  },
  {
    "like" : {
      "tweetId" : "1590747753352933378",
      "fullText" : "@StephenKing 👻",
      "expandedUrl" : "https://twitter.com/i/web/status/1590747753352933378"
    }
  },
  {
    "like" : {
      "tweetId" : "1590725965680095232",
      "fullText" : "I think I liked Twitter better in the pre-Musk days. Less controversy, more fun.",
      "expandedUrl" : "https://twitter.com/i/web/status/1590725965680095232"
    }
  },
  {
    "like" : {
      "tweetId" : "1590819661364744193",
      "fullText" : "Gala games imo is a gaming industry game changer of a token , that will go right past the moon to mars next bull run …and its at a rock bottom price ATM … this token will make millionaires.\n#gala #gaming #cryptocurrency  #altcoin",
      "expandedUrl" : "https://twitter.com/i/web/status/1590819661364744193"
    }
  },
  {
    "like" : {
      "tweetId" : "1590336744104525824",
      "fullText" : "It’s the end Of the world as we know it , and I feel fine \n#altcoin #Bitcoin #cryptomarket #cryptocurrency",
      "expandedUrl" : "https://twitter.com/i/web/status/1590336744104525824"
    }
  },
  {
    "like" : {
      "tweetId" : "1589754158625669120",
      "fullText" : "Who are you?",
      "expandedUrl" : "https://twitter.com/i/web/status/1589754158625669120"
    }
  },
  {
    "like" : {
      "tweetId" : "1589882652261519360",
      "fullText" : "I believe we are very near the end of the bear market , and recovery slowly starts in January 2023 , agree or disagree  ?",
      "expandedUrl" : "https://twitter.com/i/web/status/1589882652261519360"
    }
  },
  {
    "like" : {
      "tweetId" : "1589710335346618368",
      "fullText" : "Looking at a good gaming token , I have to say Illuvium looks like a steal atm ..all time highs close to $3000 now around $60 \nAnd the game is amazing and so are the graphics .\n#gaming #Crypto #altcoins",
      "expandedUrl" : "https://twitter.com/i/web/status/1589710335346618368"
    }
  },
  {
    "like" : {
      "tweetId" : "1589641513575022593",
      "fullText" : "Gave an interview in the morning, and got the offer in the evening 🥹💜✨",
      "expandedUrl" : "https://twitter.com/i/web/status/1589641513575022593"
    }
  },
  {
    "like" : {
      "tweetId" : "1589554203412004864",
      "fullText" : "Solidity for pleasure, Rust for money",
      "expandedUrl" : "https://twitter.com/i/web/status/1589554203412004864"
    }
  },
  {
    "like" : {
      "tweetId" : "1589684778789634050",
      "fullText" : "I have no idea what so many people in crypto/web3 do",
      "expandedUrl" : "https://twitter.com/i/web/status/1589684778789634050"
    }
  },
  {
    "like" : {
      "tweetId" : "1588967070087401472",
      "fullText" : "Seeing so many empty seats in a couple of web3 events. \n\nDisheartening for the people who put so much sweat into organizing these events + sponsors fueling $$ to expect footfall.  \n\nCome to Asia, and you'll find zero empty seats + better ROI. Heck, people will be seen standing.",
      "expandedUrl" : "https://twitter.com/i/web/status/1588967070087401472"
    }
  },
  {
    "like" : {
      "tweetId" : "1589243144398196736",
      "fullText" : "@alexacrypto___ Your wish is my command…  look at high street , look at gala games , look at dent , rfox, harmony ,look at render , look at lunaone … have a great day",
      "expandedUrl" : "https://twitter.com/i/web/status/1589243144398196736"
    }
  },
  {
    "like" : {
      "tweetId" : "1589244817565188099",
      "fullText" : "What coin is your favorite and one you have big hopes for next bull run \n#crypto #altcoins #investing #Cryptocurency",
      "expandedUrl" : "https://twitter.com/i/web/status/1589244817565188099"
    }
  },
  {
    "like" : {
      "tweetId" : "1589242319118958592",
      "fullText" : "Medieval empires is going to massive , get on board , and get ready to battle.\n#MedievalEmpires #PlayToEarn #CryptoGaming",
      "expandedUrl" : "https://twitter.com/i/web/status/1589242319118958592"
    }
  },
  {
    "like" : {
      "tweetId" : "1588499658015641601",
      "fullText" : "Created my first zkApp using @MinaProtocol 👩‍💻",
      "expandedUrl" : "https://twitter.com/i/web/status/1588499658015641601"
    }
  },
  {
    "like" : {
      "tweetId" : "1495492546751254528",
      "fullText" : "My Goerli faucet is out of funds. The faucet got over 1 million requests yesterday.\n\nI don't think it's worth topping it up again without making a significant change.\n\nA PoW faucet will be cool.",
      "expandedUrl" : "https://twitter.com/i/web/status/1495492546751254528"
    }
  },
  {
    "like" : {
      "tweetId" : "1588538640401018880",
      "fullText" : "Twitter has had a massive drop in revenue, due to activist groups pressuring advertisers, even though nothing has changed with content moderation and we did everything we could to appease the activists.\n\nExtremely messed up! They’re trying to destroy free speech in America.",
      "expandedUrl" : "https://twitter.com/i/web/status/1588538640401018880"
    }
  },
  {
    "like" : {
      "tweetId" : "1588190020967563266",
      "fullText" : "I'm leaving web 2.0",
      "expandedUrl" : "https://twitter.com/i/web/status/1588190020967563266"
    }
  },
  {
    "like" : {
      "tweetId" : "1586280188425670662",
      "fullText" : "@JackChardwood Thank you soo much ….we had a great night m went to see !0cc. , love ya lots xx",
      "expandedUrl" : "https://twitter.com/i/web/status/1586280188425670662"
    }
  },
  {
    "like" : {
      "tweetId" : "1586059953311137792",
      "fullText" : "Twitter will be forming a content moderation council with widely diverse viewpoints. \n\nNo major content decisions or account reinstatements will happen before that council convenes.",
      "expandedUrl" : "https://twitter.com/i/web/status/1586059953311137792"
    }
  },
  {
    "like" : {
      "tweetId" : "1585729498670305280",
      "fullText" : "Science marvels at the bridge that Lord Ram built. https://t.co/RWW105fPLx",
      "expandedUrl" : "https://twitter.com/i/web/status/1585729498670305280"
    }
  },
  {
    "like" : {
      "tweetId" : "1586017274015625218",
      "fullText" : "Gm to everyone building a better world through web3 and open source ☀️",
      "expandedUrl" : "https://twitter.com/i/web/status/1586017274015625218"
    }
  },
  {
    "like" : {
      "tweetId" : "1586012102355042312",
      "fullText" : "Elon Musk has emerged in recent months as a new, chaotic actor in global politics. He has waded into situations involving Russia, Ukraine, Iran and China, and left behind plenty of messes. Now that he owns Twitter, his influence is set to grow. https://t.co/Teov1dcW93",
      "expandedUrl" : "https://twitter.com/i/web/status/1586012102355042312"
    }
  },
  {
    "like" : {
      "tweetId" : "1586038983347142656",
      "fullText" : "Once you start to enjoy writing smart contracts there's no going back.",
      "expandedUrl" : "https://twitter.com/i/web/status/1586038983347142656"
    }
  },
  {
    "like" : {
      "tweetId" : "1585841080431321088",
      "fullText" : "the bird is freed",
      "expandedUrl" : "https://twitter.com/i/web/status/1585841080431321088"
    }
  },
  {
    "like" : {
      "tweetId" : "1585969572259147776",
      "fullText" : "@TransphobicLs @elonmusk Bro, your life must be so easy that you are concerned about what pronoun everyone call you with lmao",
      "expandedUrl" : "https://twitter.com/i/web/status/1585969572259147776"
    }
  },
  {
    "like" : {
      "tweetId" : "1585966869122457600",
      "fullText" : "🎶 let the good times roll 🎶",
      "expandedUrl" : "https://twitter.com/i/web/status/1585966869122457600"
    }
  },
  {
    "like" : {
      "tweetId" : "1577795819503132673",
      "fullText" : "~750 applications in 1h - you folks are crazy.",
      "expandedUrl" : "https://twitter.com/i/web/status/1577795819503132673"
    }
  },
  {
    "like" : {
      "tweetId" : "1577785507764789248",
      "fullText" : "Follow @alchemyLearn for more alpha!",
      "expandedUrl" : "https://twitter.com/i/web/status/1577785507764789248"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779221392343040",
      "fullText" : "11 / Ready to build?\n\nThe AU website is LIVE today, with courses launching very soon!\n\n- Apply for early access using the link below\n- Retweet\n- Comment below to move up the list!\n\nLFL (learn! 😜)\n\nhttps://t.co/qYJPDdcFuu",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779221392343040"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779220339490816",
      "fullText" : "10/ are you a web3 dev looking to build real projects with personal support?\n\nCrowd favorites like Alchemy’s Road to Web3 are also now part of AU! 🚀\n\nAnd it continues to be free with the fastest-growing (&amp; most fun) dev community in web3! 😋",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779220339490816"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779219248996352",
      "fullText" : "9/ Have some coding experience &amp; want to learn web3 development?\n\nor\n\nDabbled in blockchain &amp; want to reinforce the fundamentals?\n\nOur legendary Ethereum Developer Bootcamp from the Chainshot team is made for you 🤗",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779219248996352"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779217726525440",
      "fullText" : "8/ New to coding or don’t know JavaScript yet?\n\nThen AU’s JS Fundamentals course is the perfect foundation for becoming a web3 dev! 🎯\n\n(JS is a core foundation for Ethereum development)",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779217726525440"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779216606633989",
      "fullText" : "7/ A killer collab:\n\nCombining Chainshot’s iconic bootcamps &amp; teachers w/ Alchemy programs like Road to Web3 makes AU the most comprehensive web3 education hub available 🤝\n\nComprehensive, because we thought about everyone - here’s how to know which AU program is for you:",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779216606633989"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779215537053697",
      "fullText" : "6/ Project-based learning\n\nThe best way to learn is by building projects.\n\nThat’s why you’ll build your dApp portfolio by shipping some of the most crucial experiences in web3:\n\n🖼️ NFT marketplaces\n\n💸 DeFi exchanges \n\n🕹️ Gaming dApps\n\n&amp; way more!",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779215537053697"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779214064832514",
      "fullText" : "5/ Alongside 1000s of fellow builders, you’ll take part in practical bootcamps covering: \n\n✅ Cryptography\n✅ Solidity development \n✅ Smart contract security\n✅ Proxy contracts\n✅ Delegate calls\n\n+ everything you need to know to become a web3 dev, upscale your skills &amp; land jobs",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779214064832514"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779212961779712",
      "fullText" : "4/ Alchemy University isn’t just a web3 dev course, it’s an entire ecosystem for building your skills &amp; network.\n\nBeing an AU student means hands-on guidance while you learn 👯‍♀️\n\nso you’re not alone when navigating the new world of web3.",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779212961779712"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779211816775680",
      "fullText" : "3/ Learning something new is tough, and accountability is hard.\n\nThat’s why we set out to create an education experience that shortens the learning curve for web3 devs, and rewards them too!\n\nBut what is Alchemy University &amp; how will it make web3 education fast, free &amp; fun?",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779211816775680"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779209346330624",
      "fullText" : "1/ Want to become a web3 dev?\n\nWhat if we told you we’re releasing the ultimate web3 learning platform… for free?\n\nChainshot recently joined Alchemy &amp; together we’ve built something new.\n\nBuckle up frens, Alchemy University is here!\n\nA 🧵 on the future of web3 education",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779209346330624"
    }
  },
  {
    "like" : {
      "tweetId" : "1577779210789101568",
      "fullText" : "2/ We have a mission: to bring web3 to 1 billion people.\n\nThat means providing devs with the resources they need to build stunning products - and join incredible web3 companies.\n\nNo costs, no walls, just free top-notch education for everyone, to get you job-ready.",
      "expandedUrl" : "https://twitter.com/i/web/status/1577779210789101568"
    }
  },
  {
    "like" : {
      "tweetId" : "1694052163587289130",
      "fullText" : "https://t.co/muK8fg9Fq2",
      "expandedUrl" : "https://twitter.com/i/web/status/1694052163587289130"
    }
  },
  {
    "like" : {
      "tweetId" : "1694217698350354569",
      "fullText" : "Teach your children how to think, not what to think.",
      "expandedUrl" : "https://twitter.com/i/web/status/1694217698350354569"
    }
  },
  {
    "like" : {
      "tweetId" : "1693846181196243259",
      "fullText" : "https://t.co/aFsr3uOmtj",
      "expandedUrl" : "https://twitter.com/i/web/status/1693846181196243259"
    }
  },
  {
    "like" : {
      "tweetId" : "1693977706831225312",
      "fullText" : "https://t.co/TJc3JX0gv0",
      "expandedUrl" : "https://twitter.com/i/web/status/1693977706831225312"
    }
  },
  {
    "like" : {
      "tweetId" : "1693655448870867451",
      "fullText" : "Uh oh, is this true? https://t.co/02fWMcmTHQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1693655448870867451"
    }
  },
  {
    "like" : {
      "tweetId" : "1692907180951765452",
      "fullText" : "How do you say \"BRO\" in your country?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692907180951765452"
    }
  },
  {
    "like" : {
      "tweetId" : "1692899046577340425",
      "fullText" : "Is it appropriate to make up stories about you, just to create storytelling content?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692899046577340425"
    }
  },
  {
    "like" : {
      "tweetId" : "1692616855020814718",
      "fullText" : "I'm Buying More ________.",
      "expandedUrl" : "https://twitter.com/i/web/status/1692616855020814718"
    }
  },
  {
    "like" : {
      "tweetId" : "1692530827329180132",
      "fullText" : "It costs you $0 to stop copying others posts.",
      "expandedUrl" : "https://twitter.com/i/web/status/1692530827329180132"
    }
  },
  {
    "like" : {
      "tweetId" : "1692486125904863309",
      "fullText" : "If someone wrote a book about your life\n\nWhat would the title be?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692486125904863309"
    }
  },
  {
    "like" : {
      "tweetId" : "1692494339400700163",
      "fullText" : "GM #crypto fam!💎 \n\nShill me the next #1000x 🔥👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1692494339400700163"
    }
  },
  {
    "like" : {
      "tweetId" : "1692478343801716808",
      "fullText" : "@JackChardwood Hahah https://t.co/8OnbIALELI",
      "expandedUrl" : "https://twitter.com/i/web/status/1692478343801716808"
    }
  },
  {
    "like" : {
      "tweetId" : "1692446734662918346",
      "fullText" : "I was afraid.\n\n\"What will they think?\"\n\nBro, wake up.\n\nNobody cares.\n\nI spilled a bucket of yogurt today.\n\nIn front 100's people.\n\nNobody cared.\n\nUnderstand?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692446734662918346"
    }
  },
  {
    "like" : {
      "tweetId" : "1692190294752813342",
      "fullText" : "Do you think we are born with a purpose?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692190294752813342"
    }
  },
  {
    "like" : {
      "tweetId" : "1692162611981496661",
      "fullText" : "Is music a distraction or an assistant for you?🎶",
      "expandedUrl" : "https://twitter.com/i/web/status/1692162611981496661"
    }
  },
  {
    "like" : {
      "tweetId" : "1692224771466072449",
      "fullText" : "Finish the sentence:\n\n''The WORST habit a man can have is.....''",
      "expandedUrl" : "https://twitter.com/i/web/status/1692224771466072449"
    }
  },
  {
    "like" : {
      "tweetId" : "1691331499881041920",
      "fullText" : "@elonmusk Hey Elon, what about gang stalking by government officials?\n\nAsking for a friend.",
      "expandedUrl" : "https://twitter.com/i/web/status/1691331499881041920"
    }
  },
  {
    "like" : {
      "tweetId" : "1692310375872749625",
      "fullText" : "What do you want to make of it?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692310375872749625"
    }
  },
  {
    "like" : {
      "tweetId" : "1692271024417407405",
      "fullText" : "What #crypto project are you most bullish on? ❤️‍🔥📈",
      "expandedUrl" : "https://twitter.com/i/web/status/1692271024417407405"
    }
  },
  {
    "like" : {
      "tweetId" : "1692151792883396899",
      "fullText" : "How do you beat procrastination?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692151792883396899"
    }
  },
  {
    "like" : {
      "tweetId" : "1692273341623939302",
      "fullText" : "Which #Altcoin will change your life?? 🤯👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1692273341623939302"
    }
  },
  {
    "like" : {
      "tweetId" : "1692199888807764062",
      "fullText" : "Most underrated hack to grow up:\n\nStop taking things personally.",
      "expandedUrl" : "https://twitter.com/i/web/status/1692199888807764062"
    }
  },
  {
    "like" : {
      "tweetId" : "1692256480391541244",
      "fullText" : "🚀      🚀       🔥🔥        🚀🚀       🔥 \n🚀      🚀    🔥       🔥    🚀    🚀   🔥                                     \n🚀🚀🚀   🔥        🔥    🚀     🚀 🔥\n🚀      🚀    🔥       🔥    🚀    🚀   🔥\n🚀      🚀      🔥 🔥        🚀🚀       🔥🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1692256480391541244"
    }
  },
  {
    "like" : {
      "tweetId" : "1692225162723365129",
      "fullText" : "complaining is fun",
      "expandedUrl" : "https://twitter.com/i/web/status/1692225162723365129"
    }
  },
  {
    "like" : {
      "tweetId" : "1692238375942775262",
      "fullText" : "if you met someone with your exact same personality, would you get along?",
      "expandedUrl" : "https://twitter.com/i/web/status/1692238375942775262"
    }
  },
  {
    "like" : {
      "tweetId" : "1691856101594071218",
      "fullText" : "A personal brand without a business is a personal blog.",
      "expandedUrl" : "https://twitter.com/i/web/status/1691856101594071218"
    }
  },
  {
    "like" : {
      "tweetId" : "1691790248886632535",
      "expandedUrl" : "https://twitter.com/i/web/status/1691790248886632535"
    }
  },
  {
    "like" : {
      "tweetId" : "1691834605001715773",
      "fullText" : "What was the moment you realized you had what it takes to be an entrepreneur?",
      "expandedUrl" : "https://twitter.com/i/web/status/1691834605001715773"
    }
  },
  {
    "like" : {
      "tweetId" : "1691919778053800171",
      "fullText" : "What’s the next coin that will do this 😳🚀 https://t.co/iwEllOIZJj",
      "expandedUrl" : "https://twitter.com/i/web/status/1691919778053800171"
    }
  },
  {
    "like" : {
      "tweetId" : "1691770373774139458",
      "fullText" : "What would you say is the biggest thing that destroys people's dreams?",
      "expandedUrl" : "https://twitter.com/i/web/status/1691770373774139458"
    }
  },
  {
    "like" : {
      "tweetId" : "1691739643308343522",
      "fullText" : "Good morning!\n\nWhat inspired you to join 𝕏?",
      "expandedUrl" : "https://twitter.com/i/web/status/1691739643308343522"
    }
  },
  {
    "like" : {
      "tweetId" : "1691712399739355321",
      "fullText" : "Fill in the blank 👇\n\n__% of building a project is choosing the right font.",
      "expandedUrl" : "https://twitter.com/i/web/status/1691712399739355321"
    }
  },
  {
    "like" : {
      "tweetId" : "1691691661640778019",
      "fullText" : "I am whatever the opposite of an escape artist is",
      "expandedUrl" : "https://twitter.com/i/web/status/1691691661640778019"
    }
  },
  {
    "like" : {
      "tweetId" : "1691448910727000064",
      "fullText" : "What is your best advice for a person who’s looking to improve their life?",
      "expandedUrl" : "https://twitter.com/i/web/status/1691448910727000064"
    }
  },
  {
    "like" : {
      "tweetId" : "1691428340773621760",
      "fullText" : "Shill me your #100x Gems 💎 \n\n👇👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1691428340773621760"
    }
  },
  {
    "like" : {
      "tweetId" : "1691487413888339968",
      "fullText" : "If you were to #HODL only one token, what would it be? 😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1691487413888339968"
    }
  },
  {
    "like" : {
      "tweetId" : "1691318298435309568",
      "fullText" : "Which projects will go parabolic this week?",
      "expandedUrl" : "https://twitter.com/i/web/status/1691318298435309568"
    }
  },
  {
    "like" : {
      "tweetId" : "1691054943774355456",
      "fullText" : "Shill your favorite #Crypto projects! 🤩💎",
      "expandedUrl" : "https://twitter.com/i/web/status/1691054943774355456"
    }
  },
  {
    "like" : {
      "tweetId" : "1691068653888827392",
      "fullText" : "What’s your favorite crypto project?",
      "expandedUrl" : "https://twitter.com/i/web/status/1691068653888827392"
    }
  },
  {
    "like" : {
      "tweetId" : "1691003811144306689",
      "fullText" : "Good morning!\n\nTag a project you trust 100% for this week🤞🏻🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1691003811144306689"
    }
  },
  {
    "like" : {
      "tweetId" : "1690955667576635392",
      "fullText" : "Are you ok? If not you can always DM me 👍🏻",
      "expandedUrl" : "https://twitter.com/i/web/status/1690955667576635392"
    }
  },
  {
    "like" : {
      "tweetId" : "1690836886183378944",
      "fullText" : "Is there a 1000X meme coin out there right now? From current price.",
      "expandedUrl" : "https://twitter.com/i/web/status/1690836886183378944"
    }
  },
  {
    "like" : {
      "tweetId" : "1690765917213396992",
      "fullText" : "How satisfying is it when something wasn't working properly for too long and then you finally crack it. Such a relief 🥳",
      "expandedUrl" : "https://twitter.com/i/web/status/1690765917213396992"
    }
  },
  {
    "like" : {
      "tweetId" : "1690479785103724546",
      "fullText" : "Have you taken feedback to heart and got emotional about it? How do you deal with harsh sometimes what feels like attacking feedback? #buildinpublic",
      "expandedUrl" : "https://twitter.com/i/web/status/1690479785103724546"
    }
  },
  {
    "like" : {
      "tweetId" : "1690504446260719616",
      "fullText" : "Where do you find your comfort?",
      "expandedUrl" : "https://twitter.com/i/web/status/1690504446260719616"
    }
  },
  {
    "like" : {
      "tweetId" : "1690423342786912256",
      "fullText" : "What meme coins do you have that will 100X by Monday? 👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1690423342786912256"
    }
  },
  {
    "like" : {
      "tweetId" : "1690305879076450304",
      "fullText" : "Unpopular opinion:\n\nIf you depend on a social network to earn a living...\n\nThen I'm stressed and sad for you.",
      "expandedUrl" : "https://twitter.com/i/web/status/1690305879076450304"
    }
  },
  {
    "like" : {
      "tweetId" : "1651659742974976000",
      "fullText" : "https://t.co/fdGc5bvVDY",
      "expandedUrl" : "https://twitter.com/i/web/status/1651659742974976000"
    }
  },
  {
    "like" : {
      "tweetId" : "1661931818483068931",
      "fullText" : "Who likes to color? https://t.co/Y8ROMxO7Rq",
      "expandedUrl" : "https://twitter.com/i/web/status/1661931818483068931"
    }
  },
  {
    "like" : {
      "tweetId" : "1690099781144838146",
      "fullText" : "How to support your mates:\n\n• like\n• retweet \n• comment\n\nTotal cost ~ $0",
      "expandedUrl" : "https://twitter.com/i/web/status/1690099781144838146"
    }
  },
  {
    "like" : {
      "tweetId" : "1690108939197702144",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1690108939197702144"
    }
  },
  {
    "like" : {
      "tweetId" : "1689726774576381952",
      "fullText" : "She found perfect place to sleep https://t.co/i9MkHgWlJJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1689726774576381952"
    }
  },
  {
    "like" : {
      "tweetId" : "1689815133454057472",
      "fullText" : "Do you guys think we’ll ever see a $25,000 dollar #Bitcoin again???",
      "expandedUrl" : "https://twitter.com/i/web/status/1689815133454057472"
    }
  },
  {
    "like" : {
      "tweetId" : "1690093092832182272",
      "fullText" : "What is the most underrated meme coin right now?! 🤔🚀 go! 👇🏼",
      "expandedUrl" : "https://twitter.com/i/web/status/1690093092832182272"
    }
  },
  {
    "like" : {
      "tweetId" : "1689926515327152128",
      "fullText" : "What's one thing every developer wants?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689926515327152128"
    }
  },
  {
    "like" : {
      "tweetId" : "1689934697848012800",
      "fullText" : "https://t.co/vxMQiOsrfL",
      "expandedUrl" : "https://twitter.com/i/web/status/1689934697848012800"
    }
  },
  {
    "like" : {
      "tweetId" : "1690026529785356288",
      "fullText" : "Estne volumen in toga, an solum tibi libet me videre?",
      "expandedUrl" : "https://twitter.com/i/web/status/1690026529785356288"
    }
  },
  {
    "like" : {
      "tweetId" : "1689770348944760832",
      "fullText" : "#Crypto with the strongest community?? 👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1689770348944760832"
    }
  },
  {
    "like" : {
      "tweetId" : "1690019742482935808",
      "fullText" : "Which #memecoin should I look into today?",
      "expandedUrl" : "https://twitter.com/i/web/status/1690019742482935808"
    }
  },
  {
    "like" : {
      "tweetId" : "1689896928178229249",
      "fullText" : "Do you want to make money on X?\n\nComment below why people should follow you. What do you talk about? Bitcoin or something else?\n\nEngage and follow other people replying. Find connections. \n\nOne Team, One Dream. \nGrow Together! 💰",
      "expandedUrl" : "https://twitter.com/i/web/status/1689896928178229249"
    }
  },
  {
    "like" : {
      "tweetId" : "1689969927967694849",
      "fullText" : "AUGUST : which #crypto will trend the hardest ? 🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1689969927967694849"
    }
  },
  {
    "like" : {
      "tweetId" : "1689940908681175040",
      "fullText" : "@JackChardwood Sounds effective!",
      "expandedUrl" : "https://twitter.com/i/web/status/1689940908681175040"
    }
  },
  {
    "like" : {
      "tweetId" : "1689649487218913280",
      "fullText" : "Shill me ONE meme coin that will make millionaires before 1/1/24.\n\nGO! https://t.co/Uex72SF9mZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1689649487218913280"
    }
  },
  {
    "like" : {
      "tweetId" : "1689411694030893057",
      "fullText" : "What are your thoughts on being asked “explain what happens when you click a link in your browser” in a interview for a frontend software engineer position?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689411694030893057"
    }
  },
  {
    "like" : {
      "tweetId" : "1689679259315675136",
      "fullText" : "what’s the worst month of the year and why?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689679259315675136"
    }
  },
  {
    "like" : {
      "tweetId" : "1689438611911917569",
      "fullText" : "You pull up to pick your girl up for a date and you find her like this. \n\nWhat do you do? https://t.co/m3AYQaIUpX",
      "expandedUrl" : "https://twitter.com/i/web/status/1689438611911917569"
    }
  },
  {
    "like" : {
      "tweetId" : "1689416239913820160",
      "fullText" : "What meme tokens should I look into? \n\nDrop them in here.",
      "expandedUrl" : "https://twitter.com/i/web/status/1689416239913820160"
    }
  },
  {
    "like" : {
      "tweetId" : "1689697942762934272",
      "fullText" : "Going back to South East Asia next year.\n\nNeed to cut ~15lbs to get back in shape.\n\nI want to be able to still eat trash 25% of the time,\n\nWhat program do people recommend? https://t.co/0XsZE0Wl14",
      "expandedUrl" : "https://twitter.com/i/web/status/1689697942762934272"
    }
  },
  {
    "like" : {
      "tweetId" : "1689608784975626240",
      "fullText" : "______ Will Go Parabolic Next.",
      "expandedUrl" : "https://twitter.com/i/web/status/1689608784975626240"
    }
  },
  {
    "like" : {
      "tweetId" : "1689708692512428033",
      "fullText" : "Shill me your favourite #altcoin gem to do a #500X this month 📈💎",
      "expandedUrl" : "https://twitter.com/i/web/status/1689708692512428033"
    }
  },
  {
    "like" : {
      "tweetId" : "1689714481524297728",
      "fullText" : "Whats a #Crypto project that no one is talking about and is super undervalued!? 🤔👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1689714481524297728"
    }
  },
  {
    "like" : {
      "tweetId" : "1689610928658984961",
      "fullText" : "Which #Crypto should I promote?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689610928658984961"
    }
  },
  {
    "like" : {
      "tweetId" : "1689540904678531073",
      "fullText" : "@_ChrisWrites_ Bro wants that 100+ likes and juicy 40 Retweets",
      "expandedUrl" : "https://twitter.com/i/web/status/1689540904678531073"
    }
  },
  {
    "like" : {
      "tweetId" : "1689537508567031808",
      "fullText" : "Respect to everyone who builds something without knowing if it will work out.\n\nI believe in you.",
      "expandedUrl" : "https://twitter.com/i/web/status/1689537508567031808"
    }
  },
  {
    "like" : {
      "tweetId" : "1689698126620196865",
      "fullText" : "With #crypto, it is possible to change your life 🙋‍♂️",
      "expandedUrl" : "https://twitter.com/i/web/status/1689698126620196865"
    }
  },
  {
    "like" : {
      "tweetId" : "1689566300010389504",
      "fullText" : "JUST IN:\n\nFrance moves toward adopting cryptocurrency regulations",
      "expandedUrl" : "https://twitter.com/i/web/status/1689566300010389504"
    }
  },
  {
    "like" : {
      "tweetId" : "1689716903340621824",
      "fullText" : "Dogecoin is better money than USD",
      "expandedUrl" : "https://twitter.com/i/web/status/1689716903340621824"
    }
  },
  {
    "like" : {
      "tweetId" : "1689650032126160896",
      "fullText" : "What's a scientific mystery you believe could be solved in your lifetime?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689650032126160896"
    }
  },
  {
    "like" : {
      "tweetId" : "1689684983181451273",
      "fullText" : "If you’re into crypto, and need more support on your X account, reply below. Follow each other 🤝\n\nDinoLFG 🦖",
      "expandedUrl" : "https://twitter.com/i/web/status/1689684983181451273"
    }
  },
  {
    "like" : {
      "tweetId" : "1689709711229083649",
      "fullText" : "BREAKING:\n\nBig brands like Coca Cola and VISA are back advertising on X",
      "expandedUrl" : "https://twitter.com/i/web/status/1689709711229083649"
    }
  },
  {
    "like" : {
      "tweetId" : "1689574447664267264",
      "fullText" : "Which package manager do you like to use? NPM or Yarn?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689574447664267264"
    }
  },
  {
    "like" : {
      "tweetId" : "1689641924477825026",
      "fullText" : "Back pain is real. 😥\nDevs how do you deal with back pain?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689641924477825026"
    }
  },
  {
    "like" : {
      "tweetId" : "1689663172708302848",
      "fullText" : "What are your hobbies outside of coding? 🤔",
      "expandedUrl" : "https://twitter.com/i/web/status/1689663172708302848"
    }
  },
  {
    "like" : {
      "tweetId" : "1689622702938636289",
      "fullText" : "When you were a child, What did you want to be when you grew up?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689622702938636289"
    }
  },
  {
    "like" : {
      "tweetId" : "1689433338505822208",
      "fullText" : "Shill me the next #100x gem! 🔥\n\n💎👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1689433338505822208"
    }
  },
  {
    "like" : {
      "tweetId" : "1689468022849748993",
      "fullText" : "Equations that changed the world. https://t.co/4JHbI5D8hA",
      "expandedUrl" : "https://twitter.com/i/web/status/1689468022849748993"
    }
  },
  {
    "like" : {
      "tweetId" : "1689647007949017088",
      "fullText" : "Get rich then get off the grid https://t.co/t8ksetS5LC",
      "expandedUrl" : "https://twitter.com/i/web/status/1689647007949017088"
    }
  },
  {
    "like" : {
      "tweetId" : "1689329094452727808",
      "fullText" : "JUST IN:\n\nPayPal to offer interest reward for Bitcoin and crypto deposits",
      "expandedUrl" : "https://twitter.com/i/web/status/1689329094452727808"
    }
  },
  {
    "like" : {
      "tweetId" : "1689559911456210944",
      "fullText" : "Cool if X implement a feature where I can share my $5000 monthly ad revenue with loyal and active followers.",
      "expandedUrl" : "https://twitter.com/i/web/status/1689559911456210944"
    }
  },
  {
    "like" : {
      "tweetId" : "1689623115897188352",
      "fullText" : "The SEC now contends that XRP should be viewed as a security.\n\nYour opinion?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689623115897188352"
    }
  },
  {
    "like" : {
      "tweetId" : "1689579889794695168",
      "fullText" : "I have a confession...\n\nI don't:\n\n• Wake up at 5am\n• Take cold showers\n\nAm I canceled?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689579889794695168"
    }
  },
  {
    "like" : {
      "tweetId" : "1666687677440352257",
      "fullText" : "Today we have a cat meeting.😂😂😂 https://t.co/a4JcH5fGeQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1666687677440352257"
    }
  },
  {
    "like" : {
      "tweetId" : "1689424701192392704",
      "fullText" : "literally one of madonna’s best songs she’s ever made \n https://t.co/A0anZLeP0T",
      "expandedUrl" : "https://twitter.com/i/web/status/1689424701192392704"
    }
  },
  {
    "like" : {
      "tweetId" : "1689557013741842432",
      "fullText" : "I gym.\n\nI gym to create myself.\n\nI  gym to respect my body.\n\nI gym to skyrocket my energy.\n\nWhy do you gym? https://t.co/fvnIBAiTtI",
      "expandedUrl" : "https://twitter.com/i/web/status/1689557013741842432"
    }
  },
  {
    "like" : {
      "tweetId" : "1689369976518619143",
      "fullText" : "My intuition is telling me to travel to India.🇮🇳",
      "expandedUrl" : "https://twitter.com/i/web/status/1689369976518619143"
    }
  },
  {
    "like" : {
      "tweetId" : "1689592215541022720",
      "fullText" : "Active followers engaging on my posts deserve get a piece of my ad revenue from X. \n\nDo you agree?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689592215541022720"
    }
  },
  {
    "like" : {
      "tweetId" : "1689591456409722881",
      "fullText" : "@iamhuyha That's the year I was born.",
      "expandedUrl" : "https://twitter.com/i/web/status/1689591456409722881"
    }
  },
  {
    "like" : {
      "tweetId" : "1689607806603931648",
      "fullText" : "@themilosperisic Bro no wayyy, that's mine too haha",
      "expandedUrl" : "https://twitter.com/i/web/status/1689607806603931648"
    }
  },
  {
    "like" : {
      "tweetId" : "1689608963220992000",
      "fullText" : "@kristofer_gray most of them are Follow for follow\n\nI remember a guy following me 5 times and when i follow back he immediately unfollow me haha",
      "expandedUrl" : "https://twitter.com/i/web/status/1689608963220992000"
    }
  },
  {
    "like" : {
      "tweetId" : "1689599311288360960",
      "fullText" : "Buy and hodl, what’s are your gems?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689599311288360960"
    }
  },
  {
    "like" : {
      "tweetId" : "1689606268183339008",
      "fullText" : "#CryptoNews: In an effort to encourage the creation of millions of new decentralized apps, #Coinbase has released the mainnet for #Base, their #Ethereum layer-2 network. 🤩\nhttps://t.co/LsxGuXD0ev",
      "expandedUrl" : "https://twitter.com/i/web/status/1689606268183339008"
    }
  },
  {
    "like" : {
      "tweetId" : "1689607537853628416",
      "fullText" : "Which #altcoin are you NEVER selling?\n\n$ETH\n$KASTA\n$APE\n$SOL\n$XRP\n$XEC\n$TEL\n$VRA\n$CRO\n$BNB\n$VPAD\n$LINK\n$MEE\n$______?👇🏼",
      "expandedUrl" : "https://twitter.com/i/web/status/1689607537853628416"
    }
  },
  {
    "like" : {
      "tweetId" : "1689612055815573505",
      "fullText" : "Buy #ethereum before  announces it.",
      "expandedUrl" : "https://twitter.com/i/web/status/1689612055815573505"
    }
  },
  {
    "like" : {
      "tweetId" : "1689233675966124033",
      "fullText" : "Who do you think created Bitcoin ?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689233675966124033"
    }
  },
  {
    "like" : {
      "tweetId" : "1689139445197398016",
      "fullText" : "I used to struggle with social anxiety. A LOT.\n\nFuck - I was scared to ask you to pass me the salt. \n\nBut you know what helped?\n\nPutting myself out there.",
      "expandedUrl" : "https://twitter.com/i/web/status/1689139445197398016"
    }
  },
  {
    "like" : {
      "tweetId" : "1689255301382348801",
      "fullText" : "In ONE sentence — At what point should someone call themselves an expert?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689255301382348801"
    }
  },
  {
    "like" : {
      "tweetId" : "1689230138163003392",
      "expandedUrl" : "https://twitter.com/i/web/status/1689230138163003392"
    }
  },
  {
    "like" : {
      "tweetId" : "1689245370499407872",
      "fullText" : "GM! ☕",
      "expandedUrl" : "https://twitter.com/i/web/status/1689245370499407872"
    }
  },
  {
    "like" : {
      "tweetId" : "1688981696849260544",
      "fullText" : "What's an underrated coin I should be looking into❓",
      "expandedUrl" : "https://twitter.com/i/web/status/1688981696849260544"
    }
  },
  {
    "like" : {
      "tweetId" : "1689109245126451200",
      "fullText" : "Which coin is going to 10x next?",
      "expandedUrl" : "https://twitter.com/i/web/status/1689109245126451200"
    }
  },
  {
    "like" : {
      "tweetId" : "1688927813527838721",
      "fullText" : "In ONE word.\n\nHow do you deal with haters?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688927813527838721"
    }
  },
  {
    "like" : {
      "tweetId" : "1689003548485574656",
      "fullText" : "If I sent you $5000 dollars today \n\nWhich #cryptocurrency would you buy? 🤑",
      "expandedUrl" : "https://twitter.com/i/web/status/1689003548485574656"
    }
  },
  {
    "like" : {
      "tweetId" : "1688972988295614477",
      "fullText" : "Even if you don't engage with all my tweets, I just want you to know I appreciate your follow. ❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1688972988295614477"
    }
  },
  {
    "like" : {
      "tweetId" : "1688897908500754432",
      "fullText" : "Want more money?\n\nSpend more money.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688897908500754432"
    }
  },
  {
    "like" : {
      "tweetId" : "1688856083249414149",
      "fullText" : "Have you had to say no to a feature that was requested a lot by customers? #buildinpublic",
      "expandedUrl" : "https://twitter.com/i/web/status/1688856083249414149"
    }
  },
  {
    "like" : {
      "tweetId" : "1688970837469106193",
      "fullText" : "https://t.co/xDwlybEtQi",
      "expandedUrl" : "https://twitter.com/i/web/status/1688970837469106193"
    }
  },
  {
    "like" : {
      "tweetId" : "1688970735782400021",
      "fullText" : "Starship Super Heavy Booster https://t.co/3065srPugD",
      "expandedUrl" : "https://twitter.com/i/web/status/1688970735782400021"
    }
  },
  {
    "like" : {
      "tweetId" : "1688934200999612417",
      "fullText" : "Congrats to everyone who is still here 🫡\n\nYou are the chosen ones 🤝💎📈",
      "expandedUrl" : "https://twitter.com/i/web/status/1688934200999612417"
    }
  },
  {
    "like" : {
      "tweetId" : "1688876155456069633",
      "fullText" : "Sharks suggest me the best #Crypto project at the moment 👇👇🦈",
      "expandedUrl" : "https://twitter.com/i/web/status/1688876155456069633"
    }
  },
  {
    "like" : {
      "tweetId" : "1688816221171437569",
      "fullText" : "GM kings &amp; queens 👑 https://t.co/yTMl4ZtWZa",
      "expandedUrl" : "https://twitter.com/i/web/status/1688816221171437569"
    }
  },
  {
    "like" : {
      "tweetId" : "1688461639161356289",
      "fullText" : "Gm 😃 https://t.co/48DBIseiSs",
      "expandedUrl" : "https://twitter.com/i/web/status/1688461639161356289"
    }
  },
  {
    "like" : {
      "tweetId" : "1599769978143924225",
      "fullText" : "We made it 😂 https://t.co/L1XR2SssmX",
      "expandedUrl" : "https://twitter.com/i/web/status/1599769978143924225"
    }
  },
  {
    "like" : {
      "tweetId" : "1688474869732651008",
      "fullText" : "Frens.\n\nThe forgivenet is now up and running again.\n\nFor all yous trying to say sorry and failing, try again, and earn your 1 FRGVN.\n\nhttps://t.co/Iu5ef5haKj\n\nMy dev told me he'd had some issues but he's OK now. You just can't get the staff these days 🤣🤣",
      "expandedUrl" : "https://twitter.com/i/web/status/1688474869732651008"
    }
  },
  {
    "like" : {
      "tweetId" : "1688840799117606913",
      "fullText" : "Suggest me best #Crypto project at the moment 👇👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1688840799117606913"
    }
  },
  {
    "like" : {
      "tweetId" : "1688588228905836544",
      "fullText" : "@pawelkarniej My biggest and kinda only spending is AWS.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688588228905836544"
    }
  },
  {
    "like" : {
      "tweetId" : "1688667574786027520",
      "fullText" : "It's gonna be a wild week.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688667574786027520"
    }
  },
  {
    "like" : {
      "tweetId" : "1688566258667524097",
      "fullText" : "Things you'll never regret doing:\n\n• Going to the gym\n• Calling a loved one\n• Starting a business\n• Travelling the world \n• Helping someone for free\n• Learning a second language\n• Mastering marketing and sales\n• Eating a ribeye w/ red wine jus &amp; béarnaise\n\nAnything else?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688566258667524097"
    }
  },
  {
    "like" : {
      "tweetId" : "1688475070774304768",
      "fullText" : "How to fail in everything:\n\nCharge like a bull. Never reflect.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688475070774304768"
    }
  },
  {
    "like" : {
      "tweetId" : "1688602522355724288",
      "fullText" : "This is a joke FYI\n\nMy wife and I have common goals and work together with our combined finances",
      "expandedUrl" : "https://twitter.com/i/web/status/1688602522355724288"
    }
  },
  {
    "like" : {
      "tweetId" : "1688591494758776840",
      "fullText" : "Now that I am married I realize that all of my money is now her money and all of her money is also her money",
      "expandedUrl" : "https://twitter.com/i/web/status/1688591494758776840"
    }
  },
  {
    "like" : {
      "tweetId" : "1688614044104544256",
      "fullText" : "The sad look...\n\nKnowing your chipotle,\n\nGot delivered to the wrong house. https://t.co/7klAhBk97r",
      "expandedUrl" : "https://twitter.com/i/web/status/1688614044104544256"
    }
  },
  {
    "like" : {
      "tweetId" : "1688588311135240200",
      "fullText" : "The most unexpected #Crypto Token, in your opinion? 😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1688588311135240200"
    }
  },
  {
    "like" : {
      "tweetId" : "1688303894105841664",
      "fullText" : "I built a site.\n\nIt does not have dark mode.\n\nI am not going to spend time building dark mode.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688303894105841664"
    }
  },
  {
    "like" : {
      "tweetId" : "1688544962097426432",
      "fullText" : "Next BIG #Crypto project is _______? 🤔",
      "expandedUrl" : "https://twitter.com/i/web/status/1688544962097426432"
    }
  },
  {
    "like" : {
      "tweetId" : "1688246074773839873",
      "fullText" : "Apart from online.\n\nHow do you make money?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688246074773839873"
    }
  },
  {
    "like" : {
      "tweetId" : "1688041399193923584",
      "fullText" : "@Kara_Creates @elonmusk @libsoftiktok They were mad that you followed me, too.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688041399193923584"
    }
  },
  {
    "like" : {
      "tweetId" : "1688039979514011648",
      "fullText" : "@elonmusk @libsoftiktok The situation is slightly more complicated than the headline. But yes.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688039979514011648"
    }
  },
  {
    "like" : {
      "tweetId" : "1688039099330879488",
      "fullText" : "@libsoftiktok @Kara_Creates Kara, is that accurate?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688039099330879488"
    }
  },
  {
    "like" : {
      "tweetId" : "1688035428194988032",
      "fullText" : "@elonmusk .@Kara_Creates was fired for following Libs of TikTok https://t.co/HCxSqUmYKl",
      "expandedUrl" : "https://twitter.com/i/web/status/1688035428194988032"
    }
  },
  {
    "like" : {
      "tweetId" : "1688460013285593088",
      "fullText" : "It's Monday.\n\nLet's really go for it.\n\nWhat are you working on this week?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688460013285593088"
    }
  },
  {
    "like" : {
      "tweetId" : "1688205420660416512",
      "fullText" : "Am I the only one who doesn't want to call twitter 'X'?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688205420660416512"
    }
  },
  {
    "like" : {
      "tweetId" : "1688022163574439937",
      "fullText" : "If you were unfairly treated by your employer due to posting or liking something on this platform, we will fund your legal bill.\n\nNo limit. \n\nPlease let us know.",
      "expandedUrl" : "https://twitter.com/i/web/status/1688022163574439937"
    }
  },
  {
    "like" : {
      "tweetId" : "1688231973683142656",
      "fullText" : "I just want to put it out there, that if you're feeling low or alone, just @ me and know I'll reply, always got time to listen and help others 👋",
      "expandedUrl" : "https://twitter.com/i/web/status/1688231973683142656"
    }
  },
  {
    "like" : {
      "tweetId" : "1688170066188120064",
      "fullText" : "When was the last time you got a hug?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688170066188120064"
    }
  },
  {
    "like" : {
      "tweetId" : "1688190019746385920",
      "fullText" : "Twitter is a joke\n\nDating coaches with no dating experience\n\n17 year old life coaches\n\n50k in depth financial advisors\n\nWho’d I miss?",
      "expandedUrl" : "https://twitter.com/i/web/status/1688190019746385920"
    }
  },
  {
    "like" : {
      "tweetId" : "1687940038339031040",
      "fullText" : "Could you retire on $1 million?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687940038339031040"
    }
  },
  {
    "like" : {
      "tweetId" : "1687923778561392642",
      "fullText" : "Don’t do it to prove them wrong.\n\nDo it for you.\n\nYou already know they are wrong.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687923778561392642"
    }
  },
  {
    "like" : {
      "tweetId" : "1687687101670731777",
      "fullText" : "I tried so hard\n\nand got so far\n\nbut in the end\n\ngit push --force origin master",
      "expandedUrl" : "https://twitter.com/i/web/status/1687687101670731777"
    }
  },
  {
    "like" : {
      "tweetId" : "1687707927556325376",
      "fullText" : "Ever blocked by your favourite person...?🙂",
      "expandedUrl" : "https://twitter.com/i/web/status/1687707927556325376"
    }
  },
  {
    "like" : {
      "tweetId" : "1686809160732524549",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1686809160732524549"
    }
  },
  {
    "like" : {
      "tweetId" : "1687630539275034626",
      "fullText" : "Should transgender athletes be banned from competing in all women’s sports? https://t.co/8JAsmlayBx",
      "expandedUrl" : "https://twitter.com/i/web/status/1687630539275034626"
    }
  },
  {
    "like" : {
      "tweetId" : "1687736013899079680",
      "fullText" : "I'll never understand why people choose to be easily offended.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687736013899079680"
    }
  },
  {
    "like" : {
      "tweetId" : "1687796013073940480",
      "fullText" : "Very few talk about God here.\n\nOk...\n\nGod is good.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687796013073940480"
    }
  },
  {
    "like" : {
      "tweetId" : "1687790176700096512",
      "fullText" : "“If you build it, they will come.”\n\nWhat’s your take?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687790176700096512"
    }
  },
  {
    "like" : {
      "tweetId" : "1687765392524222464",
      "fullText" : "Tag a project you trust 100% 🫡⚖️",
      "expandedUrl" : "https://twitter.com/i/web/status/1687765392524222464"
    }
  },
  {
    "like" : {
      "tweetId" : "1687778213668302848",
      "fullText" : "@JackChardwood Hah. Classic.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687778213668302848"
    }
  },
  {
    "like" : {
      "tweetId" : "1687726793149575168",
      "fullText" : "Would you trade everything you learned this year for $100,000?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687726793149575168"
    }
  },
  {
    "like" : {
      "tweetId" : "1687704993606823936",
      "fullText" : "Which #token should we accumulate today ?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687704993606823936"
    }
  },
  {
    "like" : {
      "tweetId" : "1687679245424726016",
      "fullText" : "@JackChardwood 🤝🏻",
      "expandedUrl" : "https://twitter.com/i/web/status/1687679245424726016"
    }
  },
  {
    "like" : {
      "tweetId" : "1687246355511869447",
      "fullText" : "Almost every single job posting I come across wants proficiency in SQL. Guess I have something new to learn! \n\nHow long did it take you to learn SQL? 👩🏼‍💻",
      "expandedUrl" : "https://twitter.com/i/web/status/1687246355511869447"
    }
  },
  {
    "like" : {
      "tweetId" : "1687515239120879616",
      "fullText" : "Oh, you tweet about things other than business?\n\nFollowed.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687515239120879616"
    }
  },
  {
    "like" : {
      "tweetId" : "1687561360111190018",
      "fullText" : "Tether is now the 11th largest #bitcoin holder in the 🌎. https://t.co/kqJGSpNCVE",
      "expandedUrl" : "https://twitter.com/i/web/status/1687561360111190018"
    }
  },
  {
    "like" : {
      "tweetId" : "1687352930351874048",
      "fullText" : "My friends aren't afraid to call me on my shit.\n\nAnd that's why I love them.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687352930351874048"
    }
  },
  {
    "like" : {
      "tweetId" : "1687299664536801280",
      "fullText" : "Unknown Bitcoin believers have hung a blockchain on the famous Wall Street bull. 🏙 #inspiring https://t.co/ciLIvlu6q5",
      "expandedUrl" : "https://twitter.com/i/web/status/1687299664536801280"
    }
  },
  {
    "like" : {
      "tweetId" : "1687531777286369280",
      "fullText" : "@elonmusk @Starbucks https://t.co/FYaX1Mb9TH",
      "expandedUrl" : "https://twitter.com/i/web/status/1687531777286369280"
    }
  },
  {
    "like" : {
      "tweetId" : "1687532963867590670",
      "fullText" : "@elonmusk @Starbucks Yep love Starbucks ever since they gave me my coffee in this cup https://t.co/mSUmcIablO",
      "expandedUrl" : "https://twitter.com/i/web/status/1687532963867590670"
    }
  },
  {
    "like" : {
      "tweetId" : "1687531487141453824",
      "fullText" : "I know some people hate on them, but I have to credit the whole @Starbucks team with reliably serving millions of coffees &amp; snacks every day around the world",
      "expandedUrl" : "https://twitter.com/i/web/status/1687531487141453824"
    }
  },
  {
    "like" : {
      "tweetId" : "1687072785883860992",
      "fullText" : "@elonmusk Are you going to decentralize Twitter (sorry X) I wonder?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687072785883860992"
    }
  },
  {
    "like" : {
      "tweetId" : "1687347764689084416",
      "fullText" : "It will be absolutely frightening.\n\nVulnerability needed is high.  \n\nMetrics on it alone is scary. \n\nBut there peace in it too. \n\nTo share your past self. \n\nShow who you are. \n\nTell your story. \n\nMake friends. \n\nBe the brand.\n\nBut to also.\n\nBe you.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687347764689084416"
    }
  },
  {
    "like" : {
      "tweetId" : "1687446033310113793",
      "fullText" : "Cryptocurrency is not a hobby for me. It's a lifestyle.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687446033310113793"
    }
  },
  {
    "like" : {
      "tweetId" : "1687447039960121344",
      "fullText" : "Oh you like crypto? \n\nName your top coin.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687447039960121344"
    }
  },
  {
    "like" : {
      "tweetId" : "1380898299184566289",
      "fullText" : "You're not lucky.\n\nYou did your research.\nYou stopped wasting money.\nYou learned to invest.\nYou took risky decisions.\nYou bought crypto assets.\nYou endured many insults.\nYou held through the bear market.\nYou held through the fakeouts.\nYou're now making gains.\n\nYou're not lucky.",
      "expandedUrl" : "https://twitter.com/i/web/status/1380898299184566289"
    }
  },
  {
    "like" : {
      "tweetId" : "1687113283227308032",
      "fullText" : "Did the algorithm just change again?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687113283227308032"
    }
  },
  {
    "like" : {
      "tweetId" : "1687342867444858880",
      "fullText" : "@JackChardwood that's a really good way to feel if someone is lying yes",
      "expandedUrl" : "https://twitter.com/i/web/status/1687342867444858880"
    }
  },
  {
    "like" : {
      "tweetId" : "1687372232232947713",
      "fullText" : "Physics is a Ψ op",
      "expandedUrl" : "https://twitter.com/i/web/status/1687372232232947713"
    }
  },
  {
    "like" : {
      "tweetId" : "1687132055627280385",
      "fullText" : "I used to want Lamborghinis.\n\nNow I want this: https://t.co/zlrGfjblIZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1687132055627280385"
    }
  },
  {
    "like" : {
      "tweetId" : "1687123155821707264",
      "fullText" : "Vitalik Buterin takes you out to lunch.\n\nDo you accept?\n\n$ETH https://t.co/bqymJVoSCC",
      "expandedUrl" : "https://twitter.com/i/web/status/1687123155821707264"
    }
  },
  {
    "like" : {
      "tweetId" : "1686980215514284032",
      "fullText" : "People betray themselves in the delighted comforts of their lies.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686980215514284032"
    }
  },
  {
    "like" : {
      "tweetId" : "1687168338114265089",
      "fullText" : "Pornhub has blocked all users in Arkansas from the site after the state’s new age verification law went into effect.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687168338114265089"
    }
  },
  {
    "like" : {
      "tweetId" : "1686992548554801152",
      "fullText" : "Today is my birthday.\n\nThis will by my best year every.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686992548554801152"
    }
  },
  {
    "like" : {
      "tweetId" : "1687165486327566336",
      "fullText" : "I get more laughs from this platform than everything else combined and I hope you do too.\n\nThanks for posting such great content!",
      "expandedUrl" : "https://twitter.com/i/web/status/1687165486327566336"
    }
  },
  {
    "like" : {
      "tweetId" : "1687122831685894144",
      "fullText" : "I am looking forward to the replies on this one.\n\n🤣 https://t.co/5dFLaVVc9P",
      "expandedUrl" : "https://twitter.com/i/web/status/1687122831685894144"
    }
  },
  {
    "like" : {
      "tweetId" : "1687078456591368193",
      "fullText" : "I turn 34 today.\n\nLeos roar with me.",
      "expandedUrl" : "https://twitter.com/i/web/status/1687078456591368193"
    }
  },
  {
    "like" : {
      "tweetId" : "1687070819728637952",
      "fullText" : "Is confidence something you're born with or something you develop over time?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687070819728637952"
    }
  },
  {
    "like" : {
      "tweetId" : "1686919820896530433",
      "fullText" : "Which #altcoin will 💯x this week ?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686919820896530433"
    }
  },
  {
    "like" : {
      "tweetId" : "1687044135004332033",
      "fullText" : "How can you tell if a person is lying?",
      "expandedUrl" : "https://twitter.com/i/web/status/1687044135004332033"
    }
  },
  {
    "like" : {
      "tweetId" : "1687051430752931840",
      "fullText" : "@ethanklingler_ for me its when I am trying to sleep\n\ndrives me sooo mad 🤣",
      "expandedUrl" : "https://twitter.com/i/web/status/1687051430752931840"
    }
  },
  {
    "like" : {
      "tweetId" : "1686845172938575872",
      "fullText" : "Aging is an extraordinary process where you become the person you always should have been.\n– David Bowie\n\nI was born 41 years ago, a Tuesday’s child! I’m thankful for everyone I’ve crossed paths with. Peace &amp; love 💗✨ https://t.co/WIgg6cFiyu",
      "expandedUrl" : "https://twitter.com/i/web/status/1686845172938575872"
    }
  },
  {
    "like" : {
      "tweetId" : "1687101009682731008",
      "fullText" : "Shill me your 50X project\n\nGo! 👇🏼",
      "expandedUrl" : "https://twitter.com/i/web/status/1687101009682731008"
    }
  },
  {
    "like" : {
      "tweetId" : "1686928117112225792",
      "fullText" : "@elonmusk https://t.co/bjsYsjTVpp",
      "expandedUrl" : "https://twitter.com/i/web/status/1686928117112225792"
    }
  },
  {
    "like" : {
      "tweetId" : "1686934863524634624",
      "fullText" : "@elonmusk Me once twitter comes back https://t.co/FegKx9bo5I",
      "expandedUrl" : "https://twitter.com/i/web/status/1686934863524634624"
    }
  },
  {
    "like" : {
      "tweetId" : "1686925930806022146",
      "fullText" : "And a massive amount of infrastructure software &amp; hardware improvements!\n\nWe will do a post on that too. The list of technical achievements by the X team is incredible. https://t.co/Uft2jaCvrg",
      "expandedUrl" : "https://twitter.com/i/web/status/1686925930806022146"
    }
  },
  {
    "like" : {
      "tweetId" : "1686814125085655040",
      "fullText" : "My mission?\n\nTo achieve time, location, and financial freedom.\n\nWhat's yours?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686814125085655040"
    }
  },
  {
    "like" : {
      "tweetId" : "1686675080795893760",
      "fullText" : "How often do you read book?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686675080795893760"
    }
  },
  {
    "like" : {
      "tweetId" : "1686681243881218048",
      "fullText" : "What are the best ways to maintain mental health?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686681243881218048"
    }
  },
  {
    "like" : {
      "tweetId" : "1686909508969177088",
      "fullText" : "GM everyone 👋 🚀",
      "expandedUrl" : "https://twitter.com/i/web/status/1686909508969177088"
    }
  },
  {
    "like" : {
      "tweetId" : "1686809153375707136",
      "fullText" : "Don't be afraid bruv.\n\nIt's easy once you start.\n\nA simple action you'll never regret...\n\nSay sorry to someone. \n\nUse the forgivenet. \n\nReceive crypto in return.\n\nhttps://t.co/Iu5ef5haKj",
      "expandedUrl" : "https://twitter.com/i/web/status/1686809153375707136"
    }
  },
  {
    "like" : {
      "tweetId" : "1686884594061135873",
      "fullText" : "Just wondering, are the people following me mostly from the UK? Let me know what country you're from 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1686884594061135873"
    }
  },
  {
    "like" : {
      "tweetId" : "1686746874093486081",
      "fullText" : "Underrated growth hack:\n\nRoast your friends in the comments.\n\n(No one needs value all the time)\n\n• Have fun.\n• 187% disagree.\n• Answer in GIFs.\n• Don't be the smart kid.\n\nEvery reply boosts the algo –\n\nyou're showing love.",
      "expandedUrl" : "https://twitter.com/i/web/status/1686746874093486081"
    }
  },
  {
    "like" : {
      "tweetId" : "1686723456476327936",
      "fullText" : "What’s a personal passion or hobby of yours?\n\nMine’s chess and rapping.\n\nBeen playing chess since I was a kid.\n\nJust started rapping recently.\n\nWhat’s yours?",
      "expandedUrl" : "https://twitter.com/i/web/status/1686723456476327936"
    }
  }
]