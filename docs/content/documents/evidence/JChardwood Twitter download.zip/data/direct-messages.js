window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "262545395-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "262545395",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Did you look it up and/or ask someone? I think your mum rang me the other day..",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1686779524946505732",
            "createdAt" : "2023-08-02T16:42:32.298Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Okay great, So have you tried doing daily trades and making simple earnings rather  much waiting much more in months. You can do that daily with ease",
            "mediaUrls" : [ ],
            "senderId" : "262545395",
            "id" : "1686734180955070470",
            "createdAt" : "2023-08-02T13:42:21.459Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "262545395",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "whattadbout you?",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1686712007024672772",
            "createdAt" : "2023-08-02T12:14:14.775Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "262545395",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yeah, good, i'm playing the long game",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1686711986887786501",
            "createdAt" : "2023-08-02T12:14:09.964Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How are you doing and how are your trades going so far",
            "mediaUrls" : [ ],
            "senderId" : "262545395",
            "id" : "1686710738436386820",
            "createdAt" : "2023-08-02T12:09:12.306Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "262545395",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey Whassup?",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1686710516935225349",
            "createdAt" : "2023-08-02T12:08:19.494Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello",
            "mediaUrls" : [ ],
            "senderId" : "262545395",
            "id" : "1686681223903531014",
            "createdAt" : "2023-08-02T10:11:55.492Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "511538112-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How’s the crypto market going with you lately?",
            "mediaUrls" : [ ],
            "senderId" : "511538112",
            "id" : "1691175376335106404",
            "createdAt" : "2023-08-14T19:50:04.925Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "511538112",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🙏",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1691161104125198615",
            "createdAt" : "2023-08-14T18:53:22.163Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey there👋🏻\nThanks for following up with my content; you’re one of my viewers, and I genuinely appreciate",
            "mediaUrls" : [ ],
            "senderId" : "511538112",
            "id" : "1691137038563553410",
            "createdAt" : "2023-08-14T17:17:44.514Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1568722551580278786-1686833942505152512",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Would you allow me to watch a screenshot by joining my channel, my dear?",
            "mediaUrls" : [ ],
            "senderId" : "1686833942505152512",
            "id" : "1694355492384981420",
            "createdAt" : "2023-08-23T14:26:43.684Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1686833942505152512",
            "reactions" : [
              {
                "senderId" : "1686833942505152512",
                "reactionKey" : "like",
                "eventId" : "1694355476706680832",
                "createdAt" : "2023-08-23T14:26:39.918Z"
              }
            ],
            "urls" : [ ],
            "text" : "👍",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1694326950951522720",
            "createdAt" : "2023-08-23T12:33:18.865Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Please join my dear",
            "mediaUrls" : [ ],
            "senderId" : "1686833942505152512",
            "id" : "1693561634541715799",
            "createdAt" : "2023-08-21T09:52:13.215Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/LmBl0Fz14I",
                "expanded" : "https://t.me/+YQxmzR7g7VcxMDQ0",
                "display" : "t.me/+YQxmzR7g7VcxM…"
              }
            ],
            "text" : "Hello\nIf you are intrested in crypto pumps and accurate trading signals, join our big telegram channel to know the name of the next coin which will be pumped .\nWe have more than 1 million persons in our channels who participate in our pumps.\n\nTG channel username: @pumps20\n\nTG direct link: \nhttps://t.co/LmBl0Fz14I\nthank you alot",
            "mediaUrls" : [ ],
            "senderId" : "1686833942505152512",
            "id" : "1693561631903470006",
            "createdAt" : "2023-08-21T09:52:12.618Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1568722551580278786-1689895536927580160",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/4xLANpShbx",
                "expanded" : "https://t.me/+BVEH1IM1dGIzOWZk",
                "display" : "t.me/+BVEH1IM1dGIzO…"
              }
            ],
            "text" : "Hello\nIf you are intrested in crypto pumps and accurate trading signals, join our big telegram channel to know the name of the next coin which will be pumped .\nWe have more than 1 million persons in our channels \n\nTG channel username: @pumps20\nhttps://t.co/4xLANpShbx\nDid you join?",
            "mediaUrls" : [ ],
            "senderId" : "1689895536927580160",
            "id" : "1693036127123382368",
            "createdAt" : "2023-08-19T23:04:02.505Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "3021962360-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "any time you like bro",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1690831448494735819",
            "createdAt" : "2023-08-13T21:03:26.137Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "... why not just talk to me normally instead of all this madness? It'll be far easier ...  i'm tremendous fun you know :D",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1687868699636547588",
            "createdAt" : "2023-08-05T16:50:31.765Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "your mum looks cute and cuddly and I want to giver her a hug",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1687860208347873284",
            "createdAt" : "2023-08-05T16:16:47.281Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "anyway, whoever it is, how can i help you friend?",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1687854126355316740",
            "createdAt" : "2023-08-05T15:52:37.225Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "or Demiurge C ?",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1687853496022802436",
            "createdAt" : "2023-08-05T15:50:06.945Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "or perhaps you are a Frenchman with a very big nose?",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1687850460340699140",
            "createdAt" : "2023-08-05T15:38:03.183Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "was it your mum, she looks like you",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1687747614907772932",
            "createdAt" : "2023-08-05T08:49:22.911Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3021962360",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "you're back",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1687741949665554436",
            "createdAt" : "2023-08-05T08:26:52.212Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "3289324877-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How are you today?",
            "mediaUrls" : [ ],
            "senderId" : "3289324877",
            "id" : "1688125784894865412",
            "createdAt" : "2023-08-06T09:52:05.671Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello there!",
            "mediaUrls" : [ ],
            "senderId" : "3289324877",
            "id" : "1688125768516169732",
            "createdAt" : "2023-08-06T09:52:01.760Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "966229175882473472-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "966229175882473472",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Gracias, se ha arreglado con bastante rapidez &lt;3",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1656924187758407684",
            "createdAt" : "2023-05-12T07:28:05.218Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hola. En primer lugar, muchas gracias por avisarnos de la incidencia. Necesitamos que, por favor, nos envíes toda la información y detalles posibles sobre la avería para poder solucionarla de la mejor forma posible. Indícanos el lugar afectado y el tipo de incidencia.\n\nPara tramitar el aviso, indícanos los siguientes datos: número del contrato, nombre completo del titular del suministro, DNI y dirección. Además, también necesitamos que nos facilites tu nombre, relación con el contrato y un número de teléfono en caso de que nuestros compañeros del servicio técnico necesiten contactar contigo. Muchas gracias.\nEF",
            "mediaUrls" : [ ],
            "senderId" : "966229175882473472",
            "id" : "1656205751117922309",
            "createdAt" : "2023-05-10T07:53:16.579Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "966229175882473472",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hola Aqualia no hay agua en mi edificio durante una hora. Estoy en Carrer Furs 15, Bloque 1 03700 Denia Alicante",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1655989414378471454",
            "createdAt" : "2023-05-09T17:33:37.931Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1423937973201027078-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1423937973201027078",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hello",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1685648605107867652",
            "createdAt" : "2023-07-30T13:48:39.990Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hello",
            "mediaUrls" : [ ],
            "senderId" : "1423937973201027078",
            "id" : "1685648487814217732",
            "createdAt" : "2023-07-30T13:48:12.083Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1503499710111555584-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello, thank you for your attention, how are you today?",
            "mediaUrls" : [ ],
            "senderId" : "1503499710111555584",
            "id" : "1689621542270124036",
            "createdAt" : "2023-08-10T12:55:42.061Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1568722551580278786-1568722551580278786",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hullo",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1646866999685836805",
            "createdAt" : "2023-04-14T13:24:24.722Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1568722551580278786-1595920067157528578",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I need you to make your complain more explanatory..",
            "mediaUrls" : [ ],
            "senderId" : "1595920067157528578",
            "id" : "1602301339069022212",
            "createdAt" : "2022-12-12T13:56:23.239Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello",
            "mediaUrls" : [ ],
            "senderId" : "1595920067157528578",
            "id" : "1602300349339017220",
            "createdAt" : "2022-12-12T13:52:27.267Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1595920067157528578",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "0x75009043786FB3cD1C1737C8d65e87D50E58AC8C",
            "mediaUrls" : [ ],
            "senderId" : "1568722551580278786",
            "id" : "1602294989463207947",
            "createdAt" : "2022-12-12T13:31:09.375Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1568722551580278786-1672739098015023104",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1568722551580278786",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/HqL2uG5u3w",
                "expanded" : "https://t.me/+feGemMbpOIRjNGNk",
                "display" : "t.me/+feGemMbpOIRjN…"
              }
            ],
            "text" : "Hello❤️\nIf you are intrested in crypto pumps and accurate trading signals, join our big telegram channel to know the name of the next coin which will be pumped .\nWe have more than 1 million persons in our channels who participate in our pumps.\nhttps://t.co/HqL2uG5u3w\n🚀📈\n\nTG channel username: @pumps20",
            "mediaUrls" : [ ],
            "senderId" : "1672739098015023104",
            "id" : "1686751267228418053",
            "createdAt" : "2023-08-02T14:50:15.157Z"
          }
        }
      ]
    }
  }
]