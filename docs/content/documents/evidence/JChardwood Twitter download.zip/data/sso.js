window.YTD.sso.part0 = [
  {
    "singleSignOnMetaValues" : {
      "ssoId" : "100886210545332082978",
      "ssoEmail" : "jackchardwood@gmail.com",
      "associationMethodType" : "Signup",
      "createdAt" : "2022-09-10T22:06:31.932Z"
    }
  }
]