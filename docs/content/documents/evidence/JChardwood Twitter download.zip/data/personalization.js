window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "English (United Kingdom)",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "#HappyFriday",
            "isDisabled" : false
          },
          {
            "name" : "#HappyMonday",
            "isDisabled" : false
          },
          {
            "name" : "$AAPL",
            "isDisabled" : false
          },
          {
            "name" : "$AMD",
            "isDisabled" : false
          },
          {
            "name" : "$AMZN",
            "isDisabled" : false
          },
          {
            "name" : "$BABA",
            "isDisabled" : false
          },
          {
            "name" : "$BNB",
            "isDisabled" : false
          },
          {
            "name" : "$BTC",
            "isDisabled" : false
          },
          {
            "name" : "$BYND",
            "isDisabled" : false
          },
          {
            "name" : "$DOGE",
            "isDisabled" : false
          },
          {
            "name" : "$ETH",
            "isDisabled" : false
          },
          {
            "name" : "$FB",
            "isDisabled" : false
          },
          {
            "name" : "$GOOG",
            "isDisabled" : false
          },
          {
            "name" : "$GOOGL",
            "isDisabled" : false
          },
          {
            "name" : "$JPM",
            "isDisabled" : false
          },
          {
            "name" : "$MSFT",
            "isDisabled" : false
          },
          {
            "name" : "$NFLX",
            "isDisabled" : false
          },
          {
            "name" : "$NIO",
            "isDisabled" : false
          },
          {
            "name" : "$NVDA",
            "isDisabled" : false
          },
          {
            "name" : "$PLTR",
            "isDisabled" : false
          },
          {
            "name" : "$PTON",
            "isDisabled" : false
          },
          {
            "name" : "$PYPL",
            "isDisabled" : false
          },
          {
            "name" : "$QQQ",
            "isDisabled" : false
          },
          {
            "name" : "$ROKU",
            "isDisabled" : false
          },
          {
            "name" : "$SHOP",
            "isDisabled" : false
          },
          {
            "name" : "$SPCE",
            "isDisabled" : false
          },
          {
            "name" : "$SQ",
            "isDisabled" : false
          },
          {
            "name" : "$TSLA",
            "isDisabled" : false
          },
          {
            "name" : "$XRP",
            "isDisabled" : false
          },
          {
            "name" : "$ZM",
            "isDisabled" : false
          },
          {
            "name" : "Action games",
            "isDisabled" : false
          },
          {
            "name" : "Ada cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Al-Nassr FC",
            "isDisabled" : false
          },
          {
            "name" : "Alphabet Inc.",
            "isDisabled" : false
          },
          {
            "name" : "Amazon",
            "isDisabled" : false
          },
          {
            "name" : "Android",
            "isDisabled" : false
          },
          {
            "name" : "Animation & comics",
            "isDisabled" : false
          },
          {
            "name" : "Anime",
            "isDisabled" : false
          },
          {
            "name" : "Aposto!",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Apple Mac",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Asian cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Automobile Brands",
            "isDisabled" : false
          },
          {
            "name" : "Automotive",
            "isDisabled" : false
          },
          {
            "name" : "Avalanche cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Baby Dogecoin",
            "isDisabled" : false
          },
          {
            "name" : "Backstage",
            "isDisabled" : false
          },
          {
            "name" : "Ballroom dance",
            "isDisabled" : false
          },
          {
            "name" : "Banking",
            "isDisabled" : false
          },
          {
            "name" : "Barbie (2023)",
            "isDisabled" : false
          },
          {
            "name" : "Beauty",
            "isDisabled" : false
          },
          {
            "name" : "Beauty industry",
            "isDisabled" : false
          },
          {
            "name" : "Beyoncé",
            "isDisabled" : false
          },
          {
            "name" : "Bill Gates",
            "isDisabled" : false
          },
          {
            "name" : "Binance",
            "isDisabled" : false
          },
          {
            "name" : "Binance Coin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Bitcoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "BlackRock",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Brawl Stars",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "CNN",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "California",
            "isDisabled" : false
          },
          {
            "name" : "Celebrities",
            "isDisabled" : false
          },
          {
            "name" : "Central Banks",
            "isDisabled" : false
          },
          {
            "name" : "Chainlink cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Changpeng Zhao",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "China political issues",
            "isDisabled" : false
          },
          {
            "name" : "China politics",
            "isDisabled" : false
          },
          {
            "name" : "Classic rock",
            "isDisabled" : false
          },
          {
            "name" : "Climate change",
            "isDisabled" : false
          },
          {
            "name" : "Coca Cola - Diet Coke",
            "isDisabled" : false
          },
          {
            "name" : "Coca-Cola",
            "isDisabled" : false
          },
          {
            "name" : "Coinbase",
            "isDisabled" : false
          },
          {
            "name" : "Combat sports",
            "isDisabled" : false
          },
          {
            "name" : "Comedy TV",
            "isDisabled" : false
          },
          {
            "name" : "Comedy films",
            "isDisabled" : false
          },
          {
            "name" : "Competition shows",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Console gaming",
            "isDisabled" : false
          },
          {
            "name" : "Credit Cards",
            "isDisabled" : false
          },
          {
            "name" : "Cristiano Ronaldo",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocoins",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrency exchanges",
            "isDisabled" : false
          },
          {
            "name" : "Cryptotokens",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "Dance",
            "isDisabled" : false
          },
          {
            "name" : "Daniel Radcliffe",
            "isDisabled" : false
          },
          {
            "name" : "David Bowie",
            "isDisabled" : false
          },
          {
            "name" : "Denzel Washington",
            "isDisabled" : false
          },
          {
            "name" : "Digital asset industry",
            "isDisabled" : false
          },
          {
            "name" : "Digital assets & cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Digital creators",
            "isDisabled" : false
          },
          {
            "name" : "Dogecoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Dragon Ball",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "ELF",
            "isDisabled" : false
          },
          {
            "name" : "Elden Ring",
            "isDisabled" : false
          },
          {
            "name" : "Electric vehicles",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment events",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Europe travel",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Everyday Astronaut",
            "isDisabled" : false
          },
          {
            "name" : "Family films",
            "isDisabled" : false
          },
          {
            "name" : "Fantasy games",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : false
          },
          {
            "name" : "Fashion & beauty",
            "isDisabled" : false
          },
          {
            "name" : "Federal Reserve",
            "isDisabled" : false
          },
          {
            "name" : "Film festivals",
            "isDisabled" : false
          },
          {
            "name" : "Financial Literacy",
            "isDisabled" : false
          },
          {
            "name" : "Financial services",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "Food Blogs",
            "isDisabled" : false
          },
          {
            "name" : "For All Mankind",
            "isDisabled" : false
          },
          {
            "name" : "Fox Sports",
            "isDisabled" : false
          },
          {
            "name" : "Franklin Templeton",
            "isDisabled" : false
          },
          {
            "name" : "Gacha games",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "George Clooney",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Grimes",
            "isDisabled" : false
          },
          {
            "name" : "Hip hop",
            "isDisabled" : false
          },
          {
            "name" : "House Prices",
            "isDisabled" : false
          },
          {
            "name" : "India travel",
            "isDisabled" : false
          },
          {
            "name" : "Industries",
            "isDisabled" : false
          },
          {
            "name" : "Inflation",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "International Space Station",
            "isDisabled" : false
          },
          {
            "name" : "Investing",
            "isDisabled" : false
          },
          {
            "name" : "J.P. Morgan",
            "isDisabled" : false
          },
          {
            "name" : "JPMorgan Chase",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "Katy Perry",
            "isDisabled" : false
          },
          {
            "name" : "Lex Fridman",
            "isDisabled" : false
          },
          {
            "name" : "Lifehacks",
            "isDisabled" : false
          },
          {
            "name" : "Linux",
            "isDisabled" : false
          },
          {
            "name" : "Litecoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Loans",
            "isDisabled" : false
          },
          {
            "name" : "Lourdes Sánchez",
            "isDisabled" : false
          },
          {
            "name" : "Lunch",
            "isDisabled" : false
          },
          {
            "name" : "Madonna",
            "isDisabled" : false
          },
          {
            "name" : "Mark Zuckerberg",
            "isDisabled" : false
          },
          {
            "name" : "Marques Brownlee",
            "isDisabled" : false
          },
          {
            "name" : "MasterCard",
            "isDisabled" : false
          },
          {
            "name" : "Meta",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft Windows",
            "isDisabled" : false
          },
          {
            "name" : "Miracle Workers",
            "isDisabled" : false
          },
          {
            "name" : "Mobile gaming",
            "isDisabled" : false
          },
          {
            "name" : "Mohamed Hamaki",
            "isDisabled" : false
          },
          {
            "name" : "Monero cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Mortgage",
            "isDisabled" : false
          },
          {
            "name" : "Mortgage Rates",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV events",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music and radio",
            "isDisabled" : false
          },
          {
            "name" : "Music industry",
            "isDisabled" : false
          },
          {
            "name" : "Music streaming service",
            "isDisabled" : false
          },
          {
            "name" : "NASA",
            "isDisabled" : false
          },
          {
            "name" : "NEO cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "NFTs",
            "isDisabled" : false
          },
          {
            "name" : "Netflix",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Nvidia",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "PC gaming",
            "isDisabled" : false
          },
          {
            "name" : "Personal finance",
            "isDisabled" : false
          },
          {
            "name" : "Pets",
            "isDisabled" : false
          },
          {
            "name" : "PlayerUnknown's Battlegrounds",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Polygon",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Popcorn",
            "isDisabled" : false
          },
          {
            "name" : "Python",
            "isDisabled" : false
          },
          {
            "name" : "Rap",
            "isDisabled" : false
          },
          {
            "name" : "Ripple (XRP)",
            "isDisabled" : false
          },
          {
            "name" : "Robinhood",
            "isDisabled" : false
          },
          {
            "name" : "Rock",
            "isDisabled" : false
          },
          {
            "name" : "Roleplaying games",
            "isDisabled" : false
          },
          {
            "name" : "Rom-com films",
            "isDisabled" : false
          },
          {
            "name" : "Russia travel",
            "isDisabled" : false
          },
          {
            "name" : "S&P 500",
            "isDisabled" : false
          },
          {
            "name" : "SEC Now",
            "isDisabled" : false
          },
          {
            "name" : "Samsung",
            "isDisabled" : false
          },
          {
            "name" : "San Francisco",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy films",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Shiba Inu",
            "isDisabled" : false
          },
          {
            "name" : "Silvina Escudero",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Soda",
            "isDisabled" : false
          },
          {
            "name" : "Solana cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Sony Pictures",
            "isDisabled" : false
          },
          {
            "name" : "South Indian cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Space",
            "isDisabled" : false
          },
          {
            "name" : "Space agencies & companies",
            "isDisabled" : false
          },
          {
            "name" : "SpaceX",
            "isDisabled" : false
          },
          {
            "name" : "Spain politics",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports events",
            "isDisabled" : false
          },
          {
            "name" : "Starbucks",
            "isDisabled" : false
          },
          {
            "name" : "Starlink",
            "isDisabled" : false
          },
          {
            "name" : "Stephen King",
            "isDisabled" : false
          },
          {
            "name" : "Stocks & indices",
            "isDisabled" : false
          },
          {
            "name" : "Supervivientes",
            "isDisabled" : false
          },
          {
            "name" : "Supervivientes España",
            "isDisabled" : false
          },
          {
            "name" : "Supervivientes Tierra De Nadie",
            "isDisabled" : false
          },
          {
            "name" : "Survival competition",
            "isDisabled" : false
          },
          {
            "name" : "Swifties",
            "isDisabled" : false
          },
          {
            "name" : "TE Connectivity",
            "isDisabled" : false
          },
          {
            "name" : "TV streaming services",
            "isDisabled" : false
          },
          {
            "name" : "Tango",
            "isDisabled" : false
          },
          {
            "name" : "Taylor Swift",
            "isDisabled" : false
          },
          {
            "name" : "Taylor Swift - test",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology and computing",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "Tesla Motors",
            "isDisabled" : false
          },
          {
            "name" : "Tether cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "The Guardian",
            "isDisabled" : false
          },
          {
            "name" : "The New York Times",
            "isDisabled" : false
          },
          {
            "name" : "The Wall Street Journal",
            "isDisabled" : false
          },
          {
            "name" : "Threads (Meta)",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "Venture capital",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Visa",
            "isDisabled" : false
          },
          {
            "name" : "Vitalik Buterin",
            "isDisabled" : false
          },
          {
            "name" : "WWE",
            "isDisabled" : false
          },
          {
            "name" : "Water",
            "isDisabled" : false
          },
          {
            "name" : "Web development",
            "isDisabled" : false
          },
          {
            "name" : "Web3",
            "isDisabled" : false
          },
          {
            "name" : "WhatsApp",
            "isDisabled" : false
          },
          {
            "name" : "Wine",
            "isDisabled" : false
          },
          {
            "name" : "Work from home",
            "isDisabled" : false
          },
          {
            "name" : "Workplace comedy",
            "isDisabled" : false
          },
          {
            "name" : "World",
            "isDisabled" : false
          },
          {
            "name" : "Wrestling",
            "isDisabled" : false
          },
          {
            "name" : "Writing",
            "isDisabled" : false
          },
          {
            "name" : "X - the everything app",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          },
          {
            "name" : "YouTube Music",
            "isDisabled" : false
          },
          {
            "name" : "YouTubers",
            "isDisabled" : false
          },
          {
            "name" : "Yuga Labs",
            "isDisabled" : false
          },
          {
            "name" : "Zcash cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "dApps",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [
            "@BigoArabia",
            "@GoodLifeBCA",
            "@McDMalaysia",
            "@McDonalds_Uy",
            "@TapScannerApp",
            "@Tinder_Japan",
            "@farfetch",
            "@indosatim3",
            "@yahoo_shopping"
          ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "Barbie (2023)",
          "Citadel (Prime Video)",
          "Don",
          "Game of Thrones",
          "Good Morning Britain",
          "MLB Baseball",
          "NBA Basketball",
          "SEC Now",
          "Salaar",
          "Under The Dome",
          "WNBA Basketball",
          "WWE Monday Night RAW"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]