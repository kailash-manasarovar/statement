window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "https://t.co/Hxm33SaBMq\n\nHere to save crypto from inbuilt-insipid-inertia #iii\n\nThen the world.",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1568722616722022400/r1Q6nMfL.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1568722551580278786/1691617853"
    }
  }
]