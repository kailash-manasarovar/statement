window.YTD.twitter_circle.part0 = [
  {
    "twitterCircle" : {
      "id" : "1582381518755971072",
      "ownerUserId" : "1568722551580278786",
      "createdAt" : "2022-10-18T14:42:07.949Z"
    }
  }
]