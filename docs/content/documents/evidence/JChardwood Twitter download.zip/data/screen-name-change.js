window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1568722551580278786",
      "screenNameChange" : {
        "changedAt" : "2022-09-10T22:06:39.000Z",
        "changedFrom" : "ChardwoodJack",
        "changedTo" : "JackChardwood"
      }
    }
  }
]