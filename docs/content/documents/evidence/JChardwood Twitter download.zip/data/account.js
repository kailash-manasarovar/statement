window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "jackchardwood@gmail.com",
      "createdVia" : "oauth:3033300",
      "username" : "JackChardwood",
      "accountId" : "1568722551580278786",
      "createdAt" : "2022-09-10T22:06:31.693Z",
      "accountDisplayName" : "Jack Chardwood"
    }
  }
]