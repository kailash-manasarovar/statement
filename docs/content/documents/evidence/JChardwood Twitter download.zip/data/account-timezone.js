window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1568722551580278786"
    }
  }
]