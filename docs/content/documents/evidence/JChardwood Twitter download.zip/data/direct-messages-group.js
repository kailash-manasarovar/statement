window.YTD.direct_messages_group.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1698243967467327619",
      "messages" : [
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/nz3nBHZkb5",
                "expanded" : "https://jchaat.com",
                "display" : "jchaat.com"
              }
            ],
            "text" : "𝘏𝘦𝘭𝘭𝘰, 𝘷𝘪𝘴𝘪𝘵 https://t.co/nz3nBHZkb5 𝘵𝘩𝘦𝘳𝘦 𝘪𝘴 1000 𝘶𝘴𝘦𝘳𝘴 𝘰𝘯𝘭𝘪𝘯𝘦. 𝘞𝘢𝘪𝘵𝘪𝘯𝘨 𝘶 :)",
            "mediaUrls" : [ ],
            "senderId" : "1595273832914644993",
            "id" : "1698244137630285941",
            "createdAt" : "2023-09-03T07:58:48.947Z"
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "1595273832914644993",
            "participantsSnapshot" : [
              "1595273832914644993",
              "1568722551580278786",
              "1050635996491001857",
              "1001484063344136193"
            ],
            "createdAt" : "2023-09-03T07:58:19.684Z"
          }
        }
      ]
    }
  }
]