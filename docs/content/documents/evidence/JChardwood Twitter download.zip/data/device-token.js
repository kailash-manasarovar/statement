window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "v3G3SqupUqUs7GE0fXnfBnJqcdjqy5j5Mp1GulrY",
      "createdAt" : "2022-09-10T22:06:31.811Z",
      "lastSeenAt" : "2022-09-10T22:06:31.813Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "kOaaoJnT3UOd8m8tnxkbfFhqSeWGvAQnZkbO1gfD",
      "createdAt" : "2023-02-09T11:01:21.504Z",
      "lastSeenAt" : "2023-02-11T09:13:10.783Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "XF517AqVSSi8faM0x2teMcGgq3V45VeJBRzwDnpK",
      "createdAt" : "2023-03-23T08:00:00.399Z",
      "lastSeenAt" : "2023-03-23T08:00:00.401Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "wV0DiHKeKu7okulPRsb3xN2CWhrnQGVt3Rhi9kkk",
      "createdAt" : "2023-03-27T17:17:01.023Z",
      "lastSeenAt" : "2023-03-27T17:17:01.025Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "brgpnHWU8UfbmEJoMgjY0A1wwWGNd2fMueNCp1md",
      "createdAt" : "2023-08-27T12:19:55.115Z",
      "lastSeenAt" : "2023-09-01T08:06:48.097Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Rsxti1YT0OGycl4fJfs7pGHeuJ9YLhAQjCJOv8Ey",
      "createdAt" : "2023-09-01T08:13:00.679Z",
      "lastSeenAt" : "2023-09-01T08:13:00.680Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]