window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "20997098",
      "userLink" : "https://twitter.com/intent/user?user_id=20997098"
    }
  },
  {
    "following" : {
      "accountId" : "1423937973201027078",
      "userLink" : "https://twitter.com/intent/user?user_id=1423937973201027078"
    }
  },
  {
    "following" : {
      "accountId" : "155629354",
      "userLink" : "https://twitter.com/intent/user?user_id=155629354"
    }
  },
  {
    "following" : {
      "accountId" : "1355014327988707329",
      "userLink" : "https://twitter.com/intent/user?user_id=1355014327988707329"
    }
  },
  {
    "following" : {
      "accountId" : "1605",
      "userLink" : "https://twitter.com/intent/user?user_id=1605"
    }
  },
  {
    "following" : {
      "accountId" : "12152152",
      "userLink" : "https://twitter.com/intent/user?user_id=12152152"
    }
  },
  {
    "following" : {
      "accountId" : "239241254",
      "userLink" : "https://twitter.com/intent/user?user_id=239241254"
    }
  },
  {
    "following" : {
      "accountId" : "30699048",
      "userLink" : "https://twitter.com/intent/user?user_id=30699048"
    }
  },
  {
    "following" : {
      "accountId" : "19694536",
      "userLink" : "https://twitter.com/intent/user?user_id=19694536"
    }
  },
  {
    "following" : {
      "accountId" : "153243904",
      "userLink" : "https://twitter.com/intent/user?user_id=153243904"
    }
  },
  {
    "following" : {
      "accountId" : "1347777544649641985",
      "userLink" : "https://twitter.com/intent/user?user_id=1347777544649641985"
    }
  },
  {
    "following" : {
      "accountId" : "2312333412",
      "userLink" : "https://twitter.com/intent/user?user_id=2312333412"
    }
  },
  {
    "following" : {
      "accountId" : "2235729541",
      "userLink" : "https://twitter.com/intent/user?user_id=2235729541"
    }
  },
  {
    "following" : {
      "accountId" : "210623431",
      "userLink" : "https://twitter.com/intent/user?user_id=210623431"
    }
  },
  {
    "following" : {
      "accountId" : "1333062067356532736",
      "userLink" : "https://twitter.com/intent/user?user_id=1333062067356532736"
    }
  },
  {
    "following" : {
      "accountId" : "1358176095850229761",
      "userLink" : "https://twitter.com/intent/user?user_id=1358176095850229761"
    }
  },
  {
    "following" : {
      "accountId" : "419697640",
      "userLink" : "https://twitter.com/intent/user?user_id=419697640"
    }
  },
  {
    "following" : {
      "accountId" : "1509206479475298305",
      "userLink" : "https://twitter.com/intent/user?user_id=1509206479475298305"
    }
  },
  {
    "following" : {
      "accountId" : "823518894182846464",
      "userLink" : "https://twitter.com/intent/user?user_id=823518894182846464"
    }
  },
  {
    "following" : {
      "accountId" : "3359503481",
      "userLink" : "https://twitter.com/intent/user?user_id=3359503481"
    }
  },
  {
    "following" : {
      "accountId" : "39394402",
      "userLink" : "https://twitter.com/intent/user?user_id=39394402"
    }
  },
  {
    "following" : {
      "accountId" : "1394583744",
      "userLink" : "https://twitter.com/intent/user?user_id=1394583744"
    }
  },
  {
    "following" : {
      "accountId" : "1258568182224338945",
      "userLink" : "https://twitter.com/intent/user?user_id=1258568182224338945"
    }
  },
  {
    "following" : {
      "accountId" : "2260491445",
      "userLink" : "https://twitter.com/intent/user?user_id=2260491445"
    }
  },
  {
    "following" : {
      "accountId" : "1568227771",
      "userLink" : "https://twitter.com/intent/user?user_id=1568227771"
    }
  },
  {
    "following" : {
      "accountId" : "1326229737551912960",
      "userLink" : "https://twitter.com/intent/user?user_id=1326229737551912960"
    }
  },
  {
    "following" : {
      "accountId" : "2738087632",
      "userLink" : "https://twitter.com/intent/user?user_id=2738087632"
    }
  },
  {
    "following" : {
      "accountId" : "3289324877",
      "userLink" : "https://twitter.com/intent/user?user_id=3289324877"
    }
  },
  {
    "following" : {
      "accountId" : "327084810",
      "userLink" : "https://twitter.com/intent/user?user_id=327084810"
    }
  },
  {
    "following" : {
      "accountId" : "1033739483609481216",
      "userLink" : "https://twitter.com/intent/user?user_id=1033739483609481216"
    }
  },
  {
    "following" : {
      "accountId" : "958118843636854784",
      "userLink" : "https://twitter.com/intent/user?user_id=958118843636854784"
    }
  },
  {
    "following" : {
      "accountId" : "2883228803",
      "userLink" : "https://twitter.com/intent/user?user_id=2883228803"
    }
  },
  {
    "following" : {
      "accountId" : "328669891",
      "userLink" : "https://twitter.com/intent/user?user_id=328669891"
    }
  },
  {
    "following" : {
      "accountId" : "1265223205230383104",
      "userLink" : "https://twitter.com/intent/user?user_id=1265223205230383104"
    }
  },
  {
    "following" : {
      "accountId" : "877807935493033984",
      "userLink" : "https://twitter.com/intent/user?user_id=877807935493033984"
    }
  },
  {
    "following" : {
      "accountId" : "173057927",
      "userLink" : "https://twitter.com/intent/user?user_id=173057927"
    }
  },
  {
    "following" : {
      "accountId" : "1031949518609121280",
      "userLink" : "https://twitter.com/intent/user?user_id=1031949518609121280"
    }
  },
  {
    "following" : {
      "accountId" : "878924739812761600",
      "userLink" : "https://twitter.com/intent/user?user_id=878924739812761600"
    }
  },
  {
    "following" : {
      "accountId" : "953748782394499072",
      "userLink" : "https://twitter.com/intent/user?user_id=953748782394499072"
    }
  },
  {
    "following" : {
      "accountId" : "1200616796295847936",
      "userLink" : "https://twitter.com/intent/user?user_id=1200616796295847936"
    }
  },
  {
    "following" : {
      "accountId" : "295218901",
      "userLink" : "https://twitter.com/intent/user?user_id=295218901"
    }
  },
  {
    "following" : {
      "accountId" : "2233154425",
      "userLink" : "https://twitter.com/intent/user?user_id=2233154425"
    }
  },
  {
    "following" : {
      "accountId" : "902926941413453824",
      "userLink" : "https://twitter.com/intent/user?user_id=902926941413453824"
    }
  },
  {
    "following" : {
      "accountId" : "1137038394503114753",
      "userLink" : "https://twitter.com/intent/user?user_id=1137038394503114753"
    }
  },
  {
    "following" : {
      "accountId" : "44196397",
      "userLink" : "https://twitter.com/intent/user?user_id=44196397"
    }
  },
  {
    "following" : {
      "accountId" : "1272543651982344194",
      "userLink" : "https://twitter.com/intent/user?user_id=1272543651982344194"
    }
  },
  {
    "following" : {
      "accountId" : "40148479",
      "userLink" : "https://twitter.com/intent/user?user_id=40148479"
    }
  },
  {
    "following" : {
      "accountId" : "20536157",
      "userLink" : "https://twitter.com/intent/user?user_id=20536157"
    }
  },
  {
    "following" : {
      "accountId" : "98335997",
      "userLink" : "https://twitter.com/intent/user?user_id=98335997"
    }
  },
  {
    "following" : {
      "accountId" : "382267114",
      "userLink" : "https://twitter.com/intent/user?user_id=382267114"
    }
  },
  {
    "following" : {
      "accountId" : "15670515",
      "userLink" : "https://twitter.com/intent/user?user_id=15670515"
    }
  },
  {
    "following" : {
      "accountId" : "74286565",
      "userLink" : "https://twitter.com/intent/user?user_id=74286565"
    }
  }
]