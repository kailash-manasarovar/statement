window.YTD.tweetdeck.part0 = [
  {
    "deck" : {
      "title" : "Personal",
      "columns" : [
        {
          "pathname" : "/home"
        },
        {
          "pathname" : "/JackChardwood"
        },
        {
          "pathname" : "/notifications"
        },
        {
          "pathname" : "/explore"
        }
      ]
    }
  }
]