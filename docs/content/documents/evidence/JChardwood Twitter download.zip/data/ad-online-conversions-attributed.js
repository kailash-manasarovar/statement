window.YTD.ad_online_conversions_attributed.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "attributedOnlineConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "LandingPageView",
              "eventType" : "{}",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://thehealthyfat.com/230605a/video/video.php?origexperimentalOrig=true&step=1&funnelSTPId=a0q3w00000DGmzXAAT&origsplitTestingFunnelIdOrig=a0w3w00001oOhZgAAK&origuidOrig=mctwellness_vsl_230612&origspidOrig=a0w3w00001oOhZgAAK&step=1&origdsidOrig=a0v3w00000JftnQAAR&origmainFunnelIdOrig=a0q3w00000DGmzWAAT&origExternalOrig=true&origExternalIDOrig=a0q3w00000DGmzWAAT&genericUrl=os220817a_ap-mctwellness_vsl_230612&orignameOrig=os220817a_ap-mctwellness_vsl_230612&origbrandOrig=Gundry%20MD&business_unit=a00f400000dk8tnaab&n=dbtcr&utm_campaign=gmd-db-mctwellness-twitter-all-desktop-qqq-jl&utm_campaign_id=7013w00000286QNAAY&utm_source=dbtcr&twclid=226g1h931hrb1xr0ollqdcaars&sessionid=173178956760",
              "advertiserInfo" : {
                "advertiserName" : "GundryMD",
                "screenName" : "@gundrymd_"
              },
              "conversionTime" : "2023-07-02 06:43:17",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  }
]